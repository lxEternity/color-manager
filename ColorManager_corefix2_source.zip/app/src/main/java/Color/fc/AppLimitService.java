package Color.fc;

import Color.fc.AppLimitService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/* loaded from: classes.dex */
public class AppLimitService extends Service {
    public static boolean running = false;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable loop = new AnonymousClass1();

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        return 1;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: Color.fc.AppLimitService$1, reason: invalid class name */
    /* loaded from: classes.dex */
    public class AnonymousClass1 implements Runnable {
        AnonymousClass1() {
        }

        @Override // java.lang.Runnable
        public void run() {
            new Thread(new Runnable() { // from class: Color.fc.AppLimitService$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    AppLimitService.AnonymousClass1.this.lambda$run$0();
                }
            }).start();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$run$0() {
            try {
                AppFreqLimiter.tick(AppLimitService.this);
            } catch (Exception unused) {
            }
            if (AppFreqLimiter.idle()) {
                AppLimitService.this.stopSelf();
            } else {
                AppLimitService.this.ui.postDelayed(this, 1000L);
            }
        }
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        running = true;
        startForeground(2, notif());
        this.ui.postDelayed(this.loop, 500L);
    }

    @Override // android.app.Service
    public void onDestroy() {
        running = false;
        this.ui.removeCallbacksAndMessages(null);
        AppFreqLimiter.restoreAll();
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void ensure(final Context context) {
        if (running) {
            return;
        }
        new Thread(new Runnable() { // from class: Color.fc.AppLimitService$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                AppLimitService.lambda$ensure$0(context);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$ensure$0(Context context) {
        if (AppFreqLimiter.anyLimitConfigured()) {
            try {
                context.startForegroundService(new Intent(context, (Class<?>) AppLimitService.class));
            } catch (Exception unused) {
            }
        }
    }

    private Notification notif() {
        ((NotificationManager) getSystemService(NotificationManager.class)).createNotificationChannel(new NotificationChannel("applimit", "单应用负载限制", 1));
        return new Notification.Builder(this, "applimit").setContentTitle("单应用负载限制运行中").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build();
    }
}
