package Color.fc;

import Color.fc.GovernorConfig;
import Color.fc.RootShell;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.TreeSet;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class GovernorActivity extends ThemedActivity {
    private static final String GOV_DIR_B = "/data/adb/modules/colorFC/B";
    private static final int REQ_IMPORT = 7301;
    private GovernorConfig.Gov[] govs;
    private TextView tabAV;
    private TextView tabBV;
    private static final String[] GOV_PRESETS = {"conservative", "walt", "ips", "sugov_next", "scx", "hmbird", "powersave", "performance", "schedutil"};
    private static final String[] FILES = {"conservative.sh", "scx1.sh", "scx2.sh", "scx3.sh"};
    private static final String[] NAMES = {"省电模式", "均衡模式", "性能模式", "极速模式"};
    private static final String[] DESCS = {"省电模式调速器参数（CPU0-7）", "均衡模式调速器参数（CPU 0/3/5/7）", "性能模式调速器参数（CPU 0/3/5/7）", "极速模式全核调速器参数（CPU0-7）"};
    private static final String[][] FIELDS = {new String[]{"governor", "upThreshold", "downThreshold", "freqStep", "samplingRate", "minFreq", "maxFreq"}, new String[]{"governor", "targetLoads", "minFreq", "maxFreq"}, new String[]{"governor", "targetLoads", "minFreq", "maxFreq"}, new String[]{"governor", "targetLoads", "minFreq", "maxFreq"}};
    private static final String[][] DEFAULTS = {new String[]{"conservative", "98", "93", "1", "14000", "0", "0"}, new String[]{"scx", "90", "0", "0"}, new String[]{"scx", "70", "0", "0"}, new String[]{"scx", "70", "0", "0"}};
    private static final String[] MIRROR_DIRS = {"/sdcard/Android/qingtd/A", "/data/adb/modules/colorFC/qingtd/A"};
    private final GovernorConfig.Gov[] govsA = new GovernorConfig.Gov[4];
    private final GovernorConfig.Gov[] govsB = new GovernorConfig.Gov[4];
    private String tab = "a";
    private final HashMap<String, EditText> inputs = new HashMap<>();
    private final HashMap<String, TextView> spinners = new HashMap<>();
    private final HashMap<String, TextView[]> coreChips = new HashMap<>();
    private final HashMap<String, TextView> freqVals = new HashMap<>();
    private long[] cpuFreqs = new long[0];
    private String[] govList = new String[0];
    private boolean loading = true;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // Color.fc.ThemedActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_governor);
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                GovernorActivity.this.lambda$onCreate$0(view);
            }
        });
        findViewById(R.id.saveBtn).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                GovernorActivity.this.lambda$onCreate$1(view);
            }
        });
        findViewById(R.id.btnImport).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                GovernorActivity.this.lambda$onCreate$2(view);
            }
        });
        findViewById(R.id.btnExport).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                GovernorActivity.this.lambda$onCreate$3(view);
            }
        });
        this.tabAV = (TextView) findViewById(R.id.tabA);
        this.tabBV = (TextView) findViewById(R.id.tabB);
        this.tabAV.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                GovernorActivity.this.lambda$onCreate$4(view);
            }
        });
        this.tabBV.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                GovernorActivity.this.lambda$onCreate$5(view);
            }
        });
        SocInfo socInfo = MainActivity.cachedSoc;
        if (socInfo == null) {
            socInfo = SocInfo.autoDetect();
        }
        this.tab = socInfo.config != null ? socInfo.config : "a";
        buildCards();
        new Thread(new Runnable() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                GovernorActivity.this.lambda$onCreate$7();
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(View view) {
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$1(View view) {
        saveAll();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$2(View view) {
        importLax();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$3(View view) {
        exportLax();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$4(View view) {
        switchTab("a");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$5(View view) {
        switchTab("b");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$7() {
        GovernorConfig.Gov[] loadGovMirror = loadGovMirror("a");
        GovernorConfig.Gov[] loadGovMirror2 = loadGovMirror("b");
        int i = 0;
        while (i < 4) {
            StringBuilder sb = new StringBuilder("/data/adb/modules/colorFC/A/");
            String[] strArr = FILES;
            boolean z = true;
            this.govsA[i] = mergeGov(GovernorConfig.parse(RootShell.readFile(sb.append(strArr[i]).toString()), i == 0), loadGovMirror[i], i);
            String readFile = RootShell.readFile("/data/adb/modules/colorFC/B/" + strArr[i]);
            if (i != 0) {
                z = false;
            }
            this.govsB[i] = mergeGov(GovernorConfig.parse(readFile, z), loadGovMirror2[i], i);
            i++;
        }
        loadFreqScan();
        loadGovScan();
        runOnUiThread(new Runnable() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda19
            @Override // java.lang.Runnable
            public final void run() {
                GovernorActivity.this.lambda$onCreate$6();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$6() {
        this.loading = false;
        this.govs = "b".equals(this.tab) ? this.govsB : this.govsA;
        applyTabStyle();
        fillInputs();
    }

    private void buildCards() {
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.modesContainer);
        int[] iArr = {-16730717, -16738616, -2061824, -6279952};
        int i = 0;
        while (i < 4) {
            View inflate = getLayoutInflater().inflate(R.layout.mode_card, (ViewGroup) linearLayout, false);
            View findViewById = inflate.findViewById(R.id.modeDot);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setShape(1);
            gradientDrawable.setColor(iArr[i]);
            findViewById.setBackground(gradientDrawable);
            ((TextView) inflate.findViewById(R.id.modeTitle)).setText(NAMES[i]);
            ((TextView) inflate.findViewById(R.id.modeSubtitle)).setText(DESCS[i]);
            final LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.paramsBox);
            final ImageView imageView = (ImageView) inflate.findViewById(R.id.expandArrow);
            inflate.findViewById(R.id.cardHeader).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda12
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    GovernorActivity.this.lambda$buildCards$8(linearLayout2, imageView, view);
                }
            });
            addCoreSelector(linearLayout2, i);
            addGovernorSelector(linearLayout2, i + ".governor", "调速器选择", i == 0 ? "conservative" : "scx");
            if (i == 0) {
                addParam(linearLayout2, i + ".upThreshold", "up_threshold 升频阈值（% 负载超过即升频）", "98", true);
                addParam(linearLayout2, i + ".downThreshold", "down_threshold 降频阈值（% 负载低于即降频）", "93", true);
                addParam(linearLayout2, i + ".freqStep", "freq_step 每次调频步进（%）", "1", true);
                addParam(linearLayout2, i + ".samplingRate", "sampling_rate 采样周期（µs）", "14000", false);
            } else {
                addParam(linearLayout2, i + ".targetLoads", "target_loads 目标负载（%）", i == 1 ? "90" : "70", true);
            }
            addFreqSelector(linearLayout2, i + ".minFreq", "CPU 最小频率限制");
            addFreqSelector(linearLayout2, i + ".maxFreq", "CPU 最大频率限制");
            linearLayout.addView(inflate);
            i++;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildCards$8(LinearLayout linearLayout, ImageView imageView, View view) {
        boolean z = linearLayout.getVisibility() != 0;
        linearLayout.setVisibility(z ? 0 : 8);
        rotateArrow(imageView, z);
    }

    private void addCoreSelector(LinearLayout linearLayout, int i) {
        TextView textView = new TextView(this);
        textView.setText("启用或关闭核心");
        textView.setTextSize(11.0f);
        textView.setTextColor(getResources().getColor(R.color.textSecondary));
        textView.setPadding(dp(2), dp(4), dp(2), dp(4));
        linearLayout.addView(textView);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        TextView[] textViewArr = new TextView[8];
        for (int i2 = 0; i2 < 8; i2++) {
            final TextView textView2 = new TextView(this);
            textView2.setText(String.valueOf(i2));
            textView2.setGravity(17);
            textView2.setTextSize(12.0f);
            textView2.setTypeface(Typeface.DEFAULT_BOLD);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setCornerRadius(dp(8));
            textView2.setBackground(gradientDrawable);
            textView2.setTag(Boolean.TRUE);
            styleChip(textView2, true);
            textView2.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda15
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    GovernorActivity.this.lambda$addCoreSelector$9(textView2, view);
                }
            });
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(30), dp(30));
            layoutParams.rightMargin = dp(6);
            textView2.setLayoutParams(layoutParams);
            linearLayout2.addView(textView2);
            textViewArr[i2] = textView2;
        }
        this.coreChips.put(String.valueOf(i), textViewArr);
        linearLayout.addView(linearLayout2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$addCoreSelector$9(TextView textView, View view) {
        if (this.loading) {
            return;
        }
        boolean z = !Boolean.TRUE.equals(textView.getTag());
        textView.setTag(Boolean.valueOf(z));
        styleChip(textView, z);
    }

    private void styleChip(TextView textView, boolean z) {
        ((GradientDrawable) textView.getBackground()).setColor(z ? -16738616 : getResources().getColor(R.color.bgInput));
        textView.setTextColor(z ? -1 : getResources().getColor(R.color.textDim));
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    private void rotateArrow(ImageView imageView, boolean z) {
        RotateAnimation rotateAnimation = new RotateAnimation(z ? 0.0f : 180.0f, z ? 180.0f : 0.0f, 1, 0.5f, 1, 0.5f);
        rotateAnimation.setDuration(200L);
        rotateAnimation.setInterpolator(new DecelerateInterpolator());
        rotateAnimation.setFillAfter(true);
        imageView.startAnimation(rotateAnimation);
    }

    private void addParam(LinearLayout linearLayout, String str, String str2, String str3, boolean z) {
        View inflate = getLayoutInflater().inflate(R.layout.param_row, (ViewGroup) linearLayout, false);
        ((TextView) inflate.findViewById(R.id.label)).setText(str2);
        final EditText editText = (EditText) inflate.findViewById(R.id.input);
        editText.setText(str3);
        final SeekBar seekBar = (SeekBar) inflate.findViewById(R.id.seek);
        if (z) {
            seekBar.setMax(100);
            try {
                seekBar.getProgressDrawable().setColorFilter(-16738616, PorterDuff.Mode.SRC_IN);
                seekBar.getThumb().setColorFilter(-16738616, PorterDuff.Mode.SRC_IN);
            } catch (Exception unused) {
            }
            editText.addTextChangedListener(new TextWatcher() { // from class: Color.fc.GovernorActivity.1
                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                    try {
                        seekBar.setProgress(Math.max(0, Math.min(100, Integer.parseInt(editable.toString().trim()))));
                    } catch (Exception unused2) {
                    }
                }
            });
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: Color.fc.GovernorActivity.2
                @Override // android.widget.SeekBar.OnSeekBarChangeListener
                public void onStartTrackingTouch(SeekBar seekBar2) {
                }

                @Override // android.widget.SeekBar.OnSeekBarChangeListener
                public void onStopTrackingTouch(SeekBar seekBar2) {
                }

                @Override // android.widget.SeekBar.OnSeekBarChangeListener
                public void onProgressChanged(SeekBar seekBar2, int i, boolean z2) {
                    if (z2) {
                        editText.setText(String.valueOf(i));
                    }
                }
            });
        } else {
            seekBar.setVisibility(8);
        }
        this.inputs.put(str, editText);
        linearLayout.addView(inflate);
    }

    private void addGovernorSelector(LinearLayout linearLayout, final String str, String str2, String str3) {
        View inflate = getLayoutInflater().inflate(R.layout.governor_row, (ViewGroup) linearLayout, false);
        ((TextView) inflate.findViewById(R.id.label)).setText(str2);
        final TextView textView = (TextView) inflate.findViewById(R.id.govValue);
        textView.setText(str3);
        textView.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                GovernorActivity.this.lambda$addGovernorSelector$10(str, textView, view);
            }
        });
        this.spinners.put(str, textView);
        linearLayout.addView(inflate);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$addGovernorSelector$10(String str, TextView textView, View view) {
        showGovPicker(str, textView);
    }

    private void showGovPicker(String str, final TextView textView) {
        String obj = textView.getText().toString();
        final String[] strArr = this.govList;
        if (strArr.length <= 0) {
            strArr = GOV_PRESETS;
        }
        int i = 0;
        while (true) {
            if (i >= strArr.length) {
                i = -1;
                break;
            } else if (strArr[i].equals(obj)) {
                break;
            } else {
                i++;
            }
        }
        AlertDialog create = new AlertDialog.Builder(this).setTitle("选择调速器").setSingleChoiceItems(strArr, i, new DialogInterface.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda10
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                GovernorActivity.this.lambda$showGovPicker$11(strArr, textView, dialogInterface, i2);
            }
        }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).create();
        if (create.getWindow() != null) {
            create.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
        }
        create.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showGovPicker$11(String[] strArr, TextView textView, DialogInterface dialogInterface, int i) {
        if (this.govList.length > 0 && !inGovList(strArr[i])) {
            Toast.makeText(this, "没有这个调速器！", 0).show();
        } else {
            textView.setText(strArr[i]);
            dialogInterface.dismiss();
        }
    }

    private boolean inGovList(String str) {
        for (String str2 : this.govList) {
            if (str2.equals(str)) {
                return true;
            }
        }
        return false;
    }

    private void addFreqSelector(LinearLayout linearLayout, final String str, String str2) {
        View inflate = getLayoutInflater().inflate(R.layout.governor_row, (ViewGroup) linearLayout, false);
        ((TextView) inflate.findViewById(R.id.label)).setText(str2);
        final TextView textView = (TextView) inflate.findViewById(R.id.govValue);
        textView.setText("不限制");
        textView.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda18
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                GovernorActivity.this.lambda$addFreqSelector$12(str, textView, view);
            }
        });
        this.freqVals.put(str, textView);
        linearLayout.addView(inflate);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$addFreqSelector$12(String str, TextView textView, View view) {
        showFreqPicker(str, textView);
    }

    private void showFreqPicker(String str, final TextView textView) {
        long[] jArr;
        int i = 0;
        if (this.cpuFreqs.length == 0) {
            Toast.makeText(this, "频率列表不可用，改为手动输入（MHz，0=不限制）", 0).show();
            showFreqManual(textView);
            return;
        }
        String trim = textView.getText().toString().trim();
        final String[] strArr = new String[this.cpuFreqs.length + 2];
        strArr[0] = "不限制";
        int i2 = "不限制".equals(trim) ? 0 : -1;
        while (true) {
            jArr = this.cpuFreqs;
            if (i >= jArr.length) {
                break;
            }
            int i3 = i + 1;
            strArr[i3] = this.cpuFreqs[i] + " MHz";
            if (i2 < 0 && String.valueOf(this.cpuFreqs[i]).equals(trim)) {
                i2 = i3;
            }
            i = i3;
        }
        strArr[jArr.length + 1] = "手动输入 MHz…";
        AlertDialog create = new AlertDialog.Builder(this).setTitle("选择频率").setSingleChoiceItems(strArr, i2, new DialogInterface.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda8
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i4) {
                GovernorActivity.this.lambda$showFreqPicker$13(textView, strArr, dialogInterface, i4);
            }
        }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).create();
        if (create.getWindow() != null) {
            create.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
        }
        create.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showFreqPicker$13(TextView textView, String[] strArr, DialogInterface dialogInterface, int i) {
        dialogInterface.dismiss();
        if (i == 0) {
            textView.setText("不限制");
        } else if (i == strArr.length - 1) {
            showFreqManual(textView);
        } else {
            textView.setText(String.valueOf(this.cpuFreqs[i - 1]));
        }
    }

    private void showFreqManual(final TextView textView) {
        final EditText editText = new EditText(this);
        editText.setInputType(2);
        editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        String trim = textView.getText().toString().trim();
        if ("不限制".equals(trim)) {
            trim = "0";
        }
        editText.setText(trim);
        AlertDialog create = new AlertDialog.Builder(this).setTitle("输入频率（MHz，0=不限制）").setView(editText).setPositiveButton("确定", new DialogInterface.OnClickListener() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda16
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                GovernorActivity.lambda$showFreqManual$14(editText, textView, dialogInterface, i);
            }
        }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).create();
        if (create.getWindow() != null) {
            create.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
        }
        create.show();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$showFreqManual$14(EditText editText, TextView textView, DialogInterface dialogInterface, int i) {
        String trim = editText.getText().toString().trim();
        if (trim.isEmpty()) {
            trim = "0";
        }
        try {
            long parseLong = Long.parseLong(trim);
            textView.setText(parseLong <= 0 ? "不限制" : String.valueOf(parseLong));
        } catch (Exception unused) {
        }
    }

    private void loadFreqScan() {
        int i = 0;
        try {
            String string = getSharedPreferences("colorfc", 0).getString("freqScan", "");
            if (!string.isEmpty()) {
                String[] split = string.split(",");
                long[] jArr = new long[split.length];
                int length = split.length;
                int i2 = 0;
                while (i < length) {
                    int i3 = i2 + 1;
                    try {
                        jArr[i2] = Long.parseLong(split[i]);
                    } catch (Exception unused) {
                    }
                    i++;
                    i2 = i3;
                }
                this.cpuFreqs = Arrays.copyOf(jArr, i2);
                return;
            }
            StringBuilder sb = new StringBuilder();
            for (int i4 = 0; i4 < 8; i4++) {
                sb.append("cat /sys/devices/system/cpu/cpu").append(i4).append("/cpufreq/scaling_available_frequencies 2>/dev/null; ");
            }
            TreeSet treeSet = new TreeSet(Collections.reverseOrder());
            RootShell.Result exec = RootShell.exec(sb.toString());
            if (exec.ok() && exec.out != null) {
                for (String str : exec.out.trim().split("\\s+")) {
                    try {
                        long parseLong = Long.parseLong(str);
                        if (parseLong > 1000) {
                            treeSet.add(Long.valueOf(parseLong / 1000));
                        }
                    } catch (Exception unused2) {
                    }
                }
            }
            if (treeSet.size() < 2) {
                StringBuilder sb2 = new StringBuilder();
                for (int i5 = 0; i5 < 8; i5++) {
                    sb2.append("cat /sys/devices/system/cpu/cpu").append(i5).append("/cpufreq/cpuinfo_min_freq 2>/dev/null; ");
                    sb2.append("cat /sys/devices/system/cpu/cpu").append(i5).append("/cpufreq/cpuinfo_max_freq 2>/dev/null; ");
                }
                RootShell.Result exec2 = RootShell.exec(sb2.toString());
                if (exec2.ok() && exec2.out != null) {
                    for (String str2 : exec2.out.trim().split("\\s+")) {
                        try {
                            long parseLong2 = Long.parseLong(str2);
                            if (parseLong2 > 1000) {
                                treeSet.add(Long.valueOf(parseLong2 / 1000));
                            }
                        } catch (Exception unused3) {
                        }
                    }
                }
            }
            if (treeSet.isEmpty()) {
                return;
            }
            StringBuilder sb3 = new StringBuilder();
            Iterator it = treeSet.iterator();
            while (it.hasNext()) {
                long longValue = ((Long) it.next()).longValue();
                if (sb3.length() > 0) {
                    sb3.append(',');
                }
                sb3.append(longValue);
            }
            getSharedPreferences("colorfc", 0).edit().putString("freqScan", sb3.toString()).commit();
            this.cpuFreqs = new long[treeSet.size()];
            Iterator it2 = treeSet.iterator();
            while (it2.hasNext()) {
                int i6 = i + 1;
                this.cpuFreqs[i] = ((Long) it2.next()).longValue();
                i = i6;
            }
        } catch (Exception unused4) {
        }
    }

    private void loadGovScan() {
        try {
            String string = getSharedPreferences("colorfc", 0).getString("govScan", "");
            if (!string.isEmpty()) {
                this.govList = string.split(",");
                return;
            }
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) {
                sb.append("cat /sys/devices/system/cpu/cpu").append(i).append("/cpufreq/scaling_available_governors 2>/dev/null; ");
            }
            RootShell.Result exec = RootShell.exec(sb.toString());
            LinkedHashSet linkedHashSet = new LinkedHashSet();
            if (exec.ok() && exec.out != null) {
                for (String str : exec.out.trim().split("\\s+")) {
                    String trim = str.trim();
                    if (!trim.isEmpty()) {
                        linkedHashSet.add(trim);
                    }
                }
            }
            if (linkedHashSet.isEmpty()) {
                return;
            }
            this.govList = (String[]) linkedHashSet.toArray(new String[0]);
            StringBuilder sb2 = new StringBuilder();
            Iterator it = linkedHashSet.iterator();
            while (it.hasNext()) {
                String str2 = (String) it.next();
                if (sb2.length() > 0) {
                    sb2.append(',');
                }
                sb2.append(str2);
            }
            getSharedPreferences("colorfc", 0).edit().putString("govScan", sb2.toString()).commit();
        } catch (Exception unused) {
        }
    }

    private void fillInputs() {
        for (int i = 0; i < 4; i++) {
            GovernorConfig.Gov gov = this.govs[i];
            TextView[] textViewArr = this.coreChips.get(String.valueOf(i));
            if (textViewArr != null && gov != null) {
                for (int i2 = 0; i2 < 8; i2++) {
                    textViewArr[i2].setTag(Boolean.valueOf(gov.cores[i2]));
                    styleChip(textViewArr[i2], gov.cores[i2]);
                }
            }
            int i3 = 0;
            while (true) {
                String[][] strArr = FIELDS;
                if (i3 < strArr[i].length) {
                    String str = i + "." + strArr[i][i3];
                    String readField = readField(gov, strArr[i][i3]);
                    if (readField == null || readField.isEmpty()) {
                        readField = DEFAULTS[i][i3];
                    }
                    if ("governor".equals(strArr[i][i3])) {
                        TextView textView = this.spinners.get(str);
                        if (textView != null && readField != null && !readField.isEmpty()) {
                            textView.setText(readField);
                        }
                    } else if ("minFreq".equals(strArr[i][i3]) || "maxFreq".equals(strArr[i][i3])) {
                        TextView textView2 = this.freqVals.get(str);
                        if (textView2 != null) {
                            textView2.setText(normF(readField).isEmpty() ? "不限制" : readField.trim());
                        }
                    } else {
                        EditText editText = this.inputs.get(str);
                        if (editText != null) {
                            editText.setText(readField);
                        }
                    }
                    i3++;
                }
            }
        }
    }

    private String readField(GovernorConfig.Gov gov, String str) {
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case -2102277828:
                if (str.equals("targetLoads")) {
                    c = 0;
                    break;
                }
                break;
            case -1970447562:
                if (str.equals("governor")) {
                    c = 1;
                    break;
                }
                break;
            case -1527278236:
                if (str.equals("freqStep")) {
                    c = 2;
                    break;
                }
                break;
            case -899222039:
                if (str.equals("downThreshold")) {
                    c = 3;
                    break;
                }
                break;
            case 127878503:
                if (str.equals("samplingRate")) {
                    c = 4;
                    break;
                }
                break;
            case 133903376:
                if (str.equals("upThreshold")) {
                    c = 5;
                    break;
                }
                break;
            case 843701756:
                if (str.equals("maxFreq")) {
                    c = 6;
                    break;
                }
                break;
            case 1063499754:
                if (str.equals("minFreq")) {
                    c = 7;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                return gov.targetLoads;
            case 1:
                return gov.governor;
            case 2:
                return gov.freqStep;
            case 3:
                return gov.downThreshold;
            case 4:
                return gov.samplingRate;
            case 5:
                return gov.upThreshold;
            case 6:
                return gov.maxFreq;
            case 7:
                return gov.minFreq;
            default:
                return "";
        }
    }

    private void writeField(GovernorConfig.Gov gov, String str, String str2) {
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case -2102277828:
                if (str.equals("targetLoads")) {
                    c = 0;
                    break;
                }
                break;
            case -1970447562:
                if (str.equals("governor")) {
                    c = 1;
                    break;
                }
                break;
            case -1527278236:
                if (str.equals("freqStep")) {
                    c = 2;
                    break;
                }
                break;
            case -899222039:
                if (str.equals("downThreshold")) {
                    c = 3;
                    break;
                }
                break;
            case 127878503:
                if (str.equals("samplingRate")) {
                    c = 4;
                    break;
                }
                break;
            case 133903376:
                if (str.equals("upThreshold")) {
                    c = 5;
                    break;
                }
                break;
            case 843701756:
                if (str.equals("maxFreq")) {
                    c = 6;
                    break;
                }
                break;
            case 1063499754:
                if (str.equals("minFreq")) {
                    c = 7;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                gov.targetLoads = str2;
                return;
            case 1:
                gov.governor = str2;
                return;
            case 2:
                gov.freqStep = str2;
                return;
            case 3:
                gov.downThreshold = str2;
                return;
            case 4:
                gov.samplingRate = str2;
                return;
            case 5:
                gov.upThreshold = str2;
                return;
            case 6:
                gov.maxFreq = str2;
                return;
            case 7:
                gov.minFreq = str2;
                return;
            default:
                return;
        }
    }

    private void collectInputs() {
        for (int i = 0; i < 4; i++) {
            TextView[] textViewArr = this.coreChips.get(String.valueOf(i));
            if (textViewArr != null && this.govs[i] != null) {
                for (int i2 = 0; i2 < 8; i2++) {
                    Object tag = textViewArr[i2].getTag();
                    this.govs[i].cores[i2] = tag == null || ((Boolean) tag).booleanValue();
                }
            }
            int i3 = 0;
            while (true) {
                String[] strArr = FIELDS[i];
                if (i3 < strArr.length) {
                    String str = strArr[i3];
                    if ("governor".equals(str)) {
                        TextView textView = this.spinners.get(i + "." + str);
                        if (textView != null && textView.getText() != null && textView.getText().length() > 0) {
                            writeField(this.govs[i], str, textView.getText().toString());
                        }
                    } else if ("minFreq".equals(str) || "maxFreq".equals(str)) {
                        TextView textView2 = this.freqVals.get(i + "." + str);
                        if (textView2 != null) {
                            String trim = textView2.getText().toString().trim();
                            GovernorConfig.Gov gov = this.govs[i];
                            if (trim.isEmpty() || "不限制".equals(trim)) {
                                trim = "0";
                            }
                            writeField(gov, str, trim);
                        }
                    } else {
                        EditText editText = this.inputs.get(i + "." + str);
                        if (editText != null) {
                            String trim2 = editText.getText().toString().trim();
                            if (trim2.isEmpty()) {
                                trim2 = DEFAULTS[i][i3];
                            }
                            writeField(this.govs[i], str, trim2);
                        }
                    }
                    i3++;
                }
            }
        }
    }

    private void saveAll() {
        GovernorConfig.Gov[] govArr;
        if (this.loading || (govArr = this.govs) == null || govArr[0] == null) {
            Toast.makeText(this, "配置仍在加载中", 0).show();
        } else {
            collectInputs();
            saveAll("b".equals(this.tab) ? 2 : 1);
        }
    }

    private void switchTab(String str) {
        if (str.equals(this.tab) || this.loading || this.govsA[0] == null) {
            return;
        }
        collectInputs();
        this.tab = str;
        this.govs = "b".equals(str) ? this.govsB : this.govsA;
        applyTabStyle();
        fillInputs();
    }

    private void applyTabStyle() {
        boolean equals = "a".equals(this.tab);
        this.tabAV.setBackgroundResource(equals ? R.drawable.bg_tab_sel : R.drawable.bg_tab);
        this.tabAV.setTextColor(equals ? -16746584 : -8615264);
        this.tabBV.setBackgroundResource(equals ? R.drawable.bg_tab : R.drawable.bg_tab_sel);
        this.tabBV.setTextColor(equals ? -8615264 : -16746584);
    }

    private void saveAll(final int i) {
        new Thread(new Runnable() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                GovernorActivity.this.lambda$saveAll$16(i);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$saveAll$16(int i) {
        final GovernorActivity governorActivity;
        final String str;
        String str2;
        String readFile;
        String[] strArr;
        StringBuilder append;
        int i2;
        saveGovMirror();
        ArrayList arrayList = new ArrayList();
        String str3 = RootShell.GOV_DIR;
        if (i != 2) {
            arrayList.add(RootShell.GOV_DIR);
        }
        if (i != 1) {
            arrayList.add(GOV_DIR_B);
        }
        StringBuilder sb = new StringBuilder();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            String str4 = (String) it.next();
            sb.append("mkdir -p '").append(str4).append("'; [ -f '");
            sb.append(str4).append("/json_cpu_max_min.orig' ] || cp '").append(str4).append("/json_cpu_max_min' '").append(str4).append("/json_cpu_max_min.orig'; ");
        }
        RootShell.exec(sb.toString());
        int i3 = 9;
        String[] strArr2 = new String[9];
        String[] strArr3 = {GovernorConfig.generateConservative(this.govs[0]), GovernorConfig.generateScx(this.govs[1]), GovernorConfig.generateScx(this.govs[2]), GovernorConfig.generateScx3(this.govs[3]), GovernorConfig.generateFreqScript(this.govs[0], 0), GovernorConfig.generateFreqScript(this.govs[1], 1), GovernorConfig.generateFreqScript(this.govs[2], 2), GovernorConfig.generateFreqScript(this.govs[3], 3), GovernorConfig.generateJmmScript()};
        for (int i4 = 0; i4 < 4; i4++) {
            strArr2[i4] = FILES[i4];
        }
        for (int i5 = 0; i5 < 4; i5++) {
            strArr2[i5 + 4] = "freq" + i5 + ".sh";
        }
        strArr2[8] = "json_cpu_max_min";
        String[] strArr4 = new String[arrayList.size() * 9];
        String[] strArr5 = new String[arrayList.size() * 9];
        int i6 = 0;
        while (i6 < arrayList.size()) {
            int i7 = 0;
            while (i7 < i3) {
                int i8 = (i6 * 9) + i7;
                strArr4[i8] = strArr3[i7];
                strArr5[i8] = ((String) arrayList.get(i6)) + "/" + strArr2[i7];
                i7++;
                i3 = 9;
            }
            i6++;
            i3 = 9;
        }
        final boolean writeFiles = RootShell.writeFiles(getCacheDir(), strArr4, strArr5);
        if (writeFiles) {
            StringBuilder sb2 = new StringBuilder();
            for (int i9 = 0; i9 < 4; i9++) {
                if (this.govs[i9] != null) {
                    for (int i10 = 0; i10 < 8; i10++) {
                        if (this.govs[i9].cores[i10]) {
                            sb2.append("echo 1 > /sys/devices/system/cpu/cpu").append(i10).append("/online 2>/dev/null; ");
                        }
                    }
                }
            }
            RootShell.exec(sb2.toString());
        }
        if (writeFiles) {
            StringBuilder sb3 = new StringBuilder();
            String[] strArr6 = MIRROR_DIRS;
            int i11 = 0;
            for (int length = strArr6.length; i11 < length; length = i2) {
                String str5 = strArr6[i11];
                if (str5.endsWith("/A")) {
                    strArr = strArr6;
                    append = new StringBuilder().append(str5.substring(0, str5.length() - 2)).append("/B");
                } else {
                    strArr = strArr6;
                    append = new StringBuilder().append(str5).append("B");
                }
                String sb4 = append.toString();
                String str6 = str3;
                if (arrayList.contains(str3)) {
                    sb3.append("mkdir -p '").append(str5).append("'; ");
                    i2 = length;
                    int i12 = 0;
                    for (int i13 = 9; i12 < i13; i13 = 9) {
                        sb3.append("cp '/data/adb/modules/colorFC/A/").append(strArr2[i12]).append("' '").append(str5).append("/").append(strArr2[i12]).append("'; ");
                        i12++;
                    }
                } else {
                    i2 = length;
                }
                if (arrayList.contains(GOV_DIR_B)) {
                    sb3.append("mkdir -p '").append(sb4).append("'; ");
                    for (int i14 = 0; i14 < 9; i14++) {
                        sb3.append("cp '/data/adb/modules/colorFC/B/").append(strArr2[i14]).append("' '").append(sb4).append("/").append(strArr2[i14]).append("'; ");
                    }
                }
                i11++;
                str3 = str6;
                strArr6 = strArr;
            }
            RootShell.exec(sb3.toString());
        }
        String[][] strArr7 = {new String[]{"a.all.sh", "A"}, new String[]{"b.all.sh", "B"}};
        for (int i15 = 0; i15 < 2; i15++) {
            String[] strArr8 = strArr7[i15];
            try {
                try {
                    str2 = "/data/adb/modules/colorFC/config/" + strArr8[0];
                    readFile = RootShell.readFile(str2);
                } catch (Exception unused) {
                }
            } catch (Exception unused2) {
            }
            if (readFile != null && !readFile.trim().isEmpty()) {
                try {
                    String patchFreqLines = AllConfig.patchFreqLines(readFile, strArr8[1]);
                    if (!patchFreqLines.equals(readFile)) {
                        RootShell.writeFile(getCacheDir(), patchFreqLines, str2);
                    }
                } catch (Exception unused3) {
                }
            }
        }
        if (writeFiles) {
            try {
                Thread.sleep(800L);
            } catch (InterruptedException unused4) {
            }
            governorActivity = this;
            int verifySaved = governorActivity.verifySaved(arrayList);
            if (verifySaved > 0) {
                str = " · " + verifySaved + " 个文件回读不符(被外部修改?)";
                governorActivity.runOnUiThread(new Runnable() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda17
                    @Override // java.lang.Runnable
                    public final void run() {
                        GovernorActivity.this.lambda$saveAll$15(writeFiles, str);
                    }
                });
            }
        } else {
            governorActivity = this;
        }
        str = "";
        governorActivity.runOnUiThread(new Runnable() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda17
            @Override // java.lang.Runnable
            public final void run() {
                GovernorActivity.this.lambda$saveAll$15(writeFiles, str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$saveAll$15(boolean z, String str) {
        if (z) {
            Toast.makeText(this, "保存成功" + str, 0).show();
        } else {
            Toast.makeText(this, "保存失败：脚本写入不成功，请重试", 1).show();
        }
    }

    private void saveGovMirror() {
        try {
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < 4; i++) {
                GovernorConfig.Gov gov = this.govs[i];
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("name", gov.governor);
                if (i == 0) {
                    jSONObject.put("up", gov.upThreshold);
                    jSONObject.put("down", gov.downThreshold);
                    jSONObject.put("step", gov.freqStep);
                    jSONObject.put("rate", gov.samplingRate);
                } else {
                    jSONObject.put("loads", gov.targetLoads);
                }
                jSONObject.put("fmin", gov.minFreq);
                jSONObject.put("fmax", gov.maxFreq);
                StringBuilder sb = new StringBuilder();
                for (boolean z : gov.cores) {
                    sb.append(z ? '1' : '0');
                }
                jSONObject.put("cores", sb.toString());
                jSONArray.put(jSONObject);
            }
            getSharedPreferences("colorfc", 0).edit().putString("govMirror." + this.tab, jSONArray.toString()).commit();
        } catch (Exception unused) {
        }
    }

    private GovernorConfig.Gov[] loadGovMirror(String str) {
        int i;
        String str2;
        String str3;
        String str4 = "rate";
        String str5 = "step";
        GovernorConfig.Gov[] govArr = new GovernorConfig.Gov[4];
        try {
            String string = getSharedPreferences("colorfc", 0).getString("govMirror." + str, "");
            if (string.isEmpty() && "a".equals(str)) {
                i = 0;
                string = getSharedPreferences("colorfc", 0).getString("govMirror", "");
            } else {
                i = 0;
            }
            if (string.isEmpty()) {
                string = "[]";
            }
            JSONArray jSONArray = new JSONArray(string);
            int i2 = i;
            while (i2 < 4) {
                if (i2 >= jSONArray.length()) {
                    break;
                }
                JSONObject optJSONObject = jSONArray.optJSONObject(i2);
                if (optJSONObject == null) {
                    str2 = str4;
                    str3 = str5;
                } else {
                    GovernorConfig.Gov gov = new GovernorConfig.Gov();
                    if (optJSONObject.has("name")) {
                        gov.governor = optJSONObject.getString("name");
                    }
                    if (i2 == 0) {
                        if (optJSONObject.has("up")) {
                            gov.upThreshold = optJSONObject.getString("up");
                        }
                        if (optJSONObject.has("down")) {
                            gov.downThreshold = optJSONObject.getString("down");
                        }
                        if (optJSONObject.has(str5)) {
                            gov.freqStep = optJSONObject.getString(str5);
                        }
                        if (optJSONObject.has(str4)) {
                            gov.samplingRate = optJSONObject.getString(str4);
                        }
                    } else if (optJSONObject.has("loads")) {
                        gov.targetLoads = optJSONObject.getString("loads");
                    }
                    if (optJSONObject.has("fmin")) {
                        gov.minFreq = optJSONObject.getString("fmin");
                    }
                    if (optJSONObject.has("fmax")) {
                        gov.maxFreq = optJSONObject.getString("fmax");
                    }
                    String optString = optJSONObject.optString("cores", "");
                    if (optString.length() == 8) {
                        int i3 = 0;
                        for (int i4 = 8; i3 < i4; i4 = 8) {
                            String str6 = str4;
                            String str7 = str5;
                            gov.cores[i3] = optString.charAt(i3) == '1';
                            i3++;
                            str4 = str6;
                            str5 = str7;
                        }
                    }
                    str2 = str4;
                    str3 = str5;
                    govArr[i2] = gov;
                }
                i2++;
                str4 = str2;
                str5 = str3;
            }
        } catch (Exception unused) {
        }
        return govArr;
    }

    private GovernorConfig.Gov mergeGov(GovernorConfig.Gov gov, GovernorConfig.Gov gov2, int i) {
        GovernorConfig.Gov gov3 = new GovernorConfig.Gov();
        boolean[] zArr = null;
        gov3.governor = pick(gov == null ? null : gov.governor, gov2 == null ? null : gov2.governor);
        if (i == 0) {
            gov3.upThreshold = pick(gov == null ? null : gov.upThreshold, gov2 == null ? null : gov2.upThreshold);
            gov3.downThreshold = pick(gov == null ? null : gov.downThreshold, gov2 == null ? null : gov2.downThreshold);
            gov3.freqStep = pick(gov == null ? null : gov.freqStep, gov2 == null ? null : gov2.freqStep);
            gov3.samplingRate = pick(gov == null ? null : gov.samplingRate, gov2 == null ? null : gov2.samplingRate);
        }
        if (i > 0) {
            gov3.targetLoads = pick(gov == null ? null : gov.targetLoads, gov2 == null ? null : gov2.targetLoads);
        }
        gov3.minFreq = pick(gov == null ? null : gov.minFreq, gov2 == null ? null : gov2.minFreq);
        gov3.maxFreq = pick(gov == null ? null : gov.maxFreq, gov2 == null ? null : gov2.maxFreq);
        if (gov != null && gov.hasOnline) {
            zArr = gov.cores;
        } else if (gov2 != null) {
            zArr = gov2.cores;
        }
        if (zArr != null) {
            System.arraycopy(zArr, 0, gov3.cores, 0, 8);
        }
        return gov3;
    }

    private String pick(String str, String str2) {
        return (str == null || str.isEmpty()) ? str2 : str;
    }

    private int verifySaved(List<String> list) {
        int i;
        StringBuilder sb = new StringBuilder();
        for (int i2 = 0; i2 < list.size(); i2++) {
            for (int i3 = 0; i3 < 4; i3++) {
                StringBuilder append = sb.append("echo '==CF=").append(i2).append('_');
                String[] strArr = FILES;
                append.append(strArr[i3]).append("='; cat '").append(list.get(i2)).append("/").append(strArr[i3]).append("'; ");
            }
        }
        RootShell.Result exec = RootShell.exec(sb.toString());
        if (!exec.ok()) {
            return 4;
        }
        int i4 = 0;
        for (int i5 = 0; i5 < list.size(); i5++) {
            while (i < 4) {
                String str = "==CF=" + i5 + "_" + FILES[i] + "=";
                int indexOf = exec.out.indexOf(str);
                if (indexOf >= 0) {
                    int length = indexOf + str.length();
                    int indexOf2 = exec.out.indexOf("==CF=", length);
                    GovernorConfig.Gov parse = GovernorConfig.parse(indexOf2 < 0 ? exec.out.substring(length) : exec.out.substring(length, indexOf2), i == 0);
                    i = (parse != null && sameGov(parse, this.govs[i], i)) ? i + 1 : 0;
                }
                i4++;
            }
        }
        return i4;
    }

    private boolean sameGov(GovernorConfig.Gov gov, GovernorConfig.Gov gov2, int i) {
        if (!eqv(gov.governor, gov2.governor)) {
            return false;
        }
        if (i == 0 && (!eqv(gov.upThreshold, gov2.upThreshold) || !eqv(gov.downThreshold, gov2.downThreshold) || !eqv(gov.freqStep, gov2.freqStep) || !eqv(gov.samplingRate, gov2.samplingRate))) {
            return false;
        }
        if ((i <= 0 || eqv(gov.targetLoads, gov2.targetLoads)) && eqvF(gov.minFreq, gov2.minFreq) && eqvF(gov.maxFreq, gov2.maxFreq)) {
            return Arrays.equals(gov.cores, gov2.cores);
        }
        return false;
    }

    private boolean eqvF(String str, String str2) {
        return normF(str).equals(normF(str2));
    }

    private String normF(String str) {
        if (str == null) {
            return "";
        }
        String trim = str.trim();
        return "0".equals(trim) ? "" : trim;
    }

    private boolean eqv(String str, String str2) {
        return str != null && str.equals(str2);
    }

    private void exportLax() {
        if (this.loading || this.govs[0] == null) {
            Toast.makeText(this, "配置仍在加载中", 0).show();
            return;
        }
        collectInputs();
        final LinkedHashMap linkedHashMap = new LinkedHashMap();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            GovernorConfig.Gov gov = this.govs[i];
            linkedHashMap.put("gov." + i + ".name", gov.governor);
            if (i == 0) {
                linkedHashMap.put("gov.0.up", gov.upThreshold);
                linkedHashMap.put("gov.0.down", gov.downThreshold);
                linkedHashMap.put("gov.0.step", gov.freqStep);
                linkedHashMap.put("gov.0.rate", gov.samplingRate);
            } else {
                linkedHashMap.put("gov." + i + ".loads", gov.targetLoads);
            }
            sb.setLength(0);
            for (boolean z : gov.cores) {
                sb.append(z ? '1' : '0');
            }
            linkedHashMap.put("gov." + i + ".cores", sb.toString());
            String str = "0";
            linkedHashMap.put("gov." + i + ".fmin", (gov.minFreq == null || gov.minFreq.isEmpty()) ? "0" : gov.minFreq);
            String str2 = "gov." + i + ".fmax";
            if (gov.maxFreq != null && !gov.maxFreq.isEmpty()) {
                str = gov.maxFreq;
            }
            linkedHashMap.put(str2, str);
        }
        new Thread(new Runnable() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                GovernorActivity.this.lambda$exportLax$18(linkedHashMap);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$exportLax$18(LinkedHashMap linkedHashMap) {
        final RootShell.Result write = LaxStore.write(getCacheDir(), linkedHashMap);
        runOnUiThread(new Runnable() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                GovernorActivity.this.lambda$exportLax$17(write);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$exportLax$17(RootShell.Result result) {
        String str;
        if (result.ok()) {
            str = "已导出 4 个模式到内部储存根目录 /storage/emulated/0/color.lax";
        } else {
            str = "导出失败：" + result.err;
        }
        Toast.makeText(this, str, 1).show();
    }

    private void importLax() {
        if (this.loading || this.govs[0] == null) {
            Toast.makeText(this, "配置仍在加载中", 0).show();
            return;
        }
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType("*/*");
        startActivityForResult(intent, REQ_IMPORT);
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i != REQ_IMPORT || i2 != -1 || intent == null || intent.getData() == null) {
            return;
        }
        final Uri data = intent.getData();
        if (this.loading || this.govs[0] == null) {
            Toast.makeText(this, "配置仍在加载中", 0).show();
        } else {
            new Thread(new Runnable() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda14
                @Override // java.lang.Runnable
                public final void run() {
                    GovernorActivity.this.lambda$onActivityResult$20(data);
                }
            }).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onActivityResult$20(Uri uri) {
        final LinkedHashMap<String, String> readUri = LaxStore.readUri(this, uri);
        runOnUiThread(new Runnable() { // from class: Color.fc.GovernorActivity$$ExternalSyntheticLambda11
            @Override // java.lang.Runnable
            public final void run() {
                GovernorActivity.this.lambda$onActivityResult$19(readUri);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onActivityResult$19(LinkedHashMap linkedHashMap) {
        if (linkedHashMap.isEmpty()) {
            Toast.makeText(this, "无法读取所选文件", 0).show();
            return;
        }
        int applyLax = applyLax(linkedHashMap);
        if (applyLax == 0) {
            Toast.makeText(this, "文件中没有调速器参数", 0).show();
        } else {
            fillInputs();
            Toast.makeText(this, "已导入 " + applyLax + " 项（4 个模式），点击保存后生效", 1).show();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:39:0x00d1  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private int applyLax(java.util.Map<java.lang.String, java.lang.String> r12) {
        /*
            Method dump skipped, instructions count: 308
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: Color.fc.GovernorActivity.applyLax(java.util.Map):int");
    }
}
