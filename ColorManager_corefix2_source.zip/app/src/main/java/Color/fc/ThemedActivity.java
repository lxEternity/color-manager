package Color.fc;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

/* loaded from: classes.dex */
public class ThemedActivity extends Activity {
    private static int sAppliedVer = -1;

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(ThemeStore.wrap(context));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        ThemeStore.applyTheme(this);
        sAppliedVer = ThemeStore.themeVersion(this);
        super.onCreate(bundle);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        if (sAppliedVer != ThemeStore.themeVersion(this)) {
            sAppliedVer = ThemeStore.themeVersion(this);
            recreate();
        } else {
            ThemeStore.applyBackground(this);
        }
    }
}
