package Color.fc;

import android.os.Build;

/* loaded from: classes.dex */
public class SocInfo {
    private static final String[][] MAP = {new String[]{"sm8975", "SM8975", "骁龙 8 至尊版 Gen 6 超级至尊版（一加16 等）", "8 Elite G6 Ex", "Qualcomm", "b"}, new String[]{"sm8950", "SM8950", "骁龙 8 至尊版 Gen 6", "8 Elite G6", "Qualcomm", "b"}, new String[]{"sm8875", "SM8875", "骁龙 8 至尊版 Gen 5（一加15 等）", "8 Elite G5", "Qualcomm", "b"}, new String[]{"sm8850", "SM8850", "骁龙 8 至尊版 Gen 5（一加15T/小米17 等）", "8 Elite G5", "Qualcomm", "b"}, new String[]{"sm8845", "SM8845", "第五代骁龙 8（8 Gen 5）", "8 Gen 5", "Qualcomm", "b"}, new String[]{"sm8750", "SM8750", "骁龙 8 至尊版（8 Elite）", "8 Elite", "Qualcomm", "a"}, new String[]{"sm8650", "SM8650", "骁龙 8 Gen 3", "8 Gen 3", "Qualcomm", "a"}, new String[]{"sm8550", "SM8550", "骁龙 8 Gen 2", "8 Gen 2", "Qualcomm", "a"}, new String[]{"sm8450", "SM8450", "骁龙 8 Gen 1", "8 Gen 1", "Qualcomm", "a"}, new String[]{"mt6995", "MT6995", "天玑 9500 系列", "天玑 9500", "MediaTek", "a"}, new String[]{"mt6993", "MT6993", "天玑 9500 系列", "天玑 9500", "MediaTek", "a"}, new String[]{"mt6991", "MT6991", "天玑 9400 系列", "天玑 9400", "MediaTek", "a"}, new String[]{"mt6989", "MT6989", "天玑 9300 / 9400E 系列", "天玑 9300", "MediaTek", "a"}};
    public final String code;
    public final String config;
    public final boolean known;
    public final String marketing;
    public final String platform;
    public final String shortName;
    public final String vendor;

    private SocInfo(String str, String str2, String str3, String str4, String str5, String str6, boolean z) {
        this.platform = str;
        this.code = str2;
        this.marketing = str3;
        this.shortName = str4;
        this.vendor = str5;
        this.config = str6;
        this.known = z;
    }

    public static SocInfo autoDetect() {
        String[] strArr = {"ro.board.platform", "ro.soc.model", "ro.mediatek.platform"};
        String str = "";
        for (int i = 0; i < 3; i++) {
            String str2 = RootShell.getprop(strArr[i]);
            if (str2 != null && !str2.trim().isEmpty()) {
                String trim = str2.trim();
                if (str.isEmpty()) {
                    str = trim;
                }
                SocInfo detect = detect(trim);
                if (detect.known) {
                    return detect;
                }
            }
        }
        String[] strArr2 = {Build.HARDWARE, Build.BOARD, Build.DEVICE};
        for (int i2 = 0; i2 < 3; i2++) {
            String str3 = strArr2[i2];
            if (str3 != null && !str3.trim().isEmpty()) {
                SocInfo detect2 = detect(str3.trim());
                if (detect2.known) {
                    return detect2;
                }
            }
        }
        return detect(str);
    }

    public static SocInfo detect(String str) {
        if (str == null) {
            str = "";
        }
        String lowerCase = str.trim().toLowerCase();
        for (String[] strArr : MAP) {
            if (strArr[0].equals(lowerCase)) {
                return new SocInfo(strArr[0], strArr[1], strArr[2], strArr[3], strArr[4], strArr[5], true);
            }
        }
        String upperCase = lowerCase.isEmpty() ? "未知" : lowerCase.toUpperCase();
        return new SocInfo(lowerCase, upperCase, lowerCase.isEmpty() ? "检测错误" : "检测错误（" + upperCase + "）", upperCase.length() <= 8 ? upperCase : upperCase.substring(0, 8), "--", "a", false);
    }
}
