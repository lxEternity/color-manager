package Color.fc;

import Color.fc.AppPickerDialog;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/* loaded from: classes.dex */
public class AppPickerDialog {

    /* loaded from: classes.dex */
    public interface PickCb {
        void on(String str, String str2);
    }

    public static void show(final Activity activity, Map<String, String> map, PickCb pickCb) {
        TextView textView;
        final ArrayList arrayList = new ArrayList();
        try {
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.addCategory("android.intent.category.LAUNCHER");
            arrayList.addAll(activity.getPackageManager().queryIntentActivities(intent, 0));
        } catch (Exception unused) {
        }
        Collections.sort(arrayList, new Comparator() { // from class: Color.fc.AppPickerDialog$$ExternalSyntheticLambda0
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                int compareTo;
                compareTo = String.valueOf(((ResolveInfo) obj).loadLabel(r0.getPackageManager())).toLowerCase(Locale.getDefault()).compareTo(String.valueOf(((ResolveInfo) obj2).loadLabel(activity.getPackageManager())).toLowerCase(Locale.getDefault()));
                return compareTo;
            }
        });
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_app_picker);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0));
            window.setLayout(-1, (int) (activity.getResources().getDisplayMetrics().heightPixels * 0.78f));
            window.setGravity(80);
        }
        final ArrayList arrayList2 = new ArrayList(arrayList);
        ListView listView = (ListView) dialog.findViewById(R.id.appList);
        EditText editText = (EditText) dialog.findViewById(R.id.searchInput);
        dialog.findViewById(R.id.btnClose).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.AppPickerDialog$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                dialog.dismiss();
            }
        });
        final AnonymousClass1 anonymousClass1 = new AnonymousClass1(arrayList2, activity, new HashMap(), map, dialog, pickCb);
        listView.setAdapter((ListAdapter) anonymousClass1);
        editText.addTextChangedListener(new TextWatcher() { // from class: Color.fc.AppPickerDialog.2
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
                String lowerCase = editable.toString().trim().toLowerCase(Locale.getDefault());
                arrayList2.clear();
                for (ResolveInfo resolveInfo : arrayList) {
                    String lowerCase2 = String.valueOf(resolveInfo.loadLabel(activity.getPackageManager())).toLowerCase(Locale.getDefault());
                    if (lowerCase.isEmpty() || lowerCase2.contains(lowerCase) || resolveInfo.activityInfo.packageName.toLowerCase(Locale.getDefault()).contains(lowerCase)) {
                        arrayList2.add(resolveInfo);
                    }
                }
                anonymousClass1.notifyDataSetChanged();
            }
        });
        dialog.show();
        if (!arrayList.isEmpty() || (textView = (TextView) dialog.findViewById(R.id.pickHint)) == null) {
            return;
        }
        textView.setText("未扫描到应用：请更新到 v1.15+ 并重新安装");
    }

    /* renamed from: Color.fc.AppPickerDialog$1, reason: invalid class name */
    /* loaded from: classes.dex */
    class AnonymousClass1 extends BaseAdapter {
        final /* synthetic */ PickCb val$cb;
        final /* synthetic */ Activity val$ctx;
        final /* synthetic */ Dialog val$d;
        final /* synthetic */ Map val$existing;
        final /* synthetic */ HashMap val$iconCache;
        final /* synthetic */ List val$shown;

        @Override // android.widget.Adapter
        public long getItemId(int i) {
            return i;
        }

        AnonymousClass1(List list, Activity activity, HashMap hashMap, Map map, Dialog dialog, PickCb pickCb) {
            this.val$shown = list;
            this.val$ctx = activity;
            this.val$iconCache = hashMap;
            this.val$existing = map;
            this.val$d = dialog;
            this.val$cb = pickCb;
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return this.val$shown.size();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i) {
            return this.val$shown.get(i);
        }

        @Override // android.widget.Adapter
        public View getView(int i, View view, ViewGroup viewGroup) {
            View view2;
            Drawable drawable;
            ResolveInfo resolveInfo = (ResolveInfo) this.val$shown.get(i);
            if (view == null) {
                LinearLayout linearLayout = new LinearLayout(this.val$ctx);
                linearLayout.setOrientation(0);
                linearLayout.setGravity(16);
                linearLayout.setPadding(AppPickerDialog.dp(this.val$ctx, 16), AppPickerDialog.dp(this.val$ctx, 9), AppPickerDialog.dp(this.val$ctx, 16), AppPickerDialog.dp(this.val$ctx, 9));
                ImageView imageView = new ImageView(this.val$ctx);
                imageView.setLayoutParams(new LinearLayout.LayoutParams(AppPickerDialog.dp(this.val$ctx, 40), AppPickerDialog.dp(this.val$ctx, 40)));
                imageView.setId(10);
                linearLayout.addView(imageView);
                LinearLayout linearLayout2 = new LinearLayout(this.val$ctx);
                linearLayout2.setOrientation(1);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
                layoutParams.leftMargin = AppPickerDialog.dp(this.val$ctx, 12);
                linearLayout2.setLayoutParams(layoutParams);
                TextView textView = new TextView(this.val$ctx);
                textView.setId(11);
                textView.setTextColor(-14998208);
                textView.setTextSize(14.5f);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                linearLayout2.addView(textView);
                TextView textView2 = new TextView(this.val$ctx);
                textView2.setId(12);
                textView2.setTextColor(-10654843);
                textView2.setTextSize(11.0f);
                linearLayout2.addView(textView2);
                linearLayout.addView(linearLayout2);
                TextView textView3 = new TextView(this.val$ctx);
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
                layoutParams2.leftMargin = AppPickerDialog.dp(this.val$ctx, 10);
                textView3.setLayoutParams(layoutParams2);
                textView3.setId(13);
                textView3.setTextSize(11.5f);
                textView3.setTypeface(Typeface.DEFAULT_BOLD);
                textView3.setPadding(AppPickerDialog.dp(this.val$ctx, 8), AppPickerDialog.dp(this.val$ctx, 3), AppPickerDialog.dp(this.val$ctx, 8), AppPickerDialog.dp(this.val$ctx, 3));
                linearLayout.addView(textView3);
                view2 = linearLayout;
            } else {
                view2 = view;
            }
            ImageView imageView2 = (ImageView) view2.findViewById(10);
            TextView textView4 = (TextView) view2.findViewById(11);
            TextView textView5 = (TextView) view2.findViewById(12);
            TextView textView6 = (TextView) view2.findViewById(13);
            final String valueOf = String.valueOf(resolveInfo.loadLabel(this.val$ctx.getPackageManager()));
            final String str = resolveInfo.activityInfo.packageName;
            textView4.setText(valueOf);
            textView5.setText(str);
            Drawable drawable2 = (Drawable) this.val$iconCache.get(str);
            if (drawable2 == null) {
                try {
                    drawable = resolveInfo.loadIcon(this.val$ctx.getPackageManager());
                } catch (Exception unused) {
                    drawable = null;
                }
                if (drawable == null) {
                    drawable = new ColorDrawable(-2300688);
                }
                drawable2 = drawable;
                this.val$iconCache.put(str, drawable2);
            }
            imageView2.setImageDrawable(drawable2);
            Map map = this.val$existing;
            String str2 = map != null ? (String) map.get(str) : null;
            if (str2 != null) {
                textView6.setVisibility(0);
                textView6.setText(str2);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(-1705987);
                gradientDrawable.setCornerRadius(AppPickerDialog.dp(this.val$ctx, 9));
                gradientDrawable.setStroke(1, -16738616);
                textView6.setBackground(gradientDrawable);
                textView6.setTextColor(-16738616);
            } else {
                textView6.setVisibility(8);
            }
            final Dialog dialog = this.val$d;
            final PickCb pickCb = this.val$cb;
            view2.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.AppPickerDialog$1$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view3) {
                    AppPickerDialog.AnonymousClass1.lambda$getView$0(dialog, pickCb, str, valueOf, view3);
                }
            });
            return view2;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public static /* synthetic */ void lambda$getView$0(Dialog dialog, PickCb pickCb, String str, String str2, View view) {
            dialog.dismiss();
            pickCb.on(str, str2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int dp(Context context, int i) {
        return Math.round(i * context.getResources().getDisplayMetrics().density);
    }
}
