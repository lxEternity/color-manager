package Color.fc;

import android.content.Context;
import android.net.Uri;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class FrameRecordStore {
    private static final int KEEP = 50;

    /* loaded from: classes.dex */
    public static class Rec {
        public double avgCpu;
        public double avgFps;
        public int cores;
        public long dur;
        public double maxCpu;
        public double maxFps;
        public double minFps;
        public String name;
        public String ref;
        public int samples;
        public long t;
    }

    private static File file(Context context) {
        return new File(context.getFilesDir(), "frame_records.json");
    }

    public static synchronized void add(Context context, long j, long j2, int i, int i2, List<Float> list, List<Float> list2, String str, String str2) {
        JSONObject jSONObject;
        PrintWriter printWriter;
        synchronized (FrameRecordStore.class) {
            Iterator<Float> it = list.iterator();
            double d = Double.MAX_VALUE;
            int i3 = 0;
            double d2 = 0.0d;
            double d3 = 0.0d;
            while (it.hasNext()) {
                float floatValue = it.next().floatValue();
                if (floatValue > 0.0f) {
                    double d4 = floatValue;
                    d2 += d4;
                    i3++;
                    d = Math.min(d, d4);
                    d3 = Math.max(d3, d4);
                }
            }
            int size = list2.size();
            Iterator<Float> it2 = list2.iterator();
            double d5 = 0.0d;
            double d6 = 0.0d;
            while (it2.hasNext()) {
                double floatValue2 = it2.next().floatValue();
                d5 += floatValue2;
                d6 = Math.max(d6, floatValue2);
            }
            try {
                jSONObject = new JSONObject();
                double d7 = d;
                double d8 = d6;
                jSONObject.put("t", j).put("dur", j2).put("n", i).put("cores", i2);
                jSONObject.put("avgF", i3 > 0 ? d2 / i3 : 0.0d).put("minF", i3 > 0 ? d7 : 0.0d).put("maxF", d3);
                jSONObject.put("avgC", size > 0 ? d5 / size : 0.0d).put("maxC", d8);
                jSONObject.put("ref", str).put("name", str2);
                printWriter = new PrintWriter(new FileWriter(file(context), true));
            } catch (Exception unused) {
            }
            try {
                printWriter.println(jSONObject.toString());
                printWriter.close();
                trim(context);
            } finally {
            }
        }
    }

    private static void trim(Context context) {
        List<Rec> parse = parse(context);
        if (parse.size() <= KEEP) {
            return;
        }
        ArrayList arrayList = new ArrayList(parse.subList(parse.size() - KEEP, parse.size()));
        try {
            PrintWriter printWriter = new PrintWriter(new FileWriter(file(context)));
            try {
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    printWriter.println(toJson((Rec) it.next()).toString());
                }
                printWriter.close();
            } finally {
            }
        } catch (Exception unused) {
        }
    }

    public static synchronized List<Rec> list(Context context) {
        ArrayList arrayList;
        synchronized (FrameRecordStore.class) {
            List<Rec> parse = parse(context);
            arrayList = new ArrayList(parse.size());
            for (int size = parse.size() - 1; size >= 0; size--) {
                arrayList.add(parse.get(size));
            }
        }
        return arrayList;
    }

    public static synchronized String summary(Context context) {
        synchronized (FrameRecordStore.class) {
            List<Rec> parse = parse(context);
            if (parse.isEmpty()) {
                return "暂无录制 · 在悬浮窗点 ● 开始";
            }
            Rec rec = parse.get(parse.size() - 1);
            return String.format(Locale.US, "共 %d 条 · 最近 %d:%02d 均%.0fHz", Integer.valueOf(parse.size()), Long.valueOf(rec.dur / 60000), Long.valueOf((rec.dur / 1000) % 60), Double.valueOf(rec.avgFps));
        }
    }

    public static synchronized void clear(Context context) {
        synchronized (FrameRecordStore.class) {
            for (Rec rec : parse(context)) {
                try {
                    if (rec.ref != null && rec.ref.startsWith("content://")) {
                        context.getContentResolver().delete(Uri.parse(rec.ref), null, null);
                    } else if (rec.ref != null) {
                        new File(rec.ref).delete();
                    }
                } catch (Exception unused) {
                }
            }
            try {
                file(context).delete();
            } catch (Exception unused2) {
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x008f A[EDGE_INSN: B:15:0x008f->B:16:0x008f BREAK  A[LOOP:0: B:4:0x0015->B:13:0x0015], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x001b A[Catch: all -> 0x0093, TRY_LEAVE, TryCatch #0 {all -> 0x0093, blocks: (B:5:0x0015, B:7:0x001b, B:10:0x0026), top: B:4:0x0015, outer: #1 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static java.util.List<Color.fc.FrameRecordStore.Rec> parse(android.content.Context r9) {
        /*
            java.lang.String r0 = ""
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.io.BufferedReader r2 = new java.io.BufferedReader     // Catch: java.lang.Exception -> L9d
            java.io.FileReader r3 = new java.io.FileReader     // Catch: java.lang.Exception -> L9d
            java.io.File r9 = file(r9)     // Catch: java.lang.Exception -> L9d
            r3.<init>(r9)     // Catch: java.lang.Exception -> L9d
            r2.<init>(r3)     // Catch: java.lang.Exception -> L9d
        L15:
            java.lang.String r9 = r2.readLine()     // Catch: java.lang.Throwable -> L93
            if (r9 == 0) goto L8f
            java.lang.String r9 = r9.trim()     // Catch: java.lang.Throwable -> L93
            boolean r3 = r9.isEmpty()     // Catch: java.lang.Throwable -> L93
            if (r3 == 0) goto L26
            goto L15
        L26:
            org.json.JSONObject r3 = new org.json.JSONObject     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r3.<init>(r9)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            Color.fc.FrameRecordStore$Rec r9 = new Color.fc.FrameRecordStore$Rec     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.<init>()     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            java.lang.String r4 = "t"
            long r4 = r3.getLong(r4)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.t = r4     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            java.lang.String r4 = "dur"
            long r4 = r3.getLong(r4)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.dur = r4     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            java.lang.String r4 = "n"
            r5 = 0
            int r4 = r3.optInt(r4, r5)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.samples = r4     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            java.lang.String r4 = "cores"
            int r4 = r3.optInt(r4, r5)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.cores = r4     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            java.lang.String r4 = "avgF"
            r5 = 0
            double r7 = r3.optDouble(r4, r5)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.avgFps = r7     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            java.lang.String r4 = "minF"
            double r7 = r3.optDouble(r4, r5)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.minFps = r7     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            java.lang.String r4 = "maxF"
            double r7 = r3.optDouble(r4, r5)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.maxFps = r7     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            java.lang.String r4 = "avgC"
            double r7 = r3.optDouble(r4, r5)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.avgCpu = r7     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            java.lang.String r4 = "maxC"
            double r4 = r3.optDouble(r4, r5)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.maxCpu = r4     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            java.lang.String r4 = "ref"
            java.lang.String r4 = r3.optString(r4, r0)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.ref = r4     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            java.lang.String r4 = "name"
            java.lang.String r3 = r3.optString(r4, r0)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r9.name = r3     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            r1.add(r9)     // Catch: java.lang.Exception -> L15 java.lang.Throwable -> L93
            goto L15
        L8f:
            r2.close()     // Catch: java.lang.Exception -> L9d
            goto L9d
        L93:
            r9 = move-exception
            r2.close()     // Catch: java.lang.Throwable -> L98
            goto L9c
        L98:
            r0 = move-exception
            r9.addSuppressed(r0)     // Catch: java.lang.Exception -> L9d
        L9c:
            throw r9     // Catch: java.lang.Exception -> L9d
        L9d:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: Color.fc.FrameRecordStore.parse(android.content.Context):java.util.List");
    }

    private static JSONObject toJson(Rec rec) {
        try {
            return new JSONObject().put("t", rec.t).put("dur", rec.dur).put("n", rec.samples).put("cores", rec.cores).put("avgF", rec.avgFps).put("minF", rec.minFps).put("maxF", rec.maxFps).put("avgC", rec.avgCpu).put("maxC", rec.maxCpu).put("ref", rec.ref).put("name", rec.name);
        } catch (Exception unused) {
            return new JSONObject();
        }
    }
}
