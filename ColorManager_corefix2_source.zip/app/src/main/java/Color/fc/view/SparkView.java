package Color.fc.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public class SparkView extends View {
    private final ArrayList<Double> data;
    private final Paint dotPaint;
    private final Paint fillPaint;
    private boolean fullSpan;
    private final Paint gridPaint;
    private double lastW;
    private final Paint linePaint;
    private double peak;

    public SparkView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.data = new ArrayList<>();
        this.peak = 0.001d;
        this.lastW = 0.0d;
        this.fullSpan = false;
        Paint paint = new Paint(1);
        this.linePaint = paint;
        this.fillPaint = new Paint(1);
        Paint paint2 = new Paint(1);
        this.gridPaint = paint2;
        Paint paint3 = new Paint(1);
        this.dotPaint = paint3;
        paint.setColor(-16738616);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(2.0f));
        paint2.setColor(-1446154);
        paint2.setStyle(Paint.Style.STROKE);
        paint2.setStrokeWidth(1.0f);
        paint3.setColor(-16738616);
    }

    public void push(double d) {
        this.fullSpan = false;
        this.lastW = d;
        this.data.add(Double.valueOf(d));
        if (this.data.size() > 90) {
            this.data.remove(0);
        }
        if (d > this.peak) {
            this.peak = d;
        }
        if (System.currentTimeMillis() % 8 == 0) {
            refreshPeak();
        }
        invalidate();
    }

    /*  JADX ERROR: NullPointerException in pass: LoopRegionVisitor
        java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.SSAVar.use(jadx.core.dex.instructions.args.RegisterArg)" because "ssaVar" is null
        	at jadx.core.dex.nodes.InsnNode.rebindArgs(InsnNode.java:489)
        	at jadx.core.dex.nodes.InsnNode.rebindArgs(InsnNode.java:492)
        */
    public void setData(float[] r7) {
        /*
            r6 = this;
            java.util.ArrayList<java.lang.Double> r0 = r6.data
            r0.clear()
            r0 = 4562254508917369340(0x3f50624dd2f1a9fc, double:0.001)
            r6.peak = r0
            int r0 = r7.length
            r1 = 0
        Le:
            if (r1 >= r0) goto L27
            r2 = r7[r1]
            java.util.ArrayList<java.lang.Double> r3 = r6.data
            double r4 = (double) r2
            java.lang.Double r2 = java.lang.Double.valueOf(r4)
            r3.add(r2)
            double r2 = r6.peak
            int r2 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r2 <= 0) goto L24
            r6.peak = r4
        L24:
            int r1 = r1 + 1
            goto Le
        L27:
            java.util.ArrayList<java.lang.Double> r7 = r6.data
            boolean r7 = r7.isEmpty()
            if (r7 == 0) goto L32
            r0 = 0
            goto L44
        L32:
            java.util.ArrayList<java.lang.Double> r7 = r6.data
            int r0 = r7.size()
            int r0 = r0 + (-1)
            java.lang.Object r7 = r7.get(r0)
            java.lang.Double r7 = (java.lang.Double) r7
            double r0 = r7.doubleValue()
        L44:
            r6.lastW = r0
            java.util.ArrayList<java.lang.Double> r7 = r6.data
            boolean r7 = r7.isEmpty()
            r7 = r7 ^ 1
            r6.fullSpan = r7
            r6.invalidate()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: Color.fc.view.SparkView.setData(float[]):void");
    }

    public double getLast() {
        return this.lastW;
    }

    public double getPeak() {
        return this.peak;
    }

    private void refreshPeak() {
        Iterator<Double> it = this.data.iterator();
        double d = 0.001d;
        while (it.hasNext()) {
            double doubleValue = it.next().doubleValue();
            if (doubleValue > d) {
                d = doubleValue;
            }
        }
        this.peak = d;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        float f;
        float f2;
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        int i = 1;
        for (int i2 = 1; i2 <= 3; i2++) {
            float f3 = (height * i2) / 4.0f;
            canvas.drawLine(0.0f, f3, width, f3, this.gridPaint);
        }
        int size = this.data.size();
        if (size < 2) {
            return;
        }
        if (this.fullSpan) {
            f = width;
            f2 = Math.max(size - 1, 1);
        } else {
            f = width;
            f2 = 89.0f;
        }
        float f4 = f / f2;
        float f5 = this.fullSpan ? 0.0f : width - ((size - 1) * f4);
        Path path = new Path();
        Path path2 = new Path();
        int i3 = 0;
        while (i3 < size) {
            float f6 = (i3 * f4) + f5;
            float f7 = height;
            float doubleValue = (f7 - (((float) (this.data.get(i3).doubleValue() / this.peak)) * (height - dp(6.0f)))) - dp(3.0f);
            if (i3 == 0) {
                path.moveTo(f6, doubleValue);
                path2.moveTo(f6, f7);
                path2.lineTo(f6, doubleValue);
            } else {
                path.lineTo(f6, doubleValue);
                path2.lineTo(f6, doubleValue);
            }
            i3++;
            i = 1;
        }
        int i4 = size - i;
        float f8 = (i4 * f4) + f5;
        float f9 = height;
        path2.lineTo(f8, f9);
        path2.lineTo(f5, f9);
        path2.close();
        this.fillPaint.setShader(new LinearGradient(0.0f, 0.0f, 0.0f, f9, 1076024302, 2282478, Shader.TileMode.CLAMP));
        this.fillPaint.setStyle(Paint.Style.FILL);
        canvas.drawPath(path2, this.fillPaint);
        canvas.drawPath(path, this.linePaint);
        canvas.drawCircle(f8, (f9 - (((float) (this.data.get(i4).doubleValue() / this.peak)) * (height - dp(6.0f)))) - dp(3.0f), dp(3.0f), this.dotPaint);
    }

    private int dp(float f) {
        return (int) ((f * getResources().getDisplayMetrics().density) + 0.5f);
    }
}
