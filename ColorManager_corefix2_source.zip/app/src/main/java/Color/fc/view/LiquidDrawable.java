package Color.fc.view;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/* loaded from: classes.dex */
public class LiquidDrawable extends Drawable {
    private final Paint arc;
    private final Paint bottomRim;
    private final RectF buf;
    private final Paint fill = new Paint(1);
    private final Path path;
    private final float radius;
    private final Paint rim;
    private final float strokeW;

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
    }

    public LiquidDrawable(float f, float f2) {
        Paint paint = new Paint(1);
        this.rim = paint;
        Paint paint2 = new Paint(1);
        this.arc = paint2;
        Paint paint3 = new Paint(1);
        this.bottomRim = paint3;
        this.path = new Path();
        this.buf = new RectF();
        this.radius = f;
        float f3 = f2 * 1.3f;
        this.strokeW = f3;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(f3);
        paint2.setStyle(Paint.Style.STROKE);
        paint2.setStrokeWidth(2.1f * f3);
        paint2.setStrokeCap(Paint.Cap.ROUND);
        paint3.setStyle(Paint.Style.STROKE);
        paint3.setStrokeWidth(f3);
        paint3.setColor(922746879);
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Rect bounds = getBounds();
        if (bounds.isEmpty()) {
            return;
        }
        this.buf.set(bounds);
        this.path.reset();
        Path path = this.path;
        RectF rectF = this.buf;
        float f = this.radius;
        path.addRoundRect(rectF, f, f, Path.Direction.CW);
        this.fill.setShader(new LinearGradient(0.0f, bounds.top, 0.0f, bounds.bottom, new int[]{1308622847, 451346431, 16777215}, new float[]{0.0f, 0.42f, 1.0f}, Shader.TileMode.CLAMP));
        canvas.drawPath(this.path, this.fill);
        this.fill.setShader(new LinearGradient(bounds.left, bounds.top, bounds.right, (bounds.height() * 0.7f) + bounds.top, new int[]{922746879, 268435455, 16777215, 352321535}, new float[]{0.0f, 0.32f, 0.62f, 1.0f}, Shader.TileMode.CLAMP));
        canvas.drawPath(this.path, this.fill);
        this.rim.setShader(new LinearGradient(0.0f, bounds.top, 0.0f, bounds.bottom, new int[]{-1761607681, 1342177279, 654311423}, new float[]{0.0f, 0.5f, 1.0f}, Shader.TileMode.CLAMP));
        canvas.drawPath(this.path, this.rim);
        this.arc.setShader(new LinearGradient(bounds.left, bounds.top, bounds.right, bounds.top, new int[]{16777215, -922746881, 16777215}, new float[]{0.0f, 0.5f, 1.0f}, Shader.TileMode.CLAMP));
        canvas.drawArc(bounds.left + (this.strokeW * 2.0f), bounds.top + this.strokeW, bounds.right - (this.strokeW * 2.0f), bounds.top + Math.max(this.strokeW * 2.0f, bounds.height() * 0.5f), -55.0f, 110.0f, false, this.arc);
        canvas.drawArc(bounds.left + this.strokeW, bounds.bottom - Math.max(this.strokeW * 3.0f, bounds.height() * 0.28f), bounds.right - this.strokeW, bounds.bottom - this.strokeW, 35.0f, 110.0f, false, this.bottomRim);
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i) {
        this.fill.setAlpha(i);
        this.rim.setAlpha(i);
        this.arc.setAlpha(i);
        this.bottomRim.setAlpha(i);
        invalidateSelf();
    }
}
