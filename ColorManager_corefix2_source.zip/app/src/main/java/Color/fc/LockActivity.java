package Color.fc;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/* loaded from: classes.dex */
public class LockActivity extends ThemedActivity {
    static final String ACCESS_PASSWORD = "bjs5120";

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // Color.fc.ThemedActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        final SharedPreferences sharedPreferences = getSharedPreferences("lock", 0);
        if (sharedPreferences.getBoolean("unlocked", false)) {
            startActivity(new Intent(this, (Class<?>) MainActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_lock);
        final EditText editText = (EditText) findViewById(R.id.passwordInput);
        Button button = (Button) findViewById(R.id.unlockBtn);
        final Runnable runnable = new Runnable() { // from class: Color.fc.LockActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                LockActivity.this.lambda$onCreate$0(editText, sharedPreferences);
            }
        };
        button.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.LockActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                runnable.run();
            }
        });
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: Color.fc.LockActivity$$ExternalSyntheticLambda2
            @Override // android.widget.TextView.OnEditorActionListener
            public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                return LockActivity.lambda$onCreate$2(runnable, textView, i, keyEvent);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(EditText editText, SharedPreferences sharedPreferences) {
        if (ACCESS_PASSWORD.equals(editText.getText().toString())) {
            sharedPreferences.edit().putBoolean("unlocked", true).apply();
            startActivity(new Intent(this, (Class<?>) MainActivity.class));
            finish();
        } else {
            Toast.makeText(this, "密码错误", 0).show();
            shake(editText);
            editText.setText("");
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ boolean lambda$onCreate$2(Runnable runnable, TextView textView, int i, KeyEvent keyEvent) {
        runnable.run();
        return true;
    }

    private void shake(View view) {
        TranslateAnimation translateAnimation = new TranslateAnimation(-18.0f, 18.0f, 0.0f, 0.0f);
        translateAnimation.setDuration(50L);
        translateAnimation.setRepeatCount(4);
        translateAnimation.setRepeatMode(2);
        view.startAnimation(translateAnimation);
    }
}
