package Color.fc;

import Color.fc.view.LiquidDrawable;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Insets;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import java.io.File;

/* loaded from: classes.dex */
public class ThemeStore {
    private static final String SP = "theme";
    private static final int TAG_BASE_PADDING = 1374605557;
    private static int cachedBotBar;
    private static int cachedTopBar;
    private static String renderKey;
    private static Bitmap rendered;

    private static boolean isLightColor(int i) {
        return ((((double) ((i >> 16) & 255)) * 0.299d) + (((double) ((i >> 8) & 255)) * 0.587d)) + (((double) (i & 255)) * 0.114d) > 128.0d;
    }

    public static boolean dark(Context context) {
        return context.getSharedPreferences(SP, 0).getBoolean("dark", false);
    }

    public static boolean transparentBg(Context context) {
        return context.getSharedPreferences(SP, 0).getBoolean("transparent", false);
    }

    public static boolean imageBg(Context context) {
        return context.getSharedPreferences(SP, 0).getBoolean("imageBg", false);
    }

    public static int bgAlpha(Context context) {
        return context.getSharedPreferences(SP, 0).getInt("bgAlpha", 100);
    }

    public static int bgScale(Context context) {
        return Math.max(100, context.getSharedPreferences(SP, 0).getInt("bgScale", 100));
    }

    public static int bgOffX(Context context) {
        return context.getSharedPreferences(SP, 0).getInt("bgOffX", 0);
    }

    public static int bgOffY(Context context) {
        return context.getSharedPreferences(SP, 0).getInt("bgOffY", 0);
    }

    public static int glassAlpha(Context context) {
        return Math.max(30, Math.min(100, context.getSharedPreferences(SP, 0).getInt("glass", 75)));
    }

    public static boolean liquidGlass(Context context) {
        return context.getSharedPreferences(SP, 0).getBoolean("liquid", false);
    }

    public static int themeVersion(Context context) {
        return context.getSharedPreferences(SP, 0).getInt("ver", 0);
    }

    public static File bgFile(Context context) {
        return new File(context.getFilesDir(), "bg.jpg");
    }

    public static void setDark(Context context, boolean z) {
        context.getSharedPreferences(SP, 0).edit().putBoolean("dark", z).putInt("ver", themeVersion(context) + 1).commit();
    }

    public static void setTransparent(Context context, boolean z) {
        context.getSharedPreferences(SP, 0).edit().putBoolean("transparent", z).commit();
    }

    public static void setImageBg(Context context, boolean z) {
        context.getSharedPreferences(SP, 0).edit().putBoolean("imageBg", z).commit();
    }

    public static void setBgAlpha(Context context, int i) {
        context.getSharedPreferences(SP, 0).edit().putInt("bgAlpha", Math.max(5, Math.min(100, i))).commit();
    }

    public static void setBgScale(Context context, int i) {
        context.getSharedPreferences(SP, 0).edit().putInt("bgScale", Math.max(100, Math.min(300, i))).commit();
    }

    public static void setBgOffX(Context context, int i) {
        context.getSharedPreferences(SP, 0).edit().putInt("bgOffX", Math.max(-50, Math.min(50, i))).commit();
    }

    public static void setBgOffY(Context context, int i) {
        context.getSharedPreferences(SP, 0).edit().putInt("bgOffY", Math.max(-50, Math.min(50, i))).commit();
    }

    public static void setGlass(Context context, int i) {
        context.getSharedPreferences(SP, 0).edit().putInt("glass", Math.max(30, Math.min(100, i))).commit();
    }

    public static void setLiquid(Context context, boolean z) {
        context.getSharedPreferences(SP, 0).edit().putBoolean("liquid", z).commit();
    }

    public static Context wrap(Context context) {
        if (!dark(context)) {
            return context;
        }
        Configuration configuration = new Configuration(context.getResources().getConfiguration());
        configuration.uiMode = (configuration.uiMode & (-49)) | 32;
        return context.createConfigurationContext(configuration);
    }

    public static void applyTheme(Activity activity) {
        activity.setTheme(dark(activity) ? R.style.AppTheme_Dark : R.style.AppTheme);
    }

    public static void invalidate() {
        rendered = null;
        renderKey = null;
        cachedBotBar = 0;
        cachedTopBar = 0;
    }

    public static void applyBackground(Activity activity) {
        int i;
        Window window = activity.getWindow();
        boolean dark = dark(activity);
        boolean z = imageBg(activity) && bgFile(activity).exists();
        boolean z2 = transparentBg(activity) && !z;
        boolean z3 = z || z2;
        setEdgeToEdge(window, z3);
        if (z) {
            window.setBackgroundDrawable(new BitmapDrawable(activity.getResources(), renderBg(activity, dark)));
        } else if (z2) {
            window.setBackgroundDrawable(new ColorDrawable(0));
        } else {
            window.setBackgroundDrawable(new ColorDrawable(dark ? -15920608 : -657412));
        }
        window.clearFlags(1048576);
        if (z3) {
            window.setStatusBarColor(0);
            window.setNavigationBarColor(0);
            setLightStatusIcons(window, (!z || (i = cachedTopBar) == 0) ? !dark : isLightColor(i));
        } else {
            int i2 = dark ? -15920608 : -657412;
            window.setStatusBarColor(i2);
            window.setNavigationBarColor(i2);
            setLightStatusIcons(window, !dark);
        }
        walkGlass(window.getDecorView(), z3 ? Math.round(glassAlpha(activity) * 2.55f) : 255);
        walkLiquid(window.getDecorView(), z3 && liquidGlass(activity), activity.getResources().getDisplayMetrics().density);
    }

    private static void setEdgeToEdge(Window window, boolean z) {
        View decorView = window.getDecorView();
        View findViewById = decorView.findViewById(android.R.id.content);
        if (findViewById == null) {
            return;
        }
        final int i = Build.VERSION.SDK_INT;
        if (z) {
            window.addFlags(Integer.MIN_VALUE);
            if (i >= 30) {
                window.setDecorFitsSystemWindows(false);
            } else {
                decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() | 1792);
            }
            if (findViewById.getTag(TAG_BASE_PADDING) == null) {
                findViewById.setTag(TAG_BASE_PADDING, new int[]{findViewById.getPaddingLeft(), findViewById.getPaddingTop(), findViewById.getPaddingRight(), findViewById.getPaddingBottom()});
            }
            findViewById.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() { // from class: Color.fc.ThemeStore$$ExternalSyntheticLambda0
                @Override // android.view.View.OnApplyWindowInsetsListener
                public final WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                    return ThemeStore.lambda$setEdgeToEdge$0(i, view, windowInsets);
                }
            });
            return;
        }
        if (i >= 30) {
            window.setDecorFitsSystemWindows(true);
        } else {
            decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() & (-1537));
        }
        findViewById.setOnApplyWindowInsetsListener(null);
        int[] iArr = (int[]) findViewById.getTag(TAG_BASE_PADDING);
        if (iArr != null) {
            findViewById.setPadding(iArr[0], iArr[1], iArr[2], iArr[3]);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ WindowInsets lambda$setEdgeToEdge$0(int i, View view, WindowInsets windowInsets) {
        int systemWindowInsetLeft;
        int systemWindowInsetTop;
        int systemWindowInsetRight;
        int systemWindowInsetBottom;
        int[] iArr = (int[]) view.getTag(TAG_BASE_PADDING);
        if (i >= 30) {
            Insets insets = windowInsets.getInsets(WindowInsets.Type.systemBars());
            Insets insets2 = windowInsets.getInsets(WindowInsets.Type.ime());
            systemWindowInsetLeft = insets.left;
            systemWindowInsetTop = insets.top;
            systemWindowInsetRight = insets.right;
            systemWindowInsetBottom = Math.max(insets.bottom, insets2.bottom);
        } else {
            systemWindowInsetLeft = windowInsets.getSystemWindowInsetLeft();
            systemWindowInsetTop = windowInsets.getSystemWindowInsetTop();
            systemWindowInsetRight = windowInsets.getSystemWindowInsetRight();
            systemWindowInsetBottom = windowInsets.getSystemWindowInsetBottom();
        }
        view.setPadding(iArr[0] + systemWindowInsetLeft, iArr[1] + systemWindowInsetTop, iArr[2] + systemWindowInsetRight, iArr[3] + systemWindowInsetBottom);
        return windowInsets;
    }

    private static void walkGlass(View view, int i) {
        Drawable background = view.getBackground();
        if (background instanceof GradientDrawable) {
            background.setAlpha(i);
        } else if (background instanceof LayerDrawable) {
            background.mutate().setAlpha(i);
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                walkGlass(viewGroup.getChildAt(i2), i);
            }
        }
    }

    private static void walkLiquid(View view, boolean z, float f) {
        Drawable background = view.getBackground();
        boolean z2 = background instanceof GradientDrawable;
        if (z2 || (background instanceof LayerDrawable)) {
            if (z) {
                float f2 = 18.0f * f;
                if (z2) {
                    try {
                        float cornerRadius = ((GradientDrawable) background).getCornerRadius();
                        if (cornerRadius > 0.0f) {
                            f2 = cornerRadius;
                        }
                    } catch (Exception unused) {
                    }
                }
                view.setForeground(new LiquidDrawable(f2, f));
            } else if (view.getForeground() instanceof LiquidDrawable) {
                view.setForeground(null);
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                walkLiquid(viewGroup.getChildAt(i), z, f);
            }
        }
    }

    private static void setLightStatusIcons(Window window, boolean z) {
        View decorView = window.getDecorView();
        if (Build.VERSION.SDK_INT >= 30) {
            window.getInsetsController().setSystemBarsAppearance(z ? 24 : 0, 24);
        } else {
            int systemUiVisibility = decorView.getSystemUiVisibility();
            decorView.setSystemUiVisibility(z ? systemUiVisibility | 8208 : systemUiVisibility & (-8209));
        }
    }

    private static synchronized Bitmap renderBg(Context context, boolean z) {
        synchronized (ThemeStore.class) {
            File bgFile = bgFile(context);
            Point point = new Point();
            ((WindowManager) context.getSystemService("window")).getDefaultDisplay().getRealSize(point);
            int max = Math.max(1, point.x);
            int max2 = Math.max(1, point.y);
            String str = bgFile.getAbsolutePath() + "|" + bgFile.lastModified() + "|" + max + "x" + max2 + "|" + bgScale(context) + "|" + bgOffX(context) + "|" + bgOffY(context) + "|" + bgAlpha(context) + "|" + z;
            if (rendered != null && str.equals(renderKey)) {
                return rendered;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(bgFile.getAbsolutePath(), options);
            int i = 1;
            while (true) {
                int i2 = i * 2;
                if (Math.max(options.outWidth, options.outHeight) / i2 < 2560) {
                    break;
                }
                i = i2;
            }
            BitmapFactory.Options options2 = new BitmapFactory.Options();
            options2.inSampleSize = i;
            Bitmap decodeFile = BitmapFactory.decodeFile(bgFile.getAbsolutePath(), options2);
            if (decodeFile == null) {
                rendered = null;
                renderKey = null;
                return Bitmap.createBitmap(max, max2, Bitmap.Config.ARGB_8888);
            }
            float f = max;
            float f2 = max2;
            float max3 = (Math.max(f / decodeFile.getWidth(), f2 / decodeFile.getHeight()) * bgScale(context)) / 100.0f;
            Matrix matrix = new Matrix();
            matrix.postScale(max3, max3);
            matrix.postTranslate(((f - (decodeFile.getWidth() * max3)) / 2.0f) + ((bgOffX(context) / 100.0f) * f), ((f2 - (decodeFile.getHeight() * max3)) / 2.0f) + ((bgOffY(context) / 100.0f) * f2));
            Bitmap createBitmap = Bitmap.createBitmap(max, max2, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(createBitmap);
            canvas.drawColor(z ? -15920608 : -657412);
            Paint paint = new Paint(2);
            paint.setAlpha(Math.round(bgAlpha(context) * 2.55f));
            canvas.drawBitmap(decodeFile, matrix, paint);
            if (z) {
                canvas.drawColor(1493172224);
            }
            decodeFile.recycle();
            try {
                cachedTopBar = createBitmap.getPixel(max / 2, Math.max(0, (int) (0.02f * f2)));
                cachedBotBar = createBitmap.getPixel(max / 2, Math.min(max2 - 1, (int) (f2 * 0.98f)));
            } catch (Exception unused) {
                cachedBotBar = 0;
                cachedTopBar = 0;
            }
            rendered = createBitmap;
            renderKey = str;
            return createBitmap;
        }
    }
}
