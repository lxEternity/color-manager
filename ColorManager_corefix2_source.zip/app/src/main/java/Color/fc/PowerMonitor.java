package Color.fc;

import Color.fc.RootShell;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public class PowerMonitor {
    private static final String SCAN_SCRIPT = "for d in /sys/class/power_supply/*; do [ -f \"$d/type\" ] || continue; t=$(cat \"$d/type\" 2>/dev/null); [ \"$t\" = \"Battery\" ] || [ \"$t\" = \"battery\" ] || continue; echo \"$d|$(cat \"$d/voltage_now\" 2>/dev/null)|$(cat \"$d/current_now\" 2>/dev/null)|$(cat \"$d/power_now\" 2>/dev/null)|$(cat \"$d/capacity\" 2>/dev/null)|$(cat \"$d/temp\" 2>/dev/null)|$(cat \"$d/status\" 2>/dev/null)\"; done";

    /* loaded from: classes.dex */
    public static class BatteryStat {
        public double amps;
        public int cells = 1;
        public int level = -1;
        public String status = "";
        public double tempC;
        public double volts;
        public double watts;
    }

    public static BatteryStat readOnce() {
        BatteryStat fromSysfs = fromSysfs();
        return fromSysfs == null ? fromDumpsys() : fromSysfs;
    }

    public static double applyCellMode(BatteryStat batteryStat, int i) {
        if (i == 0) {
            i = batteryStat.cells;
        }
        boolean z = i >= 2 && batteryStat.cells < 2;
        double d = batteryStat.amps;
        if (z) {
            d *= 2.0d;
        }
        return Math.abs(z ? batteryStat.volts * d : batteryStat.watts);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class Node {
        final double i;
        final String name;
        final double v;

        Node(String str, double d, double d2) {
            this.name = str;
            this.v = d;
            this.i = d2;
        }
    }

    private static boolean isAuxNode(String str) {
        String lowerCase = str.toLowerCase();
        return lowerCase.contains("bms") || lowerCase.contains("fg") || lowerCase.contains("gauge") || lowerCase.contains("charger") || lowerCase.contains("charge_pump") || lowerCase.contains("chargepump") || lowerCase.contains("pump") || lowerCase.contains("parallel") || lowerCase.contains("usb") || lowerCase.contains("dc");
    }

    private static String nodeName(String str) {
        if (str == null) {
            return "";
        }
        return str.contains("/") ? str.substring(str.lastIndexOf(47) + 1) : str;
    }

    private static BatteryStat fromSysfs() {
        String[] strArr;
        try {
            RootShell.Result exec = RootShell.exec(SCAN_SCRIPT);
            if (exec.ok() && exec.out != null && !exec.out.trim().isEmpty()) {
                ArrayList<String[]> arrayList = new ArrayList();
                for (String str : exec.out.split("\\n")) {
                    if (!str.trim().isEmpty()) {
                        String[] split = str.split("\\|");
                        if (split.length >= 7) {
                            arrayList.add(split);
                        }
                    }
                }
                if (arrayList.isEmpty()) {
                    return null;
                }
                BatteryStat batteryStat = new BatteryStat();
                Iterator it = arrayList.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        strArr = null;
                        break;
                    }
                    strArr = (String[]) it.next();
                    if ("battery".equals(nodeName(strArr[0]))) {
                        break;
                    }
                }
                if (strArr == null) {
                    Iterator it2 = arrayList.iterator();
                    while (true) {
                        if (!it2.hasNext()) {
                            break;
                        }
                        String[] strArr2 = (String[]) it2.next();
                        if (!isAuxNode(nodeName(strArr2[0]))) {
                            strArr = strArr2;
                            break;
                        }
                    }
                }
                int i = 2;
                if (strArr != null) {
                    batteryStat.volts = calibV(toD(strArr[1]));
                    batteryStat.amps = calibI(toD(strArr[2]));
                    double d = toD(strArr[3]);
                    if (batteryStat.volts <= 5.5d) {
                        i = 1;
                    }
                    batteryStat.cells = i;
                    batteryStat.watts = d != 0.0d ? calibW(d) : batteryStat.volts * batteryStat.amps;
                    fillBasic(batteryStat, strArr);
                    if (batteryStat.volts == 0.0d && batteryStat.watts == 0.0d && batteryStat.level < 0 && batteryStat.tempC == 0.0d) {
                        return null;
                    }
                    return batteryStat;
                }
                ArrayList arrayList2 = new ArrayList();
                for (String[] strArr3 : arrayList) {
                    double calibV = calibV(toD(strArr3[1]));
                    double calibI = calibI(toD(strArr3[2]));
                    if (calibV > 0.0d || calibI != 0.0d) {
                        arrayList2.add(new Node(nodeName(strArr3[0]), calibV, calibI));
                    }
                }
                Iterator it3 = arrayList.iterator();
                double d2 = 0.0d;
                while (it3.hasNext()) {
                    d2 = toD(((String[]) it3.next())[3]);
                    if (d2 != 0.0d) {
                        break;
                    }
                }
                Iterator it4 = arrayList2.iterator();
                double d3 = 0.0d;
                while (it4.hasNext()) {
                    d3 = Math.max(d3, ((Node) it4.next()).v);
                    d2 = d2;
                }
                double d4 = d2;
                boolean z = d3 > 5.5d;
                Iterator it5 = arrayList2.iterator();
                int i2 = 0;
                while (it5.hasNext()) {
                    if (!isAuxNode(((Node) it5.next()).name)) {
                        i2++;
                    }
                }
                boolean z2 = !z && i2 >= 2;
                if (!z && !z2) {
                    i = 1;
                }
                batteryStat.cells = i;
                if (!arrayList2.isEmpty()) {
                    Iterator it6 = arrayList2.iterator();
                    double d5 = 0.0d;
                    while (it6.hasNext()) {
                        d5 += ((Node) it6.next()).i;
                    }
                    if (z) {
                        batteryStat.volts = d3;
                        batteryStat.amps = d5 / arrayList2.size();
                    } else if (z2) {
                        batteryStat.volts = d3;
                        batteryStat.amps = d5;
                    } else {
                        batteryStat.volts = d3;
                        batteryStat.amps = d5 / arrayList2.size();
                    }
                    batteryStat.watts = d4 != 0.0d ? calibW(d4) : batteryStat.volts * batteryStat.amps;
                } else if (d4 != 0.0d) {
                    batteryStat.watts = calibW(d4);
                }
                fillBasic(batteryStat, (String[]) arrayList.get(0));
                if (batteryStat.volts == 0.0d && batteryStat.watts == 0.0d && batteryStat.level < 0 && batteryStat.tempC == 0.0d) {
                    return null;
                }
                return batteryStat;
            }
        } catch (Exception unused) {
        }
        return null;
    }

    private static BatteryStat fromDumpsys() {
        try {
            RootShell.Result exec = RootShell.exec("dumpsys battery");
            if (exec.ok() && exec.out != null && !exec.out.trim().isEmpty()) {
                BatteryStat batteryStat = new BatteryStat();
                String[] split = exec.out.split("\\n");
                int length = split.length;
                int i = 0;
                while (true) {
                    double d = 0.0d;
                    if (i >= length) {
                        break;
                    }
                    String trim = split[i].trim();
                    if (trim.startsWith("level:")) {
                        batteryStat.level = (int) toD(trim.substring(6).trim());
                    } else if (trim.startsWith("temperature:")) {
                        double d2 = toD(trim.substring(12).trim());
                        if (d2 >= 0.0d) {
                            d = d2 > 60.0d ? d2 / 10.0d : d2;
                        }
                        batteryStat.tempC = d;
                    } else if (trim.startsWith("voltage:")) {
                        batteryStat.volts = calibV(toD(trim.substring(8).trim()));
                    } else if (trim.startsWith("status:")) {
                        batteryStat.status = dumpsysStatus(trim.substring(7).trim());
                    }
                    i++;
                }
                if (batteryStat.level < 0 && batteryStat.tempC == 0.0d) {
                    if (batteryStat.volts == 0.0d) {
                        return null;
                    }
                }
                return batteryStat;
            }
        } catch (Exception unused) {
        }
        return null;
    }

    private static String dumpsysStatus(String str) {
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case 49:
                if (str.equals("1")) {
                    c = 0;
                    break;
                }
                break;
            case 50:
                if (str.equals("2")) {
                    c = 1;
                    break;
                }
                break;
            case 51:
                if (str.equals("3")) {
                    c = 2;
                    break;
                }
                break;
            case 52:
                if (str.equals("4")) {
                    c = 3;
                    break;
                }
                break;
            case 53:
                if (str.equals("5")) {
                    c = 4;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                return "Unknown";
            case 1:
                return "Charging";
            case 2:
                return "Discharging";
            case 3:
                return "Not charging";
            case 4:
                return "Full";
            default:
                return str;
        }
    }

    private static void fillBasic(BatteryStat batteryStat, String[] strArr) {
        batteryStat.level = (int) toD(strArr[4]);
        double d = toD(strArr[5]);
        if (d < 0.0d) {
            d = 0.0d;
        } else if (d > 60.0d) {
            d /= 10.0d;
        }
        batteryStat.tempC = d;
        String str = strArr[6];
        if (str != null) {
            batteryStat.status = str.trim();
        }
    }

    public static int cpuCount() {
        int i = 0;
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader("/proc/cpuinfo"));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                if (readLine.startsWith("processor")) {
                    i++;
                }
            }
            bufferedReader.close();
        } catch (Exception unused) {
        }
        if (i > 0) {
            return i;
        }
        return 8;
    }

    private static double toD(String str) {
        if (str == null) {
            return 0.0d;
        }
        try {
            return Double.parseDouble(str.trim());
        } catch (Exception unused) {
            return 0.0d;
        }
    }

    private static double calibV(double d) {
        double abs = Math.abs(d);
        return abs > 1000000.0d ? d / 1000000.0d : abs > 2500.0d ? d / 1000.0d : d;
    }

    private static double calibI(double d) {
        double d2;
        double abs = Math.abs(d);
        if (abs > 100000.0d) {
            d2 = 1000000.0d;
        } else {
            if (abs <= 1.0d) {
                return d;
            }
            d2 = 1000.0d;
        }
        return d / d2;
    }

    private static double calibW(double d) {
        double d2;
        double abs = Math.abs(d);
        if (abs > 100000.0d) {
            d2 = 1000000.0d;
        } else {
            if (abs <= 500.0d) {
                return d;
            }
            d2 = 1000.0d;
        }
        return d / d2;
    }
}
