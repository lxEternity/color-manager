package Color.fc;

import java.util.regex.Pattern;

/* loaded from: classes.dex */
public class GovernorConfig {
    private static final Pattern P_GOV = Pattern.compile("echo \\\"?([\\w.-]+)\\\"? > \\S*(?:cpu\\d+/cpufreq|cpufreq/policy\\d+)/scaling_governor");
    private static final Pattern P_UP = Pattern.compile("echo \\\"?([\\w.-]+)\\\"? > \\S*conservative/up_threshold");
    private static final Pattern P_DOWN = Pattern.compile("echo \\\"?([\\w.-]+)\\\"? > \\S*conservative/down_threshold");
    private static final Pattern P_STEP = Pattern.compile("echo \\\"?([\\w.-]+)\\\"? > \\S*conservative/freq_step");
    private static final Pattern P_RATE = Pattern.compile("echo \\\"?([\\w.-]+)\\\"? > \\S*conservative/sampling_rate");
    private static final Pattern P_LOADS = Pattern.compile("echo \\\"?([\\w.-]+)\\\"? > \\S*scx/target_loads");
    private static final Pattern P_ONLINE = Pattern.compile("echo \\\"?([01])\\\"? > \\S*cpu(\\d+)/online");
    private static final Pattern P_MIN_FREQ = Pattern.compile("echo \\\"?([\\w.-]+)\\\"? > \\S*(?:cpu\\d+/cpufreq|cpufreq/policy\\d+)/scaling_min_freq");
    private static final Pattern P_MAX_FREQ = Pattern.compile("echo \\\"?([\\w.-]+)\\\"? > \\S*(?:cpu\\d+/cpufreq|cpufreq/policy\\d+)/scaling_max_freq");

    /* loaded from: classes.dex */
    public static class Gov {
        public String governor = null;
        public String upThreshold = null;
        public String downThreshold = null;
        public String freqStep = null;
        public String samplingRate = null;
        public String targetLoads = null;
        public String minFreq = null;
        public String maxFreq = null;
        public final boolean[] cores = {true, true, true, true, true, true, true, true};
        public boolean hasOnline = false;
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x009b A[Catch: Exception -> 0x0107, TRY_LEAVE, TryCatch #0 {Exception -> 0x0107, blocks: (B:7:0x0014, B:9:0x0021, B:11:0x002c, B:13:0x0038, B:14:0x0040, B:16:0x004c, B:17:0x0054, B:19:0x0060, B:20:0x0068, B:22:0x0074, B:23:0x008d, B:24:0x008f, B:25:0x0095, B:27:0x009b, B:45:0x00bd, B:48:0x00e2, B:69:0x007b, B:71:0x0087), top: B:6:0x0014 }] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0105 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0106 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00ee A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00cd A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static Color.fc.GovernorConfig.Gov parse(java.lang.String r11, boolean r12) {
        /*
            Method dump skipped, instructions count: 264
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: Color.fc.GovernorConfig.parse(java.lang.String, boolean):Color.fc.GovernorConfig$Gov");
    }

    private static boolean anyOff(boolean[] zArr) {
        for (boolean z : zArr) {
            if (!z) {
                return true;
            }
        }
        return false;
    }

    private static void appendCoreOn(StringBuilder sb, boolean[] zArr) {
        if (anyOff(zArr)) {
            for (int i = 0; i < 8; i++) {
                if (zArr[i]) {
                    sb.append("echo 1 > /sys/devices/system/cpu/cpu").append(i).append("/online\n");
                }
            }
            sb.append('\n');
        }
    }

    private static void appendCoreOff(StringBuilder sb, boolean[] zArr) {
        if (anyOff(zArr)) {
            for (int i = 0; i < 8; i++) {
                if (!zArr[i]) {
                    sb.append("echo 0 > /sys/devices/system/cpu/cpu").append(i).append("/online\n");
                }
            }
        }
    }

    private static long mhzToKhz(String str) {
        try {
            long parseLong = Long.parseLong(str.trim());
            if (parseLong > 0) {
                return 1000 * parseLong;
            }
            return 0L;
        } catch (Exception unused) {
            return 0L;
        }
    }

    private static void appendFreqLimit(StringBuilder sb, String str, Gov gov) {
        long mhzToKhz = mhzToKhz(gov.minFreq);
        long mhzToKhz2 = mhzToKhz(gov.maxFreq);
        if (mhzToKhz > 0) {
            sb.append("echo ").append(mhzToKhz).append(" > ").append(str).append("scaling_min_freq\n");
        }
        if (mhzToKhz2 > 0) {
            sb.append("echo ").append(mhzToKhz2).append(" > ").append(str).append("scaling_max_freq\n");
        }
    }

    public static String generateConservative(Gov gov) {
        StringBuilder sb = new StringBuilder();
        appendCoreOn(sb, gov.cores);
        for (int i = 0; i < 8; i++) {
            String str = "/sys/devices/system/cpu/cpu" + i + "/cpufreq/";
            sb.append("chmod 777 ").append(str).append("scaling_governor\n");
            sb.append("echo \"").append(gov.governor).append("\" > ").append(str).append("scaling_governor\n");
            sb.append("echo \"").append(gov.upThreshold).append("\" > ").append(str).append("conservative/up_threshold\n");
            sb.append("echo \"").append(gov.downThreshold).append("\" > ").append(str).append("conservative/down_threshold\n");
            sb.append("echo \"").append(gov.freqStep).append("\" > ").append(str).append("conservative/freq_step\n");
            sb.append("echo \"").append(gov.samplingRate).append("\" > ").append(str).append("conservative/sampling_rate\n");
            appendFreqLimit(sb, str, gov);
            sb.append('\n');
        }
        appendCoreOff(sb, gov.cores);
        return sb.toString();
    }

    public static String generateScx(Gov gov) {
        StringBuilder sb = new StringBuilder();
        appendCoreOn(sb, gov.cores);
        int[] iArr = {0, 3, 5, 7};
        for (int i = 0; i < 4; i++) {
            sb.append("chmod 777 ").append("/sys/devices/system/cpu/cpu" + iArr[i] + "/cpufreq/").append("scaling_governor\n");
        }
        sb.append('\n');
        for (int i2 = 0; i2 < 4; i2++) {
            sb.append("echo \"").append(gov.governor).append("\" > ").append("/sys/devices/system/cpu/cpu" + iArr[i2] + "/cpufreq/").append("scaling_governor\n");
        }
        for (int i3 = 0; i3 < 4; i3++) {
            String str = "/sys/devices/system/cpu/cpu" + iArr[i3] + "/cpufreq/";
            sb.append("echo \"").append(gov.targetLoads).append("\" > ").append(str).append("scx/target_loads\n");
            appendFreqLimit(sb, str, gov);
        }
        appendCoreOff(sb, gov.cores);
        return sb.toString();
    }

    public static String generateFreqScript(Gov gov, int i) {
        long mhzToKhz = mhzToKhz(gov.minFreq);
        long mhzToKhz2 = mhzToKhz(gov.maxFreq);
        StringBuilder sb = new StringBuilder();
        for (int i2 = 0; i2 < 8; i2++) {
            if (gov.cores[i2]) {
                sb.append("echo 1 > /sys/devices/system/cpu/cpu").append(i2).append("/online 2>/dev/null\n");
            }
        }
        if (mhzToKhz <= 0 && mhzToKhz2 <= 0) {
            return sb.length() > 0 ? sb.toString() : "exit 0\n";
        }
        for (int i3 : (i == 0 || i == 3) ? new int[]{0, 1, 2, 3, 4, 5, 6, 7} : new int[]{0, 3, 5, 7}) {
            String str = "/sys/devices/system/cpu/cpu" + i3 + "/cpufreq/";
            if (mhzToKhz > 0) {
                sb.append("echo ").append(mhzToKhz).append(" > ").append(str).append("scaling_min_freq\n");
            }
            if (mhzToKhz2 > 0) {
                sb.append("echo ").append(mhzToKhz2).append(" > ").append(str).append("scaling_max_freq\n");
            }
        }
        return sb.toString();
    }

    public static String generateJmmScript() {
        return "#!/system/bin/sh\nmx=\"$1\"; mn=\"$2\"\nBASE=/sys/devices/system/cpu/cpufreq\nif [ -n \"$mx\" ]; then\n  for p in $BASE/policy*; do\n    [ -f \"$p/cpuinfo_max_freq\" ] || continue\n    imf=$(cat \"$p/cpuinfo_max_freq\" 2>/dev/null)\n    imn=$(cat \"$p/cpuinfo_min_freq\" 2>/dev/null)\n    [ -n \"$imf\" ] || continue\n    [ -n \"$mn\" ] || mn=0\n    vmax=$((imf * mx / 100))\n    vmin=$((imf * mn / 100))\n    chmod 777 \"$p/scaling_max_freq\" \"$p/scaling_min_freq\" 2>/dev/null\n    echo \"$imf\" > \"$p/scaling_max_freq\" 2>/dev/null\n    echo \"$imn\" > \"$p/scaling_min_freq\" 2>/dev/null\n    echo \"$vmax\" > \"$p/scaling_max_freq\" 2>/dev/null\n    echo \"$vmin\" > \"$p/scaling_min_freq\" 2>/dev/null\n  done\nfi\ncase \"$action\" in\n  powersave) n=0 ;;\n  balance) n=1 ;;\n  performance) n=2 ;;\n  fast) n=3 ;;\n  *) exit 0 ;;\nesac\nDIR=$(cd \"$(dirname \"$0\")\" 2>/dev/null && pwd)\n[ -n \"$DIR\" ] && [ -f \"$DIR/freq$n.sh\" ] && sh \"$DIR/freq$n.sh\"\nexit 0\n";
    }

    public static String generateScx3(Gov gov) {
        StringBuilder sb = new StringBuilder();
        appendCoreOn(sb, gov.cores);
        for (int i = 0; i < 8; i++) {
            sb.append("chmod 777 ").append("/sys/devices/system/cpu/cpu" + i + "/cpufreq/").append("scaling_governor\n");
        }
        sb.append('\n');
        for (int i2 = 0; i2 < 8; i2++) {
            sb.append("echo \"").append(gov.governor).append("\" > ").append("/sys/devices/system/cpu/cpu" + i2 + "/cpufreq/").append("scaling_governor\n");
        }
        for (int i3 = 0; i3 < 8; i3++) {
            String str = "/sys/devices/system/cpu/cpu" + i3 + "/cpufreq/";
            sb.append("echo \"").append(gov.targetLoads).append("\" > ").append(str).append("scx/target_loads\n");
            appendFreqLimit(sb, str, gov);
        }
        appendCoreOff(sb, gov.cores);
        return sb.toString();
    }
}
