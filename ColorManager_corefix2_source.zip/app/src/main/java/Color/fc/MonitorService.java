package Color.fc;

import Color.fc.MonitorService;
import Color.fc.PowerMonitor;
import Color.fc.RootShell;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.ToDoubleFunction;

/* loaded from: classes.dex */
public class MonitorService extends Service {
    private static final int COL_DIM = -8550762;
    private static final int COL_GREEN = -13318311;
    private static final int COL_LABEL = -6774093;
    private static final int COL_ORANGE = -27392;
    private static final int COL_VALUE = -854792;
    private static final String FPS_CMD = "f=$(dumpsys window 2>/dev/null | grep -m1 -E 'mCurrentFocus|mFocusedApp');p=$(echo \"$f\" | grep -oE '[A-Za-z0-9_.]+/' | head -1); p=${p%/};echo \"P:$p\";if [ -n \"$p\" ]; then dumpsys gfxinfo \"$p\" 2>/dev/null | grep -m1 'Total frames rendered' | grep -oE '[0-9]+' | tail -1; ll=$(dumpsys SurfaceFlinger --list 2>/dev/null | grep -F \"$p\" | grep -viE 'StatusBar|NavigationBar|ColorFade|ScreenDecor|Wallpaper|Sprite|Cursor|Ink|Dim|Toast|InputMethod|SplashScreen|saveLayer|ripple|Screenshot|Effect|Blur'); l=$(echo \"$ll\" | grep -m1 'SurfaceView'); [ -n \"$l\" ] || l=$(echo \"$ll\" | head -1); echo \"L:$l\"; [ -n \"$l\" ] && dumpsys SurfaceFlinger --latency \"$l\" 2>/dev/null;fi";
    private static final int MAX_CL = 3;
    private static final long MIN_REC_MS = 3000;
    private static final int M_FPS = 1;
    private static final int M_LOAD = 0;
    private static final int M_PWR = 4;
    private static final int M_TEMP = 3;
    private static final int M_THR = 2;
    private static final String SCAN = "g=$(cat /sys/class/kgsl/kgsl-3d0/gpuclk 2>/dev/null);[ -n \"$g\" ] || g=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq 2>/dev/null);[ -n \"$g\" ] || g=$(cat /sys/class/devfreq/*qcom,gpu*/cur_freq 2>/dev/null);[ -n \"$g\" ] || g=$(cat /sys/class/devfreq/*gpu*/cur_freq 2>/dev/null);echo \"G:$g\";gl=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/gpu_load 2>/dev/null);[ -n \"$gl\" ] || gl=$(cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage 2>/dev/null);[ -n \"$gl\" ] || gl=$(cat /sys/class/kgsl/kgsl-3d0/gpuload 2>/dev/null);echo \"GL:$gl\";gm=$(cat /sys/class/kgsl/kgsl-3d0/max_gpuclk 2>/dev/null);[ -n \"$gm\" ] || gm=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/max_freq 2>/dev/null);[ -n \"$gm\" ] || gm=$(cat /sys/class/kgsl/kgsl-3d0/gpu_available_frequencies 2>/dev/null | awk '{print $NF}');echo \"GM:$gm\";for q in /sys/devices/system/cpu/cpufreq/policy*; do echo \"Q:$(cat $q/scaling_cur_freq 2>/dev/null)\"; done;r=\"\"; for q in /sys/devices/system/cpu/cpufreq/policy*; do r=\"$r$(cat $q/related_cpu 2>/dev/null);\"; done; echo \"R:$r\";for z in /sys/class/thermal/thermal_zone*; do [ -f \"$z/temp\" ] || continue; echo \"T:$(cat \"$z/type\" 2>/dev/null):$(cat \"$z/temp\" 2>/dev/null)\"; done";
    public static volatile boolean running = false;
    private int[][] clMap;
    private LinearLayout clusterBox;
    private LinearLayout detailBox;
    private String fpsLayer;
    private String fpsPkg;
    private TextView fpsText;
    private long gfxAt;
    private long[] lastCoreIdle;
    private long[] lastCoreTotal;
    private LinearLayout listPanel;
    private TextView listQuit;
    private TextView listTitle;
    private Runnable pendingTap;
    private TextView pill;
    private TextView pwrBig;
    private long recStart;
    private RingsView rings;
    private TextView rowBat;
    private TextView rowCpu;
    private TextView rowGpu;
    private TextView rowRam;
    private TextView tempText;
    private Map<Integer, long[]> thrPrev;
    private WindowManager wm;
    private static final String[] MON_KEYS = {"mon_load", "mon_fps", "mon_thr", "mon_temp", "mon_pwr"};
    private static final String[] MON_LABELS = {"负载监视器", "帧率记录器", "线程监视器", "温度监视器", "功耗监视器"};
    private static final int COL_RED = -1096636;
    private static final int[] CORE_COLORS = {-16718337, -14494738, -15681151, -680437, COL_RED, -7643914, -1292135, -8074218};
    private final Handler ui = new Handler(Looper.getMainLooper());
    private int cellMode = M_LOAD;
    private boolean pillHidden = false;
    private final TextView[] listRows = new TextView[5];
    private boolean listOpen = false;
    private final View[] win = new View[5];
    private final WindowManager.LayoutParams[] wlp = new WindowManager.LayoutParams[5];
    private final boolean[] winOpen = new boolean[5];
    private boolean expanded = false;
    private final TextView[] thrRows = new TextView[6];
    private boolean locked = false;
    private long lastTapAt = 0;
    private volatile double cW = -1.0d;
    private volatile double cV = -1.0d;
    private volatile double cA = -1.0d;
    private volatile double cBusy = -1.0d;
    private volatile double cCpuM = 0.0d;
    private volatile double cGpuM = 0.0d;
    private volatile double cCpuT = 0.0d;
    private volatile double cSocT = 0.0d;
    private volatile double cBatT = 0.0d;
    private volatile float cHz = 0.0f;
    private volatile float batPct = -1.0f;
    private volatile float ramPct = -1.0f;
    private volatile float ramUsedG = 0.0f;
    private volatile float gpuLoad = -1.0f;
    private double gpuMax = 0.0d;
    private volatile long recShown = 0;
    private volatile int nCluster = M_LOAD;
    private final double[] clFreq = new double[3];
    private final float[] clBusy = new float[3];
    private final String[] clLbl = new String[3];
    private int rowsBuilt = M_LOAD;
    private long lastIdle = -1;
    private long lastTotal = -1;
    private long recLastIdle = -1;
    private long recLastTotal = -1;
    private int coreCount = M_LOAD;
    private long sfPrevNewest = -1;
    private long gfxFrames = -1;
    private float lastGoodHz = 0.0f;
    private long lastGoodAt = 0;
    private float peakHz = 0.0f;
    private long thrLastAt = 0;
    private double thrTck = 100.0d;
    private int thrPid = M_LOAD;
    private long thrPidAt = 0;
    private boolean recording = false;
    private final ArrayList<Long> ts = new ArrayList<>();
    private final ArrayList<Float> fps = new ArrayList<>();
    private final ArrayList<Float> cpuTot = new ArrayList<>();
    private final ArrayList<float[]> cores = new ArrayList<>();
    private final View.OnTouchListener pillTouch = new View.OnTouchListener() { // from class: Color.fc.MonitorService.1
        private long downAt;
        private float dx;
        private float dy;
        private boolean longFired;
        private final Runnable longRun = new Runnable() { // from class: Color.fc.MonitorService.1.1
            RunnableC00001() {
            }

            @Override // java.lang.Runnable
            public void run() {
                if (AnonymousClass1.this.moved) {
                    return;
                }
                AnonymousClass1.this.longFired = true;
                MonitorService.this.hidePill();
            }
        };
        private boolean moved;
        private float sx;
        private float sy;

        AnonymousClass1() {
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        /* renamed from: Color.fc.MonitorService$1$1 */
        /* loaded from: classes.dex */
        public class RunnableC00001 implements Runnable {
            RunnableC00001() {
            }

            @Override // java.lang.Runnable
            public void run() {
                if (AnonymousClass1.this.moved) {
                    return;
                }
                AnonymousClass1.this.longFired = true;
                MonitorService.this.hidePill();
            }
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) view.getLayoutParams();
            int action = motionEvent.getAction();
            if (action == 0) {
                this.sx = motionEvent.getRawX();
                this.sy = motionEvent.getRawY();
                this.dx = this.sx - layoutParams.x;
                this.dy = this.sy - layoutParams.y;
                this.downAt = System.currentTimeMillis();
                this.moved = false;
                this.longFired = false;
                MonitorService.this.ui.postDelayed(this.longRun, 500L);
                return true;
            }
            if (action != MonitorService.M_FPS) {
                if (action == MonitorService.M_THR) {
                    if (Math.abs(motionEvent.getRawX() - this.sx) > MonitorService.this.dp(12.0f) || Math.abs(motionEvent.getRawY() - this.sy) > MonitorService.this.dp(12.0f)) {
                        this.moved = true;
                        MonitorService.this.ui.removeCallbacks(this.longRun);
                    }
                    if (!MonitorService.this.locked && !this.longFired) {
                        layoutParams.x = (int) (motionEvent.getRawX() - this.dx);
                        layoutParams.y = (int) (motionEvent.getRawY() - this.dy);
                        try {
                            MonitorService.this.wm.updateViewLayout(view, layoutParams);
                            if (MonitorService.this.listOpen) {
                                MonitorService.this.positionList();
                            }
                        } catch (Exception unused) {
                        }
                    }
                    return true;
                }
                if (action != 3) {
                    return false;
                }
            }
            MonitorService.this.ui.removeCallbacks(this.longRun);
            if (!this.longFired && !this.moved && System.currentTimeMillis() - this.downAt < 350) {
                MonitorService.this.toggleList();
            }
            return true;
        }
    };

    private static int tColor(double d) {
        if (d >= 75.0d) {
            return COL_RED;
        }
        if (d >= 60.0d) {
            return -680437;
        }
        return COL_VALUE;
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent != null && "stop".equals(intent.getAction())) {
            stopSelf();
            return M_THR;
        }
        if (intent != null && "show_pill".equals(intent.getAction())) {
            showPill();
        }
        return M_FPS;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        running = true;
        SharedPreferences sharedPreferences = getSharedPreferences("colorfc", M_LOAD);
        this.cellMode = sharedPreferences.getInt("cellMode", M_LOAD);
        this.expanded = sharedPreferences.getBoolean("mon_expanded", false);
        this.pillHidden = sharedPreferences.getBoolean("mon_pill_hidden", false);
        this.locked = false;
        int i = M_LOAD;
        while (i < 5) {
            this.winOpen[i] = sharedPreferences.getBoolean(MON_KEYS[i], i == 0 ? M_FPS : M_LOAD);
            i += M_FPS;
        }
        startForeground(M_FPS, notif());
        this.wm = (WindowManager) getSystemService("window");
        try {
            Display[] displays = ((DisplayManager) getSystemService("display")).getDisplays();
            int length = displays.length;
            float f = 0.0f;
            for (int i2 = M_LOAD; i2 < length; i2 += M_FPS) {
                Display.Mode[] supportedModes = displays[i2].getSupportedModes();
                int length2 = supportedModes.length;
                for (int i3 = M_LOAD; i3 < length2; i3 += M_FPS) {
                    f = Math.max(f, supportedModes[i3].getRefreshRate());
                }
            }
            if (f > 30.0f) {
                this.peakHz = f;
            }
        } catch (Exception unused) {
        }
        buildListPanel();
        buildPill();
        buildLoadWin();
        buildFpsWin();
        buildThrWin();
        buildTempWin();
        buildPwrWin();
        for (int i4 = M_LOAD; i4 < 5; i4 += M_FPS) {
            if (this.winOpen[i4]) {
                addWin(i4);
            }
        }
        this.ui.postDelayed(new MonitorService$$ExternalSyntheticLambda13(this), 200L);
        this.ui.postDelayed(new MonitorService$$ExternalSyntheticLambda14(this), 800L);
        this.ui.postDelayed(new MonitorService$$ExternalSyntheticLambda15(this), 600L);
    }

    @Override // android.app.Service
    public void onDestroy() {
        running = false;
        this.ui.removeCallbacksAndMessages(null);
        if (this.recording) {
            stopRec(false);
        }
        for (int i = M_LOAD; i < 5; i += M_FPS) {
            View view = this.win[i];
            if (view != null && view.getParent() != null) {
                try {
                    this.wm.removeView(this.win[i]);
                } catch (Exception unused) {
                }
            }
        }
        LinearLayout linearLayout = this.listPanel;
        if (linearLayout != null && linearLayout.getParent() != null) {
            try {
                this.wm.removeView(this.listPanel);
            } catch (Exception unused2) {
            }
        }
        TextView textView = this.pill;
        if (textView != null) {
            try {
                this.wm.removeView(textView);
            } catch (Exception unused3) {
            }
        }
        super.onDestroy();
    }

    public int dp(float f) {
        return Math.round(f * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable winBg(int i) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(-735762644);
        gradientDrawable.setCornerRadius(i);
        return gradientDrawable;
    }

    private WindowManager.LayoutParams overlayLp(int i) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 264, -3);
        layoutParams.gravity = i;
        return layoutParams;
    }

    private TextView mkText(String str, int i, float f) {
        TextView textView = new TextView(this);
        textView.setTextColor(i);
        textView.setTextSize(f);
        textView.setTypeface(Typeface.MONOSPACE);
        textView.setText(str);
        return textView;
    }

    private LinearLayout mkBox(int i, int i2, int i3) {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(M_FPS);
        linearLayout.setBackground(winBg(i));
        float f = i2;
        float f2 = i3;
        linearLayout.setPadding(dp(f), dp(f2), dp(f), dp(f2));
        return linearLayout;
    }

    private boolean hit(View view, MotionEvent motionEvent) {
        int[] iArr = new int[M_THR];
        view.getLocationOnScreen(iArr);
        return motionEvent.getRawX() >= ((float) iArr[M_LOAD]) && motionEvent.getRawX() <= ((float) (iArr[M_LOAD] + view.getWidth())) && motionEvent.getRawY() >= ((float) iArr[M_FPS]) && motionEvent.getRawY() <= ((float) (iArr[M_FPS] + view.getHeight()));
    }

    private void addWin(int i) {
        try {
            this.wm.addView(this.win[i], this.wlp[i]);
        } catch (Exception unused) {
        }
    }

    private void showWin(int i) {
        boolean[] zArr = this.winOpen;
        if (zArr[i]) {
            return;
        }
        zArr[i] = true;
        getSharedPreferences("colorfc", M_LOAD).edit().putBoolean(MON_KEYS[i], true).apply();
        addWin(i);
        if (i == M_THR) {
            this.thrPrev = null;
        }
        if (i == 0) {
            updateUi();
        }
        syncList();
    }

    public void hideWin(int i) {
        boolean[] zArr = this.winOpen;
        if (zArr[i]) {
            zArr[i] = false;
            getSharedPreferences("colorfc", M_LOAD).edit().putBoolean(MON_KEYS[i], false).apply();
            try {
                this.wm.removeView(this.win[i]);
            } catch (Exception unused) {
            }
            if (i == M_FPS && this.recording) {
                stopRec(true);
            }
            if (i == 0) {
                this.lastIdle = -1L;
                this.lastTotal = -1L;
                this.lastCoreIdle = null;
            }
            syncList();
        }
    }

    private void buildPill() {
        TextView textView = new TextView(this);
        this.pill = textView;
        textView.setTypeface(Typeface.MONOSPACE);
        this.pill.setTextSize(10.0f);
        this.pill.setTextColor(COL_VALUE);
        this.pill.setText("监视器 ▾");
        this.pill.setBackground(winBg(dp(12.0f)));
        this.pill.setPadding(dp(10.0f), dp(3.0f), dp(10.0f), dp(3.0f));
        if (!this.pillHidden) {
            this.wm.addView(this.pill, overlayLp(8388659));
            this.pill.post(new Runnable() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda16
                @Override // java.lang.Runnable
                public final void run() {
                    MonitorService.this.lambda$buildPill$0();
                }
            });
        }
        this.pill.setOnTouchListener(this.pillTouch);
    }

    public /* synthetic */ void lambda$buildPill$0() {
        try {
            WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) this.pill.getLayoutParams();
            layoutParams.x = Math.max(M_LOAD, (getResources().getDisplayMetrics().widthPixels - this.pill.getWidth()) / M_THR);
            layoutParams.y = dp(2.0f);
            this.wm.updateViewLayout(this.pill, layoutParams);
        } catch (Exception unused) {
        }
    }

    public void hidePill() {
        try {
            this.wm.removeView(this.pill);
        } catch (Exception unused) {
        }
        this.pillHidden = true;
        if (this.listOpen) {
            toggleList();
        }
        getSharedPreferences("colorfc", M_LOAD).edit().putBoolean("mon_pill_hidden", true).apply();
    }

    private void showPill() {
        this.pillHidden = false;
        getSharedPreferences("colorfc", M_LOAD).edit().putBoolean("mon_pill_hidden", false).apply();
        try {
            if (this.pill.getParent() == null) {
                this.pill.measure(View.MeasureSpec.makeMeasureSpec(M_LOAD, M_LOAD), View.MeasureSpec.makeMeasureSpec(M_LOAD, M_LOAD));
                WindowManager.LayoutParams overlayLp = overlayLp(8388659);
                overlayLp.x = Math.max(M_LOAD, (getResources().getDisplayMetrics().widthPixels - this.pill.getMeasuredWidth()) / M_THR);
                overlayLp.y = dp(2.0f);
                this.wm.addView(this.pill, overlayLp);
            }
        } catch (Exception unused) {
        }
        Toast.makeText(this, "监视器菜单已恢复", M_LOAD).show();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: Color.fc.MonitorService$1 */
    /* loaded from: classes.dex */
    public class AnonymousClass1 implements View.OnTouchListener {
        private long downAt;
        private float dx;
        private float dy;
        private boolean longFired;
        private final Runnable longRun = new Runnable() { // from class: Color.fc.MonitorService.1.1
            RunnableC00001() {
            }

            @Override // java.lang.Runnable
            public void run() {
                if (AnonymousClass1.this.moved) {
                    return;
                }
                AnonymousClass1.this.longFired = true;
                MonitorService.this.hidePill();
            }
        };
        private boolean moved;
        private float sx;
        private float sy;

        AnonymousClass1() {
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        /* renamed from: Color.fc.MonitorService$1$1 */
        /* loaded from: classes.dex */
        public class RunnableC00001 implements Runnable {
            RunnableC00001() {
            }

            @Override // java.lang.Runnable
            public void run() {
                if (AnonymousClass1.this.moved) {
                    return;
                }
                AnonymousClass1.this.longFired = true;
                MonitorService.this.hidePill();
            }
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) view.getLayoutParams();
            int action = motionEvent.getAction();
            if (action == 0) {
                this.sx = motionEvent.getRawX();
                this.sy = motionEvent.getRawY();
                this.dx = this.sx - layoutParams.x;
                this.dy = this.sy - layoutParams.y;
                this.downAt = System.currentTimeMillis();
                this.moved = false;
                this.longFired = false;
                MonitorService.this.ui.postDelayed(this.longRun, 500L);
                return true;
            }
            if (action != MonitorService.M_FPS) {
                if (action == MonitorService.M_THR) {
                    if (Math.abs(motionEvent.getRawX() - this.sx) > MonitorService.this.dp(12.0f) || Math.abs(motionEvent.getRawY() - this.sy) > MonitorService.this.dp(12.0f)) {
                        this.moved = true;
                        MonitorService.this.ui.removeCallbacks(this.longRun);
                    }
                    if (!MonitorService.this.locked && !this.longFired) {
                        layoutParams.x = (int) (motionEvent.getRawX() - this.dx);
                        layoutParams.y = (int) (motionEvent.getRawY() - this.dy);
                        try {
                            MonitorService.this.wm.updateViewLayout(view, layoutParams);
                            if (MonitorService.this.listOpen) {
                                MonitorService.this.positionList();
                            }
                        } catch (Exception unused) {
                        }
                    }
                    return true;
                }
                if (action != 3) {
                    return false;
                }
            }
            MonitorService.this.ui.removeCallbacks(this.longRun);
            if (!this.longFired && !this.moved && System.currentTimeMillis() - this.downAt < 350) {
                MonitorService.this.toggleList();
            }
            return true;
        }
    }

    public void toggleList() {
        boolean z = !this.listOpen;
        this.listOpen = z;
        if (z) {
            syncList();
            WindowManager.LayoutParams overlayLp = overlayLp(8388659);
            overlayLp.x = dp(2.0f);
            overlayLp.y = dp(2.0f);
            this.wm.addView(this.listPanel, overlayLp);
            positionList();
        } else {
            try {
                this.wm.removeView(this.listPanel);
            } catch (Exception unused) {
            }
        }
        this.pill.setText(this.listOpen ? "监视器 ▴" : "监视器 ▾");
    }

    public void positionList() {
        try {
            WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) this.pill.getLayoutParams();
            this.listPanel.measure(View.MeasureSpec.makeMeasureSpec(M_LOAD, M_LOAD), View.MeasureSpec.makeMeasureSpec(M_LOAD, M_LOAD));
            int measuredWidth = this.listPanel.getMeasuredWidth();
            int measuredHeight = this.listPanel.getMeasuredHeight();
            int i = getResources().getDisplayMetrics().widthPixels;
            int i2 = getResources().getDisplayMetrics().heightPixels;
            int width = (layoutParams.x + (this.pill.getWidth() / M_THR)) - (measuredWidth / M_THR);
            if (width + measuredWidth > i - dp(2.0f)) {
                width = (i - dp(2.0f)) - measuredWidth;
            }
            if (width < dp(2.0f)) {
                width = dp(2.0f);
            }
            int height = layoutParams.y + this.pill.getHeight() + dp(6.0f);
            if (height + measuredHeight > i2 - dp(2.0f)) {
                height = Math.max(dp(2.0f), (i2 - dp(2.0f)) - measuredHeight);
            }
            WindowManager.LayoutParams layoutParams2 = (WindowManager.LayoutParams) this.listPanel.getLayoutParams();
            layoutParams2.gravity = 8388659;
            layoutParams2.x = width;
            layoutParams2.y = height;
            this.wm.updateViewLayout(this.listPanel, layoutParams2);
        } catch (Exception unused) {
        }
    }

    private void buildListPanel() {
        this.listPanel = mkBox(dp(10.0f), 10, 8);
        TextView mkText = mkText("监视器功能", COL_VALUE, 10.0f);
        this.listTitle = mkText;
        int dp = dp(2.0f);
        mkText.setPadding(M_LOAD, M_LOAD, M_LOAD, dp);
        this.listPanel.addView(this.listTitle);
        for (int i = M_LOAD; i < 5; i += M_FPS) {
            this.listRows[i] = mkText("", COL_VALUE, 10.0f);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.topMargin = dp(3.0f);
            this.listRows[i].setLayoutParams(layoutParams);
            this.listPanel.addView(this.listRows[i]);
        }
        this.listQuit = mkText("关闭监视器", COL_RED, 10.0f);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.topMargin = dp(5.0f);
        this.listQuit.setLayoutParams(layoutParams2);
        this.listPanel.addView(this.listQuit);
        this.listPanel.setOnTouchListener(new View.OnTouchListener() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda12
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                boolean lambda$buildListPanel$1;
                lambda$buildListPanel$1 = MonitorService.this.lambda$buildListPanel$1(view, motionEvent);
                return lambda$buildListPanel$1;
            }
        });
        syncList();
    }

    public /* synthetic */ boolean lambda$buildListPanel$1(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() != M_FPS) {
            return true;
        }
        if (hit(this.listTitle, motionEvent)) {
            toggleList();
            return true;
        }
        for (int i = M_LOAD; i < 5; i += M_FPS) {
            if (hit(this.listRows[i], motionEvent)) {
                if (this.winOpen[i]) {
                    hideWin(i);
                } else {
                    showWin(i);
                }
                return true;
            }
        }
        if (hit(this.listQuit, motionEvent)) {
            stopSelf();
        }
        return true;
    }

    private void syncList() {
        for (int i = M_LOAD; i < 5; i += M_FPS) {
            String str = this.winOpen[i] ? "✓ " : "✗ ";
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
            int length = spannableStringBuilder.length();
            spannableStringBuilder.append((CharSequence) str);
            spannableStringBuilder.setSpan(new ForegroundColorSpan(this.winOpen[i] ? COL_GREEN : -11115661), length, spannableStringBuilder.length(), 33);
            int length2 = spannableStringBuilder.length();
            spannableStringBuilder.append((CharSequence) MON_LABELS[i]);
            spannableStringBuilder.setSpan(new ForegroundColorSpan(this.winOpen[i] ? COL_VALUE : COL_DIM), length2, spannableStringBuilder.length(), 33);
            this.listRows[i].setText(spannableStringBuilder);
        }
    }

    private void buildLoadWin() {
        LinearLayout mkBox = mkBox(dp(14.0f), 10, 8);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(M_LOAD);
        this.rings = new RingsView();
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.rightMargin = dp(12.0f);
        linearLayout.addView(this.rings, layoutParams);
        LinearLayout linearLayout2 = new LinearLayout(this);
        this.detailBox = linearLayout2;
        linearLayout2.setOrientation(M_FPS);
        this.rowRam = mkText("", COL_VALUE, 10.0f);
        this.rowCpu = mkText("", COL_VALUE, 10.0f);
        LinearLayout linearLayout3 = new LinearLayout(this);
        this.clusterBox = linearLayout3;
        linearLayout3.setOrientation(M_FPS);
        this.rowGpu = mkText("", COL_VALUE, 10.0f);
        this.rowBat = mkText("", COL_VALUE, 10.0f);
        this.detailBox.addView(this.rowRam);
        this.detailBox.addView(this.rowCpu);
        this.detailBox.addView(this.clusterBox);
        this.detailBox.addView(this.rowGpu);
        this.detailBox.addView(this.rowBat);
        linearLayout.addView(this.detailBox);
        mkBox.addView(linearLayout);
        applyExpanded();
        this.win[M_LOAD] = mkBox;
        this.wlp[M_LOAD] = overlayLp(8388659);
        this.wlp[M_LOAD].x = dp(14.0f);
        this.wlp[M_LOAD].y = dp(110.0f);
        mkBox.setOnTouchListener(new WinTouch(M_LOAD));
    }

    private void applyExpanded() {
        this.rings.setVertical(this.expanded);
        this.detailBox.setVisibility(this.expanded ? M_LOAD : 8);
    }

    public void setExpanded(boolean z) {
        if (this.expanded == z) {
            return;
        }
        this.expanded = z;
        getSharedPreferences("colorfc", M_LOAD).edit().putBoolean("mon_expanded", z).apply();
        applyExpanded();
        updateUi();
    }

    private void buildFpsWin() {
        LinearLayout mkBox = mkBox(dp(12.0f), 10, 6);
        TextView mkText = mkText("#FPS --", COL_VALUE, 11.0f);
        this.fpsText = mkText;
        mkBox.addView(mkText);
        this.win[M_FPS] = mkBox;
        this.wlp[M_FPS] = overlayLp(8388659);
        this.wlp[M_FPS].x = dp(14.0f);
        this.wlp[M_FPS].y = dp(260.0f);
        mkBox.setOnTouchListener(new WinTouch(M_FPS));
    }

    private void buildThrWin() {
        LinearLayout mkBox = mkBox(dp(12.0f), 10, 6);
        mkBox.addView(mkText("线程 TOP6", COL_LABEL, 9.0f));
        for (int i = M_LOAD; i < 6; i += M_FPS) {
            this.thrRows[i] = mkText("--", COL_VALUE, 10.0f);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.topMargin = dp(2.0f);
            this.thrRows[i].setLayoutParams(layoutParams);
            mkBox.addView(this.thrRows[i]);
        }
        this.win[M_THR] = mkBox;
        this.wlp[M_THR] = overlayLp(8388659);
        this.wlp[M_THR].x = dp(14.0f);
        this.wlp[M_THR].y = dp(340.0f);
        mkBox.setOnTouchListener(new WinTouch(M_THR));
    }

    private void buildTempWin() {
        LinearLayout mkBox = mkBox(dp(12.0f), 10, 6);
        TextView mkText = mkText("--", COL_VALUE, 10.0f);
        this.tempText = mkText;
        mkBox.addView(mkText);
        this.win[3] = mkBox;
        this.wlp[3] = overlayLp(8388659);
        this.wlp[3].x = dp(14.0f);
        this.wlp[3].y = dp(420.0f);
        mkBox.setOnTouchListener(new WinTouch(3));
    }

    private void buildPwrWin() {
        LinearLayout mkBox = mkBox(dp(12.0f), 10, 6);
        TextView mkText = mkText("--W", COL_VALUE, 11.0f);
        this.pwrBig = mkText;
        mkBox.addView(mkText);
        this.win[M_PWR] = mkBox;
        this.wlp[M_PWR] = overlayLp(8388659);
        this.wlp[M_PWR].x = dp(14.0f);
        this.wlp[M_PWR].y = dp(500.0f);
        mkBox.setOnTouchListener(new WinTouch(M_PWR));
    }

    /* loaded from: classes.dex */
    public class WinTouch implements View.OnTouchListener {
        private long downAt;
        private float dx;
        private float dy;
        private final int idx;
        private boolean longFired;
        private final Runnable longRun = new Runnable() { // from class: Color.fc.MonitorService.WinTouch.1
            AnonymousClass1() {
            }

            @Override // java.lang.Runnable
            public void run() {
                if (WinTouch.this.moved) {
                    return;
                }
                WinTouch.this.longFired = true;
                MonitorService.this.toggleLock();
            }
        };
        private boolean moved;
        private float sx;
        private float sy;

        /* JADX INFO: Access modifiers changed from: package-private */
        /* renamed from: Color.fc.MonitorService$WinTouch$1 */
        /* loaded from: classes.dex */
        public class AnonymousClass1 implements Runnable {
            AnonymousClass1() {
            }

            @Override // java.lang.Runnable
            public void run() {
                if (WinTouch.this.moved) {
                    return;
                }
                WinTouch.this.longFired = true;
                MonitorService.this.toggleLock();
            }
        }

        WinTouch(int i) {
            this.idx = i;
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) view.getLayoutParams();
            int action = motionEvent.getAction();
            if (action == 0) {
                this.sx = motionEvent.getRawX();
                this.sy = motionEvent.getRawY();
                this.dx = this.sx - layoutParams.x;
                this.dy = this.sy - layoutParams.y;
                this.downAt = System.currentTimeMillis();
                this.moved = false;
                this.longFired = false;
                MonitorService.this.ui.postDelayed(this.longRun, 500L);
                return true;
            }
            if (action != MonitorService.M_FPS) {
                if (action == MonitorService.M_THR) {
                    if (Math.abs(motionEvent.getRawX() - this.sx) > MonitorService.this.dp(12.0f) || Math.abs(motionEvent.getRawY() - this.sy) > MonitorService.this.dp(12.0f)) {
                        this.moved = true;
                        MonitorService.this.ui.removeCallbacks(this.longRun);
                    }
                    if (!MonitorService.this.locked && !this.longFired) {
                        layoutParams.x = (int) (motionEvent.getRawX() - this.dx);
                        layoutParams.y = (int) (motionEvent.getRawY() - this.dy);
                        try {
                            MonitorService.this.wm.updateViewLayout(view, layoutParams);
                        } catch (Exception unused) {
                        }
                    }
                    return true;
                }
                if (action != 3) {
                    return false;
                }
            }
            MonitorService.this.ui.removeCallbacks(this.longRun);
            if (!this.longFired && !this.moved && System.currentTimeMillis() - this.downAt < 350) {
                onTap(motionEvent);
            }
            return true;
        }

        private void onTap(MotionEvent motionEvent) {
            long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis - MonitorService.this.lastTapAt < 300) {
                MonitorService.this.lastTapAt = 0L;
                if (MonitorService.this.pendingTap != null) {
                    MonitorService.this.ui.removeCallbacks(MonitorService.this.pendingTap);
                    MonitorService.this.pendingTap = null;
                }
                MonitorService.this.hideWin(this.idx);
                return;
            }
            MonitorService.this.lastTapAt = currentTimeMillis;
            MonitorService.this.pendingTap = new Runnable() { // from class: Color.fc.MonitorService$WinTouch$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    MonitorService.WinTouch.this.lambda$onTap$0();
                }
            };
            MonitorService.this.ui.postDelayed(MonitorService.this.pendingTap, 300L);
        }

        public /* synthetic */ void lambda$onTap$0() {
            MonitorService.this.pendingTap = null;
            int i = this.idx;
            if (i == 0) {
                MonitorService monitorService = MonitorService.this;
                monitorService.setExpanded(MonitorService.M_FPS ^ monitorService.expanded);
            } else {
                if (i != MonitorService.M_FPS) {
                    return;
                }
                MonitorService.this.toggleRec();
            }
        }
    }

    public void toggleLock() {
        boolean z = !this.locked;
        this.locked = z;
        Toast.makeText(this, z ? "位置已锁定 · 再次长按解锁" : "位置已解锁，可自由拖动", M_LOAD).show();
        if (this.locked || !this.pillHidden) {
            return;
        }
        showPill();
    }

    /* loaded from: classes.dex */
    public class RingsView extends View {
        private String iB;
        private String iC;
        private String iG;
        private float pB;
        private float pC;
        private float pG;
        private final RectF rect;
        private String sB;
        private String sC;
        private String sG;
        private boolean vertical;

        RingsView() {
            super(MonitorService.this);
            this.vertical = false;
            this.iC = "--";
            this.iG = "--";
            this.iB = "--";
            this.sC = "--";
            this.sG = "--";
            this.sB = "--";
            this.rect = new RectF();
        }

        void setVertical(boolean z) {
            this.vertical = z;
            requestLayout();
        }

        void data(float f, String str, String str2, float f2, String str3, String str4, float f3, String str5, String str6) {
            this.pC = f;
            this.iC = str;
            this.sC = str2;
            this.pG = f2;
            this.iG = str3;
            this.sG = str4;
            this.pB = f3;
            this.iB = str5;
            this.sB = str6;
            invalidate();
        }

        @Override // android.view.View
        protected void onMeasure(int i, int i2) {
            int dp = MonitorService.this.dp(34.0f);
            int dp2 = MonitorService.this.dp(12.0f);
            int dp3 = MonitorService.this.dp(13.0f);
            if (this.vertical) {
                setMeasuredDimension(dp, ((dp3 + dp) * 3) + (MonitorService.this.dp(8.0f) * MonitorService.M_THR));
            } else {
                setMeasuredDimension((dp * 3) + (dp2 * MonitorService.M_THR), dp + dp3);
            }
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            float[] fArr;
            String[] strArr;
            float f;
            int dp = MonitorService.this.dp(34.0f);
            int dp2 = MonitorService.this.dp(13.0f);
            int dp3 = MonitorService.this.dp(12.0f);
            float dp4 = MonitorService.this.dp(3.0f);
            float f2 = dp;
            float f3 = f2 / 2.0f;
            float f4 = f3 - (dp4 / 2.0f);
            Paint paint = new Paint(MonitorService.M_FPS);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp4);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(654311423);
            Paint paint2 = new Paint(paint);
            Paint paint3 = new Paint(MonitorService.M_FPS);
            paint3.setColor(MonitorService.COL_VALUE);
            paint3.setTextSize(MonitorService.this.dp(8.0f));
            paint3.setTextAlign(Paint.Align.CENTER);
            Paint paint4 = new Paint(MonitorService.M_FPS);
            paint4.setColor(-5195580);
            paint4.setTextSize(MonitorService.this.dp(8.5f));
            paint4.setTextAlign(Paint.Align.CENTER);
            float f5 = this.pC;
            float f6 = this.pG;
            float f7 = this.pB;
            Paint paint5 = paint3;
            Paint paint6 = paint4;
            float[] fArr2 = {f5, f6, f7};
            int[] iArr = {MonitorService.COL_GREEN, MonitorService.COL_GREEN, f7 <= 25.0f ? MonitorService.COL_ORANGE : MonitorService.COL_GREEN};
            String[] strArr2 = {this.iC, this.iG, this.iB};
            String[] strArr3 = {this.sC, this.sG, this.sB};
            int i = MonitorService.M_LOAD;
            int i2 = 3;
            while (i < i2) {
                boolean z = this.vertical;
                float f8 = z ? f3 : (i * (dp + dp3)) + f3;
                if (z) {
                    fArr = fArr2;
                    strArr = strArr3;
                    f = ((dp + dp2 + MonitorService.this.dp(8.0f)) * i) + f3;
                } else {
                    fArr = fArr2;
                    strArr = strArr3;
                    f = f3;
                }
                float dp5 = this.vertical ? (dp + dp2 + MonitorService.this.dp(8.0f)) * i : 0.0f;
                int i3 = i;
                float f9 = f8;
                this.rect.set(f8 - f4, f - f4, f8 + f4, f + f4);
                Paint paint7 = paint6;
                float[] fArr3 = fArr;
                String[] strArr4 = strArr2;
                String[] strArr5 = strArr;
                Paint paint8 = paint5;
                int i4 = dp;
                Paint paint9 = paint2;
                canvas.drawArc(this.rect, 0.0f, 360.0f, false, paint);
                paint9.setColor(iArr[i3]);
                float max = Math.max(0.0f, Math.min(100.0f, fArr3[i3]));
                if (max > 0.5f) {
                    canvas.drawArc(this.rect, -90.0f, max * 3.6f, false, paint9);
                }
                canvas.drawText(strArr4[i3], f9, f + MonitorService.this.dp(3.0f), paint8);
                canvas.drawText(strArr5[i3], f9, dp5 + f2 + MonitorService.this.dp(10.0f), paint7);
                i = i3 + MonitorService.M_FPS;
                paint5 = paint8;
                fArr2 = fArr3;
                strArr3 = strArr5;
                i2 = 3;
                paint6 = paint7;
                paint2 = paint9;
                strArr2 = strArr4;
                dp = i4;
            }
        }
    }

    private void setRow(TextView textView, String str, String str2, int i) {
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        int length = spannableStringBuilder.length();
        spannableStringBuilder.append((CharSequence) str);
        spannableStringBuilder.setSpan(new ForegroundColorSpan(COL_LABEL), length, spannableStringBuilder.length(), 33);
        spannableStringBuilder.append(' ');
        int length2 = spannableStringBuilder.length();
        spannableStringBuilder.append((CharSequence) str2);
        spannableStringBuilder.setSpan(new ForegroundColorSpan(i), length2, spannableStringBuilder.length(), 33);
        textView.setText(spannableStringBuilder);
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0045  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x00d6  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00c9  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x009c  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0049  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void updateUi() {
        /*
            Method dump skipped, instructions count: 764
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: Color.fc.MonitorService.updateUi():void");
    }

    private void appendTemp(SpannableStringBuilder spannableStringBuilder, String str, double d) {
        int length = spannableStringBuilder.length();
        spannableStringBuilder.append((CharSequence) str);
        spannableStringBuilder.setSpan(new ForegroundColorSpan(COL_LABEL), length, spannableStringBuilder.length(), 33);
        spannableStringBuilder.append(' ');
        int length2 = spannableStringBuilder.length();
        spannableStringBuilder.append((CharSequence) (d > 0.0d ? String.format(Locale.US, "%.1f℃", Double.valueOf(d)) : "--"));
        spannableStringBuilder.setSpan(new ForegroundColorSpan(tColor(d)), length2, spannableStringBuilder.length(), 33);
    }

    private TextView[] clusterRows() {
        int childCount = this.clusterBox.getChildCount();
        TextView[] textViewArr = new TextView[childCount];
        for (int i = M_LOAD; i < childCount; i += M_FPS) {
            textViewArr[i] = (TextView) this.clusterBox.getChildAt(i);
        }
        return textViewArr;
    }

    private void ensureClusterRows() {
        if (this.rowsBuilt == this.nCluster || this.nCluster <= 0) {
            return;
        }
        this.clusterBox.removeAllViews();
        for (int i = M_LOAD; i < this.nCluster && i < 3; i += M_FPS) {
            this.clusterBox.addView(mkText("--", COL_VALUE, 10.0f));
        }
        this.rowsBuilt = this.nCluster;
    }

    public void fastLoop() {
        new Thread(new Runnable() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                MonitorService.this.lambda$fastLoop$2();
            }
        }).start();
    }

    public /* synthetic */ void lambda$fastLoop$2() {
        try {
            PowerMonitor.BatteryStat readOnce = PowerMonitor.readOnce();
            if (readOnce != null) {
                this.cW = PowerMonitor.applyCellMode(readOnce, this.cellMode);
                this.cV = readOnce.volts;
                this.cA = readOnce.amps;
                this.cBatT = readOnce.tempC;
                readOnce.watts = this.cW;
                PowerHistoryManager.record(this, readOnce);
            } else {
                this.cW = -1.0d;
                this.cV = -1.0d;
                this.cA = -1.0d;
            }
        } catch (Exception unused) {
        }
        readBattery();
        if (this.winOpen[M_LOAD]) {
            this.cBusy = readCpuBusy();
            aggClusters(readCores());
        }
        if (this.winOpen[M_FPS] || this.recording) {
            this.cHz = currentFps();
        }
        this.ui.post(new MonitorService$$ExternalSyntheticLambda1(this));
        this.ui.postDelayed(new MonitorService$$ExternalSyntheticLambda13(this), 500L);
    }

    private void readBattery() {
        try {
            Intent registerReceiver = registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
            if (registerReceiver != null) {
                int intExtra = registerReceiver.getIntExtra("level", -1);
                int intExtra2 = registerReceiver.getIntExtra("scale", -1);
                if (intExtra < 0 || intExtra2 <= 0) {
                    return;
                }
                this.batPct = (intExtra * 100.0f) / intExtra2;
            }
        } catch (Exception unused) {
        }
    }

    private void aggClusters(float[] fArr) {
        if (fArr == null) {
            return;
        }
        if (this.clMap == null || this.nCluster <= 0) {
            int length = fArr.length;
            float f = M_LOAD;
            for (int i = M_LOAD; i < length; i += M_FPS) {
                f += fArr[i];
            }
            this.clBusy[M_LOAD] = fArr.length > 0 ? f / fArr.length : 0.0f;
            return;
        }
        for (int i2 = M_LOAD; i2 < this.nCluster; i2 += M_FPS) {
            int[][] iArr = this.clMap;
            if (i2 >= iArr.length) {
                return;
            }
            int[] iArr2 = iArr[i2];
            int length2 = iArr2.length;
            float f2 = M_LOAD;
            int i3 = M_LOAD;
            int i4 = i3;
            while (i3 < length2) {
                int i5 = iArr2[i3];
                if (i5 >= 0 && i5 < fArr.length) {
                    f2 += fArr[i5];
                    i4 += M_FPS;
                }
                i3 += M_FPS;
            }
            this.clBusy[i2] = i4 > 0 ? f2 / i4 : M_LOAD;
        }
    }

    public void slowLoop() {
        new Thread(new Runnable() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                MonitorService.this.lambda$slowLoop$3();
            }
        }).start();
    }

    public /* synthetic */ void lambda$slowLoop$3() {
        double d;
        boolean[] zArr = this.winOpen;
        if (zArr[M_LOAD] || zArr[3]) {
            String str = "";
            try {
                RootShell.Result exec = RootShell.exec(SCAN);
                if (exec.ok() && exec.out != null) {
                    str = exec.out;
                }
            } catch (Exception unused) {
            }
            String[] split = str.split("\\n");
            int length = split.length;
            int i = M_LOAD;
            int i2 = i;
            while (true) {
                if (i >= length) {
                    break;
                }
                String str2 = split[i];
                if (str2.startsWith("G:")) {
                    double parseGpu = parseGpu(str2);
                    this.cGpuM = parseGpu > 0.0d ? parseGpu / 1000000.0d : 0.0d;
                } else if (str2.startsWith("GL:")) {
                    this.gpuLoad = parseGpuLoad(str2);
                } else if (str2.startsWith("GM:")) {
                    double parseGpuMax = parseGpuMax(str2);
                    if (parseGpuMax > 0.0d) {
                        this.gpuMax = parseGpuMax;
                    }
                } else if (str2.startsWith("Q:")) {
                    try {
                        double parseDouble = Double.parseDouble(str2.substring(M_THR).trim());
                        if (i2 < 3) {
                            this.clFreq[i2] = parseDouble / 1000.0d;
                        }
                    } catch (Exception unused2) {
                    }
                    i2 += M_FPS;
                } else if (str2.startsWith("R:") && this.clMap == null) {
                    buildClusterMap(str2.substring(M_THR));
                }
                i += M_FPS;
            }
            if (this.nCluster <= 0) {
                this.nCluster = Math.min(3, Math.max(M_FPS, i2));
            }
            for (int i3 = M_LOAD; i3 < this.nCluster; i3 += M_FPS) {
                d = Math.max(d, this.clFreq[i3]);
            }
            this.cCpuM = d;
            double parseZoneTemp = parseZoneTemp(str, "cpu", this.cBatT);
            this.cCpuT = parseZoneTemp;
            this.cSocT = parseZoneTemp(str, "soc", parseZoneTemp);
            readMem();
        }
        this.ui.post(new MonitorService$$ExternalSyntheticLambda1(this));
        this.ui.postDelayed(new MonitorService$$ExternalSyntheticLambda14(this), 2000L);
    }

    private void buildClusterMap(String str) {
        try {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            String[] split = str.split(";");
            int length = split.length;
            int i = M_LOAD;
            for (int i2 = M_LOAD; i2 < length; i2 += M_FPS) {
                String trim = split[i2].trim();
                if (!trim.isEmpty()) {
                    String[] split2 = trim.split("\\s+");
                    int length2 = split2.length;
                    int[] iArr = new int[length2];
                    for (int i3 = M_LOAD; i3 < split2.length; i3 += M_FPS) {
                        iArr[i3] = Integer.parseInt(split2[i3].trim());
                    }
                    if (length2 != 0) {
                        arrayList.add(iArr);
                        arrayList2.add(iArr[M_LOAD] + "-" + iArr[length2 - 1]);
                        if (arrayList.size() >= 3) {
                            break;
                        }
                    }
                }
            }
            if (arrayList.isEmpty()) {
                return;
            }
            this.clMap = (int[][]) arrayList.toArray(new int[M_LOAD]);
            while (true) {
                int[][] iArr2 = this.clMap;
                if (i >= iArr2.length) {
                    this.nCluster = iArr2.length;
                    return;
                } else {
                    this.clLbl[i] = (String) arrayList2.get(i);
                    i += M_FPS;
                }
            }
        } catch (Exception unused) {
        }
    }

    private void readMem() {
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader("/proc/meminfo"));
            long j = -1;
            long j2 = -1;
            while (true) {
                try {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        break;
                    }
                    if (j < 0 && readLine.startsWith("MemTotal:")) {
                        j = Long.parseLong(readLine.split("\\s+")[M_FPS]);
                    } else if (j2 < 0 && readLine.startsWith("MemAvailable:")) {
                        j2 = Long.parseLong(readLine.split("\\s+")[M_FPS]);
                    } else if (j >= 0 && j2 >= 0) {
                        break;
                    }
                } finally {
                }
            }
            if (j > 0 && j2 >= 0) {
                float f = (float) (j - j2);
                this.ramPct = (100.0f * f) / ((float) j);
                this.ramUsedG = f / 1048576.0f;
            }
            bufferedReader.close();
        } catch (Exception unused) {
        }
    }

    public void threadLoop() {
        new Thread(new Runnable() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                MonitorService.this.lambda$threadLoop$4();
            }
        }).start();
    }

    public /* synthetic */ void lambda$threadLoop$4() {
        if (this.winOpen[M_THR]) {
            sampleThreads();
        }
        this.ui.postDelayed(new MonitorService$$ExternalSyntheticLambda15(this), 250L);
    }

    private void sampleThreads() {
        HashMap hashMap;
        try {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            char c = 0;
            if (this.thrPid <= 0 || elapsedRealtime - this.thrPidAt > 4000) {
                RootShell.Result exec = RootShell.exec("f=$(dumpsys window 2>/dev/null | grep -m1 -E 'mCurrentFocus|mFocusedApp');p=$(echo \"$f\" | grep -oE '[A-Za-z0-9_.]+/' | head -1); p=${p%/};echo \"K:$(getconf CLK_TCK 2>/dev/null)\";pid=$(pidof \"$p\" 2>/dev/null | cut -d' ' -f1); echo \"I:$pid\";", 8);
                if (exec.ok() && exec.out != null) {
                    String[] split = exec.out.split("\\n");
                    int length = split.length;
                    for (int i = M_LOAD; i < length; i += M_FPS) {
                        String trim = split[i].trim();
                        if (trim.startsWith("K:")) {
                            try {
                                double parseDouble = Double.parseDouble(trim.substring(M_THR).trim());
                                if (parseDouble > 0.0d) {
                                    this.thrTck = parseDouble;
                                }
                            } catch (Exception unused) {
                            }
                        } else if (trim.startsWith("I:")) {
                            try {
                                this.thrPid = Integer.parseInt(trim.substring(M_THR).trim());
                            } catch (Exception unused2) {
                                this.thrPid = M_LOAD;
                            }
                        }
                    }
                }
                this.thrPidAt = elapsedRealtime;
                if (this.thrPid <= 0) {
                    return;
                }
            }
            RootShell.Result exec2 = RootShell.exec("if [ -d /proc/" + this.thrPid + " ]; then echo TZQ7_; awk '{n=split(FILENAME,a,\"/\"); print a[n-1] \" \" $14+$15}' /proc/" + this.thrPid + "/task/*/stat 2>/dev/null; echo NZQ7_; cat /proc/" + this.thrPid + "/task/*/comm 2>/dev/null; echo EZQ7_; else echo DEADZQ7_; fi", M_PWR);
            if (exec2.ok() && exec2.out != null) {
                long elapsedRealtime2 = SystemClock.elapsedRealtime();
                HashMap hashMap2 = new HashMap();
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                String[] split2 = exec2.out.split("\\n");
                int length2 = split2.length;
                int i2 = M_LOAD;
                int i3 = i2;
                while (true) {
                    String str = "?";
                    if (i2 >= length2) {
                        break;
                    }
                    String str2 = split2[i2];
                    if (str2.equals("TZQ7_")) {
                        i3 = M_FPS;
                    } else if (str2.equals("NZQ7_")) {
                        i3 = M_THR;
                    } else {
                        if (str2.equals("EZQ7_")) {
                            break;
                        }
                        if (str2.equals("DEADZQ7_")) {
                            this.thrPid = M_LOAD;
                            return;
                        }
                        if (i3 == M_FPS) {
                            int indexOf = str2.indexOf(32);
                            if (indexOf > 0) {
                                try {
                                    int parseInt = Integer.parseInt(str2.substring(M_LOAD, indexOf).trim());
                                    hashMap2.put(Integer.valueOf(parseInt), new long[]{Long.parseLong(str2.substring(indexOf + M_FPS).trim())});
                                    arrayList.add(Integer.valueOf(parseInt));
                                } catch (Exception unused3) {
                                }
                            }
                        } else if (i3 == M_THR) {
                            String trim2 = str2.trim();
                            if (!trim2.isEmpty()) {
                                str = trim2;
                            }
                            arrayList2.add(str);
                        }
                    }
                    i2 += M_FPS;
                }
                if (hashMap2.isEmpty()) {
                    return;
                }
                HashMap hashMap3 = new HashMap();
                for (int i4 = M_LOAD; i4 < arrayList.size() && i4 < arrayList2.size(); i4 += M_FPS) {
                    hashMap3.put((Integer) arrayList.get(i4), (String) arrayList2.get(i4));
                }
                if (this.thrPrev != null) {
                    if (elapsedRealtime2 > this.thrLastAt) {
                        double d = (elapsedRealtime2 - r8) / 1000.0d;
                        ArrayList arrayList3 = new ArrayList();
                        for (Map.Entry entry : hashMap2.entrySet()) {
                            long[] jArr = this.thrPrev.get(entry.getKey());
                            if (jArr != null) {
                                long j = ((long[]) entry.getValue())[c] - jArr[c];
                                if (j > 0) {
                                    arrayList3.add(new double[]{Math.min(999.0d, ((j / this.thrTck) / d) * 100.0d), ((Integer) entry.getKey()).intValue()});
                                    hashMap2 = hashMap2;
                                    c = 0;
                                }
                            }
                        }
                        HashMap hashMap4 = hashMap2;
                        arrayList3.sort(Comparator.comparingDouble(new ToDoubleFunction() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda10
                            @Override // java.util.function.ToDoubleFunction
                            public final double applyAsDouble(Object obj) {
                                return MonitorService.lambda$sampleThreads$5((double[]) obj);
                            }
                        }));
                        List subList = arrayList3.subList(M_LOAD, Math.min(6, arrayList3.size()));
                        final String[] strArr = new String[6];
                        for (int i5 = M_LOAD; i5 < 6; i5 += M_FPS) {
                            if (i5 < subList.size()) {
                                double d2 = ((double[]) subList.get(i5))[M_LOAD];
                                String str3 = (String) hashMap3.get(Integer.valueOf((int) ((double[]) subList.get(i5))[M_FPS]));
                                if (str3 == null) {
                                    str3 = "?";
                                }
                                if (str3.length() > 14) {
                                    str3 = str3.substring(M_LOAD, 14);
                                }
                                strArr[i5] = String.format(Locale.US, "%s %.0f%%", str3, Double.valueOf(d2));
                            } else {
                                strArr[i5] = null;
                            }
                        }
                        this.ui.post(new Runnable() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda11
                            @Override // java.lang.Runnable
                            public final void run() {
                                MonitorService.this.lambda$sampleThreads$6(strArr);
                            }
                        });
                        hashMap = hashMap4;
                        this.thrPrev = hashMap;
                        this.thrLastAt = elapsedRealtime2;
                    }
                }
                hashMap = hashMap2;
                this.thrPrev = hashMap;
                this.thrLastAt = elapsedRealtime2;
            }
        } catch (Exception unused4) {
        }
    }

    public static /* synthetic */ double lambda$sampleThreads$5(double[] dArr) {
        return -dArr[M_LOAD];
    }

    public /* synthetic */ void lambda$sampleThreads$6(String[] strArr) {
        for (int i = M_LOAD; i < 6; i += M_FPS) {
            String str = strArr[i];
            if (str != null) {
                int lastIndexOf = str.lastIndexOf(32);
                SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
                int length = spannableStringBuilder.length();
                spannableStringBuilder.append((CharSequence) strArr[i].substring(M_LOAD, lastIndexOf));
                spannableStringBuilder.setSpan(new ForegroundColorSpan(COL_LABEL), length, spannableStringBuilder.length(), 33);
                spannableStringBuilder.append(' ');
                int length2 = spannableStringBuilder.length();
                String str2 = strArr[i];
                int i2 = lastIndexOf + M_FPS;
                spannableStringBuilder.append((CharSequence) str2.substring(i2));
                double parseDouble = Double.parseDouble(strArr[i].substring(i2).replace("%", ""));
                spannableStringBuilder.setSpan(new ForegroundColorSpan(parseDouble >= 80.0d ? COL_RED : parseDouble >= 50.0d ? -680437 : COL_VALUE), length2, spannableStringBuilder.length(), 33);
                this.thrRows[i].setText(spannableStringBuilder);
            }
        }
    }

    public void toggleRec() {
        if (!this.recording) {
            this.recording = true;
            this.recStart = System.currentTimeMillis();
            this.recShown = 0L;
            this.ts.clear();
            this.fps.clear();
            this.cpuTot.clear();
            this.cores.clear();
            this.recLastIdle = -1L;
            this.recLastTotal = -1L;
            this.lastCoreIdle = null;
            Toast.makeText(this, "开始录制（至少 3 秒），再次点击停止并保存", M_LOAD).show();
            recSample();
            return;
        }
        stopRec(true);
    }

    private void stopRec(boolean z) {
        this.recording = false;
        long currentTimeMillis = System.currentTimeMillis() - this.recStart;
        final int size = this.ts.size();
        if (currentTimeMillis < MIN_REC_MS || size < M_PWR) {
            if (z) {
                Toast.makeText(this, "录制不足 3 秒，未保存", M_LOAD).show();
            }
        } else {
            if (z) {
                Toast.makeText(this, "录制完成，正在生成曲线图…", M_LOAD).show();
            }
            new Thread(new Runnable() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    MonitorService.this.lambda$stopRec$7(size);
                }
            }).start();
        }
    }

    public void recSample() {
        if (this.recording) {
            new Thread(new Runnable() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    MonitorService.this.lambda$recSample$8();
                }
            }).start();
        }
    }

    public /* synthetic */ void lambda$recSample$8() {
        float currentFps = currentFps();
        Double recCpuTotal = recCpuTotal();
        float[] readCores = readCores();
        if (this.recording) {
            long currentTimeMillis = System.currentTimeMillis();
            if (recCpuTotal != null && readCores != null) {
                this.ts.add(Long.valueOf(currentTimeMillis - this.recStart));
                this.fps.add(Float.valueOf(currentFps));
                this.cpuTot.add(Float.valueOf(recCpuTotal.floatValue()));
                this.cores.add(readCores);
            }
            this.cHz = currentFps;
            this.recShown = currentTimeMillis - this.recStart;
            this.ui.post(new MonitorService$$ExternalSyntheticLambda1(this));
            this.ui.postDelayed(new Runnable() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    MonitorService.this.recSample();
                }
            }, 500L);
        }
    }

    private Double recCpuTotal() {
        BufferedReader bufferedReader;
        String readLine;
        try {
            bufferedReader = new BufferedReader(new FileReader("/proc/stat"));
            try {
                readLine = bufferedReader.readLine();
            } finally {
            }
        } catch (Exception unused) {
        }
        if (readLine != null && readLine.startsWith("cpu ")) {
            String[] split = readLine.split("\\s+");
            long parseLong = Long.parseLong(split[M_PWR]) + Long.parseLong(split[5]);
            long j = 0;
            for (int i = M_FPS; i < split.length; i += M_FPS) {
                j += Long.parseLong(split[i]);
            }
            if (this.recLastIdle >= 0) {
                if (j > this.recLastTotal) {
                    this.recLastIdle = parseLong;
                    this.recLastTotal = j;
                    Double valueOf = Double.valueOf(Math.max(0.0d, Math.min(100.0d, (((j - r5) - (parseLong - r10)) * 100.0d) / (j - r5))));
                    bufferedReader.close();
                    return valueOf;
                }
            }
            this.recLastIdle = parseLong;
            this.recLastTotal = j;
            bufferedReader.close();
            return null;
        }
        bufferedReader.close();
        return null;
    }

    private float[] readCores() {
        long j;
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader("/proc/stat"));
            try {
                ArrayList arrayList = new ArrayList();
                while (true) {
                    String readLine = bufferedReader.readLine();
                    j = 0;
                    if (readLine == null) {
                        break;
                    }
                    if (readLine.startsWith("cpu") && !readLine.startsWith("cpu ")) {
                        String[] split = readLine.split("\\s+");
                        long parseLong = Long.parseLong(split[M_PWR]) + Long.parseLong(split[5]);
                        for (int i = M_FPS; i < split.length; i += M_FPS) {
                            j += Long.parseLong(split[i]);
                        }
                        arrayList.add(new long[]{parseLong, j});
                    }
                }
                int size = arrayList.size();
                this.coreCount = Math.max(this.coreCount, size);
                if (size != 0) {
                    long[] jArr = this.lastCoreIdle;
                    if (jArr != null && jArr.length == size) {
                        float[] fArr = new float[size];
                        int i2 = M_LOAD;
                        while (i2 < size) {
                            long j2 = ((long[]) arrayList.get(i2))[M_LOAD] - this.lastCoreIdle[i2];
                            long j3 = ((long[]) arrayList.get(i2))[M_FPS] - this.lastCoreTotal[i2];
                            fArr[i2] = j3 > j ? (float) Math.max(0.0d, Math.min(100.0d, ((j3 - j2) * 100.0d) / j3)) : 0.0f;
                            this.lastCoreIdle[i2] = ((long[]) arrayList.get(i2))[M_LOAD];
                            this.lastCoreTotal[i2] = ((long[]) arrayList.get(i2))[M_FPS];
                            i2 += M_FPS;
                            j = 0;
                        }
                        bufferedReader.close();
                        return fArr;
                    }
                    this.lastCoreIdle = new long[size];
                    this.lastCoreTotal = new long[size];
                    for (int i3 = M_LOAD; i3 < size; i3 += M_FPS) {
                        this.lastCoreIdle[i3] = ((long[]) arrayList.get(i3))[M_LOAD];
                        this.lastCoreTotal[i3] = ((long[]) arrayList.get(i3))[M_FPS];
                    }
                    bufferedReader.close();
                    return null;
                }
                bufferedReader.close();
                return null;
            } finally {
            }
        } catch (Exception unused) {
            return null;
        }
    }

    /* renamed from: saveChart */
    public void lambda$stopRec$7(int i) {
        try {
            Bitmap renderChart = renderChart(i);
            String str = "rec_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date(this.recStart)) + ".png";
            String[] writePng = writePng(renderChart, str);
            if (writePng != null) {
                FrameRecordStore.add(this, this.recStart, this.ts.get(i - 1).longValue(), i, this.coreCount, this.fps, this.cpuTot, writePng[M_FPS], str);
                final String str2 = "已保存: " + writePng[M_LOAD];
                this.ui.post(new Runnable() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() {
                        MonitorService.this.lambda$saveChart$9(str2);
                    }
                });
            } else {
                this.ui.post(new Runnable() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda5
                    @Override // java.lang.Runnable
                    public final void run() {
                        MonitorService.this.lambda$saveChart$10();
                    }
                });
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: Color.fc.MonitorService$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    MonitorService.this.lambda$saveChart$11(e);
                }
            });
        }
    }

    public /* synthetic */ void lambda$saveChart$9(String str) {
        Toast.makeText(this, str, M_FPS).show();
    }

    public /* synthetic */ void lambda$saveChart$10() {
        Toast.makeText(this, "保存失败", M_FPS).show();
    }

    public /* synthetic */ void lambda$saveChart$11(Exception exc) {
        Toast.makeText(this, "保存失败: " + exc, M_FPS).show();
    }

    private String[] writePng(Bitmap bitmap, String str) {
        File file;
        FileOutputStream fileOutputStream;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("_display_name", str);
            contentValues.put("mime_type", "image/png");
            contentValues.put("relative_path", "Pictures/ColorFC");
            Uri insert = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
            if (insert != null) {
                OutputStream openOutputStream = getContentResolver().openOutputStream(insert);
                try {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, openOutputStream);
                    if (openOutputStream != null) {
                        openOutputStream.close();
                    }
                    return new String[]{"Pictures/ColorFC/" + str, insert.toString()};
                } finally {
                }
            }
            try {
                file = new File(getExternalFilesDir(null), "ColorFC");
                if (!file.isDirectory() || file.mkdirs()) {
                    File file2 = new File(file, str);
                    fileOutputStream = new FileOutputStream(file2);
                    try {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                        fileOutputStream.close();
                        return new String[]{file2.getAbsolutePath(), file2.getAbsolutePath()};
                    } finally {
                        try {
                            fileOutputStream.close();
                        } catch (Throwable th) {
                            th.addSuppressed(th);
                        }
                    }
                }
            } catch (Exception unused) {
            }
            return null;
        }
        File file3 = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "ColorFC");
        if (file3.isDirectory() || file3.mkdirs()) {
            File file4 = new File(file3, str);
            fileOutputStream = new FileOutputStream(file4);
            try {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                fileOutputStream.close();
                return new String[]{file4.getAbsolutePath(), file4.getAbsolutePath()};
            } finally {
            }
        }
        file = new File(getExternalFilesDir(null), "ColorFC");
        if (!file.isDirectory()) {
        }
        File file22 = new File(file, str);
        fileOutputStream = new FileOutputStream(file22);
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
        fileOutputStream.close();
        return new String[]{file22.getAbsolutePath(), file22.getAbsolutePath()};
    }

    private Bitmap renderChart(int i) {
        Bitmap createBitmap = Bitmap.createBitmap(1080, 1750, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        canvas.drawColor(-15919840);
        Paint paint = new Paint(M_FPS);
        paint.setColor(-1643021);
        paint.setTextSize(40.0f);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        Paint paint2 = new Paint(M_FPS);
        paint2.setColor(-7629666);
        paint2.setTextSize(26.0f);
        Paint paint3 = new Paint(M_FPS);
        paint3.setColor(-16718337);
        paint3.setTextSize(30.0f);
        paint3.setTypeface(Typeface.DEFAULT_BOLD);
        long longValue = this.ts.get(i - 1).longValue();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        canvas.drawText("帧率录制报告", 40.0f, 66.0f, paint);
        canvas.drawText(String.format(Locale.US, "%s ｜ 时长 %d:%02d ｜ 采样 %d 条", simpleDateFormat.format(new Date(this.recStart)), Long.valueOf(longValue / 60000), Long.valueOf((longValue / 1000) % 60), Integer.valueOf(i)), 40.0f, 108.0f, paint2);
        float f = 1000;
        canvas.drawText("实时帧率 (fps)", 40.0f, 184.0f, paint3);
        canvas.drawText(fpsStats(), 40.0f, 220.0f, paint2);
        drawSeries(canvas, 40.0f, 240.0f, f, 300.0f, new float[][]{toFloat(this.fps)}, new int[]{-16718337}, niceMax(maxOf(this.fps, 120.0f)));
        canvas.drawText("CPU 实时使用率 (%)", 40.0f, 644.0f, paint3);
        canvas.drawText(cpuStats(), 40.0f, 680.0f, paint2);
        drawSeries(canvas, 40.0f, 700.0f, f, 300.0f, new float[][]{toFloat(this.cpuTot)}, new int[]{-680437}, 100.0f);
        int min = Math.min(this.coreCount, 8);
        canvas.drawText("CPU 线程负载 (%)", 40.0f, 1104.0f, paint3);
        StringBuilder sb = new StringBuilder();
        float[][] fArr = new float[min];
        int[] iArr = new int[min];
        for (int i2 = M_LOAD; i2 < min; i2 += M_FPS) {
            fArr[i2] = coreSeries(i2);
            int[] iArr2 = CORE_COLORS;
            iArr[i2] = iArr2[i2 % iArr2.length];
            if (i2 > 0) {
                sb.append("  ");
            }
            sb.append("C").append(i2);
        }
        canvas.drawText(sb.toString(), 40.0f, 1140.0f, paint2);
        drawSeries(canvas, 40.0f, 1160.0f, f, 420.0f, fArr, iArr, 100.0f);
        return createBitmap;
    }

    private String fpsStats() {
        Iterator<Float> it = this.fps.iterator();
        float f = Float.MAX_VALUE;
        float f2 = M_LOAD;
        float f3 = f2;
        while (it.hasNext()) {
            float floatValue = it.next().floatValue();
            if (floatValue > 0.0f) {
                f = Math.min(f, floatValue);
                f3 = Math.max(f3, floatValue);
                f2 += floatValue;
            }
        }
        int size = this.fps.size();
        return String.format(Locale.US, "平均 %.1f ｜ 最低 %.0f ｜ 最高 %.0f", Float.valueOf(size > 0 ? f2 / size : M_LOAD), Float.valueOf(f != Float.MAX_VALUE ? f : 0.0f), Float.valueOf(f3));
    }

    private String cpuStats() {
        Iterator<Float> it = this.cpuTot.iterator();
        float f = M_LOAD;
        float f2 = f;
        while (it.hasNext()) {
            float floatValue = it.next().floatValue();
            f = Math.max(f, floatValue);
            f2 += floatValue;
        }
        int size = this.cpuTot.size();
        return String.format(Locale.US, "平均 %.1f%% ｜ 峰值 %.1f%%", Float.valueOf(size > 0 ? f2 / size : 0.0f), Float.valueOf(f));
    }

    private float[] toFloat(ArrayList<Float> arrayList) {
        int size = arrayList.size();
        float[] fArr = new float[size];
        for (int i = M_LOAD; i < size; i += M_FPS) {
            fArr[i] = arrayList.get(i).floatValue();
        }
        return fArr;
    }

    private float maxOf(ArrayList<Float> arrayList, float f) {
        Iterator<Float> it = arrayList.iterator();
        float f2 = M_LOAD;
        while (it.hasNext()) {
            f2 = Math.max(f2, it.next().floatValue());
        }
        return f2 > 0.0f ? f2 : f;
    }

    private float niceMax(float f) {
        if (f <= 30.0f) {
            return 30.0f;
        }
        if (f <= 60.0f) {
            return 60.0f;
        }
        if (f <= 90.0f) {
            return 90.0f;
        }
        if (f <= 120.0f) {
            return 120.0f;
        }
        if (f <= 144.0f) {
            return 144.0f;
        }
        return (float) (Math.ceil(f / 60.0d) * 60.0d);
    }

    private float[] coreSeries(int i) {
        float[] fArr = new float[this.cores.size()];
        for (int i2 = M_LOAD; i2 < this.cores.size(); i2 += M_FPS) {
            float[] fArr2 = this.cores.get(i2);
            fArr[i2] = i < fArr2.length ? fArr2[i] : 0.0f;
        }
        return fArr;
    }

    private void drawSeries(Canvas canvas, float f, float f2, float f3, float f4, float[][] fArr, int[] iArr, float f5) {
        String format;
        Paint paint = new Paint(M_FPS);
        paint.setColor(452984831);
        paint.setStrokeWidth(1.0f);
        Paint paint2 = new Paint(M_FPS);
        paint2.setColor(-13615795);
        paint2.setStrokeWidth(2.0f);
        Paint paint3 = new Paint(M_FPS);
        paint3.setColor(-9734267);
        paint3.setTextSize(22.0f);
        Paint paint4 = new Paint(M_FPS);
        paint4.setColor(-15655896);
        float f6 = f + f3;
        float f7 = f2 + f4;
        canvas.drawRoundRect(f - 16.0f, f2 - 12.0f, f6 + 16.0f, f7 + 16.0f, 14.0f, 14.0f, paint4);
        for (int i = M_LOAD; i <= M_PWR; i += M_FPS) {
            float f8 = f2 + ((i * f4) / 4.0f);
            canvas.drawLine(f, f8, f6, f8, paint);
            canvas.drawText(String.format(Locale.US, "%.0f", Float.valueOf(((4 - i) * f5) / 4.0f)), f + 6.0f, f8 - 5.0f, paint3);
        }
        for (int i2 = M_FPS; i2 < 6; i2 += M_FPS) {
            float f9 = f + ((i2 * f3) / 6.0f);
            canvas.drawLine(f9, f2, f9, f7, paint);
        }
        canvas.drawLine(f, f2, f6, f2, paint2);
        canvas.drawLine(f, f7, f6, f7, paint2);
        canvas.drawLine(f, f2, f, f7, paint2);
        canvas.drawLine(f6, f2, f6, f7, paint2);
        if (fArr.length != 0) {
            int length = fArr[M_LOAD].length;
            int i3 = M_THR;
            if (length >= M_THR) {
                ArrayList<Long> arrayList = this.ts;
                long longValue = arrayList.get(arrayList.size() - M_FPS).longValue();
                for (int i4 = M_LOAD; i4 <= 3; i4 += M_FPS) {
                    long j = (i4 * longValue) / 3;
                    if (j >= 60000) {
                        format = String.format(Locale.US, "%dm", Long.valueOf(j / 60000));
                    } else {
                        format = String.format(Locale.US, "%ds", Long.valueOf(j / 1000));
                    }
                    canvas.drawText(format, Math.min(f + ((i4 * f3) / 3.0f) + 4.0f, f6 - 40.0f), f7 + 44.0f, paint3);
                }
                int i5 = M_LOAD;
                while (i5 < fArr.length) {
                    float[] fArr2 = fArr[i5];
                    int length2 = fArr2.length;
                    if (length2 >= i3) {
                        Paint paint5 = new Paint(M_FPS);
                        paint5.setColor(iArr[i5]);
                        paint5.setStyle(Paint.Style.STROKE);
                        paint5.setStrokeWidth(4.0f);
                        Path path = new Path();
                        for (int i6 = M_LOAD; i6 < length2; i6 += M_FPS) {
                            float f10 = f + ((i6 * f3) / (length2 - 1));
                            float max = f7 - ((Math.max(0.0f, Math.min(f5, fArr2[i6])) / f5) * f4);
                            if (i6 == 0) {
                                path.moveTo(f10, max);
                            } else {
                                path.lineTo(f10, max);
                            }
                        }
                        canvas.drawPath(path, paint5);
                    }
                    i5 += M_FPS;
                    i3 = M_THR;
                }
            }
        }
    }

    private double readCpuBusy() {
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader("/proc/stat"));
            String readLine = bufferedReader.readLine();
            bufferedReader.close();
            if (readLine != null && readLine.startsWith("cpu ")) {
                String[] split = readLine.split("\\s+");
                long parseLong = Long.parseLong(split[M_PWR]) + Long.parseLong(split[5]);
                long j = 0;
                for (int i = M_FPS; i < split.length; i += M_FPS) {
                    j += Long.parseLong(split[i]);
                }
                if (this.lastIdle >= 0) {
                    if (j > this.lastTotal) {
                        this.lastIdle = parseLong;
                        this.lastTotal = j;
                        return Math.max(0.0d, Math.min(100.0d, (((j - r5) - (parseLong - r10)) * 100.0d) / (j - r5)));
                    }
                }
                this.lastIdle = parseLong;
                this.lastTotal = j;
            }
        } catch (Exception unused) {
        }
        return -1.0d;
    }

    private double parseGpu(String str) {
        try {
            String[] split = str.split("\\n");
            int length = split.length;
            for (int i = M_LOAD; i < length; i += M_FPS) {
                String str2 = split[i];
                if (str2.startsWith("G:")) {
                    double parseDouble = Double.parseDouble(str2.substring(M_THR).trim());
                    if (parseDouble <= 0.0d) {
                        return 0.0d;
                    }
                    return parseDouble < 3000.0d ? parseDouble * 1000000.0d : parseDouble;
                }
            }
        } catch (Exception unused) {
        }
        return 0.0d;
    }

    private float parseGpuLoad(String str) {
        try {
            String trim = str.substring(3).trim().replace("%", "").replaceAll("[^0-9.].*$", "").trim();
            if (trim.isEmpty()) {
                return -1.0f;
            }
            float parseFloat = Float.parseFloat(trim);
            if (parseFloat > 100.0f && parseFloat <= 1000.0f) {
                parseFloat /= 10.0f;
            }
            return Math.max(0.0f, Math.min(100.0f, parseFloat));
        } catch (Exception unused) {
            return -1.0f;
        }
    }

    private double parseGpuMax(String str) {
        try {
            double parseDouble = Double.parseDouble(str.substring(3).trim());
            if (parseDouble <= 0.0d) {
                return 0.0d;
            }
            return parseDouble < 3000.0d ? parseDouble : parseDouble < 1000000.0d ? parseDouble / 1000.0d : parseDouble / 1000000.0d;
        } catch (Exception unused) {
            return 0.0d;
        }
    }

    private double parseZoneTemp(String str, String str2, double d) {
        double d2;
        String substring;
        int lastIndexOf;
        boolean contains;
        double d3 = 0.0d;
        try {
            String[] split = str.split("\\n");
            int length = split.length;
            d2 = 0.0d;
            for (int i = M_LOAD; i < length; i += M_FPS) {
                try {
                    String str3 = split[i];
                    if (str3.startsWith("T:") && (lastIndexOf = (substring = str3.substring(M_THR)).lastIndexOf(58)) > 0) {
                        String lowerCase = substring.substring(M_LOAD, lastIndexOf).toLowerCase();
                        double parseDouble = Double.parseDouble(substring.substring(lastIndexOf + M_FPS).trim());
                        if (parseDouble > 1000.0d) {
                            parseDouble /= 1000.0d;
                        }
                        if (parseDouble > 0.0d && parseDouble <= 120.0d) {
                            if ("cpu".equals(str2)) {
                                if (!lowerCase.contains("cpu") && !lowerCase.contains("apc") && !lowerCase.contains("big")) {
                                    contains = M_LOAD;
                                }
                                contains = true;
                            } else {
                                contains = lowerCase.contains("soc");
                            }
                            if (contains) {
                                d2 = Math.max(d2, parseDouble);
                            }
                        }
                    }
                } catch (Exception unused) {
                    d3 = d2;
                    d2 = d3;
                    return Math.max(d2, d);
                }
            }
        } catch (Exception unused2) {
        }
        return Math.max(d2, d);
    }

    private Float realFps() {
        RootShell.Result exec;
        try {
            exec = RootShell.exec(FPS_CMD, 8);
        } catch (Exception unused) {
        }
        if (exec.ok() && exec.out != null) {
            String[] split = exec.out.split("\\n");
            int length = split.length;
            long j = 0;
            long j2 = 0;
            int i = M_LOAD;
            String str = null;
            String str2 = null;
            boolean z = false;
            long j3 = -1;
            for (int i2 = M_LOAD; i2 < length; i2 += M_FPS) {
                String trim = split[i2].trim();
                if (trim.startsWith("P:")) {
                    str = trim.substring(M_THR);
                } else if (trim.startsWith("L:")) {
                    str2 = trim.substring(M_THR);
                    z = M_FPS;
                } else if (!trim.isEmpty()) {
                    if (!z) {
                        long parseNs = parseNs(trim);
                        if (parseNs >= 0) {
                            j3 = parseNs;
                        }
                    } else {
                        String[] split2 = trim.split("\\s+");
                        long parseNs2 = split2.length >= M_THR ? parseNs(split2[M_FPS]) : parseNs(split2[M_LOAD]);
                        if (parseNs2 >= 1000000000 && parseNs2 < 4611686018427387903L) {
                            if (parseNs2 > j) {
                                j = parseNs2;
                            }
                            long j4 = this.sfPrevNewest;
                            if (j4 > 0 && parseNs2 > j4 && parseNs2 != j2) {
                                i += M_FPS;
                                j2 = parseNs2;
                            }
                        }
                    }
                }
            }
            if (str != null && str.isEmpty()) {
                str = null;
            }
            if (str2 != null && str2.isEmpty()) {
                str2 = null;
            }
            if (!eq(str2, this.fpsLayer) || !eq(str, this.fpsPkg)) {
                this.sfPrevNewest = -1L;
                this.gfxFrames = -1L;
            }
            this.fpsLayer = str2;
            this.fpsPkg = str;
            if (str2 != null && j > 0) {
                long j5 = this.sfPrevNewest;
                if (j5 > 0) {
                    if (j <= j5) {
                        return Float.valueOf(0.0f);
                    }
                    double d = (j - j5) / 1.0E9d;
                    this.sfPrevNewest = j;
                    if (d >= 0.005d && d <= 120.0d) {
                        float f = this.peakHz;
                        return Float.valueOf(Math.max(1.0f, Math.min(f > 0.0f ? f : 240.0f, (float) (i / d))));
                    }
                    return Float.valueOf(0.0f);
                }
                this.sfPrevNewest = j;
            }
            if (str != null) {
                long j6 = j3;
                if (j6 >= 0) {
                    long uptimeMillis = SystemClock.uptimeMillis();
                    long j7 = this.gfxFrames;
                    if (j7 >= 0 && j6 >= j7) {
                        float max = (((float) (j6 - j7)) * 1000.0f) / ((float) Math.max(1L, uptimeMillis - this.gfxAt));
                        this.gfxFrames = j6;
                        this.gfxAt = uptimeMillis;
                        float f2 = this.peakHz;
                        return Float.valueOf(Math.max(0.0f, Math.min(f2 > 0.0f ? f2 : 240.0f, max)));
                    }
                    this.gfxFrames = j6;
                    this.gfxAt = uptimeMillis;
                }
            }
            return null;
        }
        return null;
    }

    private static boolean eq(String str, String str2) {
        if (str == null) {
            return str2 == null;
        }
        return str.equals(str2);
    }

    private float currentFps() {
        Float realFps = realFps();
        if (realFps == null || realFps.floatValue() <= 0.0f) {
            if (this.lastGoodAt > 0) {
                return this.lastGoodHz;
            }
            return 0.0f;
        }
        this.lastGoodHz = realFps.floatValue();
        this.lastGoodAt = SystemClock.elapsedRealtime();
        return realFps.floatValue();
    }

    private static long parseNs(String str) {
        try {
            return Long.parseLong(str.trim());
        } catch (NumberFormatException unused) {
            return -1L;
        }
    }

    private Notification notif() {
        ((NotificationManager) getSystemService(NotificationManager.class)).createNotificationChannel(new NotificationChannel("monitor", "负载监视器", M_THR));
        PendingIntent service = PendingIntent.getService(this, M_FPS, new Intent(this, (Class<?>) MonitorService.class).setAction("stop"), 201326592);
        return new Notification.Builder(this, "monitor").setContentTitle("监视器功能运行中").setContentText("点击「监视器」展开功能 · 长按胶囊隐藏 · 长按窗口锁定位置").setSmallIcon(android.R.drawable.ic_menu_view).addAction(new Notification.Action.Builder((Icon) null, "显示菜单", PendingIntent.getService(this, M_THR, new Intent(this, (Class<?>) MonitorService.class).setAction("show_pill"), 201326592)).build()).addAction(new Notification.Action.Builder((Icon) null, "关闭", service).build()).setOngoing(true).build();
    }
}
