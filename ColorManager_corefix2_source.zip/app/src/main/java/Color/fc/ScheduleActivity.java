package Color.fc;

import Color.fc.AllConfig;
import Color.fc.RootShell;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/* loaded from: classes.dex */
public class ScheduleActivity extends ThemedActivity {
    private static final String[] FIELDS = {"opt2", "cpuMax", "cpuMin", "llcc", "uclampDisplay", "uclampSsfg", "uclampTouch", "uclampMm", "uclampRt", "uclampTopApp", "walt1", "walt2"};
    private static final int REQ_IMPORT = 7301;
    private AllConfig cfgA;
    private AllConfig cfgB;
    private SocInfo soc;
    private TextView socTip;
    private TextView tabAV;
    private TextView tabBV;
    private String tab = "a";
    private boolean dirty = false;
    private boolean loading = true;
    private final HashMap<String, EditText> inputs = new HashMap<>();
    private final HashMap<String, SeekBar> seekBars = new HashMap<>();
    private boolean syncing = false;
    private int laxScheme = 2;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // Color.fc.ThemedActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        String str;
        super.onCreate(bundle);
        setContentView(R.layout.activity_schedule);
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ScheduleActivity.this.lambda$onCreate$0(view);
            }
        });
        this.socTip = (TextView) findViewById(R.id.socTip);
        this.tabAV = (TextView) findViewById(R.id.tabA);
        this.tabBV = (TextView) findViewById(R.id.tabB);
        SocInfo socInfo = MainActivity.cachedSoc;
        this.soc = socInfo;
        if (socInfo == null) {
            this.soc = SocInfo.autoDetect();
        }
        TextView textView = this.socTip;
        if (this.soc.known) {
            str = String.format(Locale.US, "当前 SOC：%s（%s）→ 加载方案 %s", this.soc.code, this.soc.marketing, "a".equals(this.soc.config) ? "1" : "2");
        } else {
            str = "检测错误，默认加载方案1";
        }
        textView.setText(str);
        this.tabAV.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda17
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ScheduleActivity.this.lambda$onCreate$1(view);
            }
        });
        this.tabBV.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ScheduleActivity.this.lambda$onCreate$2(view);
            }
        });
        this.tab = this.soc.config;
        findViewById(R.id.saveBtn).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ScheduleActivity.this.lambda$onCreate$3(view);
            }
        });
        findViewById(R.id.btnImport).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ScheduleActivity.this.lambda$onCreate$4(view);
            }
        });
        findViewById(R.id.btnExport).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ScheduleActivity.this.lambda$onCreate$5(view);
            }
        });
        buildCards();
        final String str2 = "/data/adb/modules/colorFC/config/a.all.sh";
        final String str3 = "/data/adb/modules/colorFC/config/b.all.sh";
        new Thread(new Runnable() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                ScheduleActivity.this.lambda$onCreate$7(str2, str3);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(View view) {
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$1(View view) {
        switchTab("a");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$2(View view) {
        switchTab("b");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$3(View view) {
        saveConfig();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$4(View view) {
        importLax();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$5(View view) {
        exportLax();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$7(String str, String str2) {
        String readFile = RootShell.readFile(str);
        String readFile2 = RootShell.readFile(str2);
        this.cfgA = AllConfig.parse(readFile);
        this.cfgB = AllConfig.parse(readFile2);
        if (this.cfgA == null) {
            this.cfgA = AllConfig.defaults();
        }
        if (this.cfgB == null) {
            this.cfgB = AllConfig.defaults();
        }
        runOnUiThread(new Runnable() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                ScheduleActivity.this.lambda$onCreate$6();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$6() {
        this.loading = false;
        applyTabStyle();
        fillInputs();
    }

    private void buildCards() {
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.modesContainer);
        int[] iArr = {-16730717, -16738616, -2061824, -6279952};
        for (int i = 0; i < AllConfig.MODE_KEYS.length; i++) {
            String str = AllConfig.MODE_KEYS[i];
            View inflate = getLayoutInflater().inflate(R.layout.mode_card, (ViewGroup) linearLayout, false);
            View findViewById = inflate.findViewById(R.id.modeDot);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setShape(1);
            gradientDrawable.setColor(iArr[i]);
            findViewById.setBackground(gradientDrawable);
            ((TextView) inflate.findViewById(R.id.modeTitle)).setText(AllConfig.MODE_NAMES[i]);
            ((TextView) inflate.findViewById(R.id.modeSubtitle)).setText(AllConfig.MODE_DESC[i]);
            final LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.paramsBox);
            final ImageView imageView = (ImageView) inflate.findViewById(R.id.expandArrow);
            inflate.findViewById(R.id.cardHeader).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda14
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    ScheduleActivity.this.lambda$buildCards$8(linearLayout2, imageView, view);
                }
            });
            addParam(linearLayout2, str + ".opt2", "调度增强等级 opt2（0-100，越高越激进，省电设 0）");
            addParam(linearLayout2, str + ".cpuMax", "CPU 最高频率百分比（json_cpu_max_min 参数一）");
            addParam(linearLayout2, str + ".cpuMin", "CPU 最低频率百分比（json_cpu_max_min 参数二）");
            addParam(linearLayout2, str + ".llcc", "LLCC 系统缓存最大频率（Hz）");
            addParam(linearLayout2, str + ".uclampDisplay", "display 显示任务 uclamp 最低提升");
            addParam(linearLayout2, str + ".uclampSsfg", "ssfg 前台服务组 uclamp 最低提升");
            addParam(linearLayout2, str + ".uclampTouch", "touch 触控线程 uclamp 最低提升（影响跟手性）");
            addParam(linearLayout2, str + ".uclampMm", "multimedia 多媒体任务 uclamp 最低提升");
            addParam(linearLayout2, str + ".uclampRt", "rt 实时任务 uclamp 最低提升");
            addParam(linearLayout2, str + ".uclampTopApp", "top-app 前台应用 uclamp 最低提升");
            if ("fast".equals(str)) {
                addParam(linearLayout2, str + ".walt1", "WALT 提频速率限制 参数一（µs）");
                addParam(linearLayout2, str + ".walt2", "WALT 提频速率限制 参数二（µs）");
            }
            linearLayout.addView(inflate);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildCards$8(LinearLayout linearLayout, ImageView imageView, View view) {
        boolean z = linearLayout.getVisibility() != 0;
        linearLayout.setVisibility(z ? 0 : 8);
        rotateArrow(imageView, z);
    }

    private void rotateArrow(ImageView imageView, boolean z) {
        RotateAnimation rotateAnimation = new RotateAnimation(z ? 0.0f : 180.0f, z ? 180.0f : 0.0f, 1, 0.5f, 1, 0.5f);
        rotateAnimation.setDuration(200L);
        rotateAnimation.setInterpolator(new DecelerateInterpolator());
        rotateAnimation.setFillAfter(true);
        imageView.startAnimation(rotateAnimation);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class ParamRange {
        final long max;
        final long min;
        final long step;

        ParamRange(long j, long j2, long j3) {
            this.min = j;
            this.max = j2;
            this.step = j3;
        }

        int maxProgress() {
            return (int) ((this.max - this.min) / this.step);
        }

        int toProgress(long j) {
            long j2 = this.min;
            if (j < j2) {
                j = j2;
            }
            long j3 = this.max;
            if (j > j3) {
                j = j3;
            }
            return (int) ((j - j2) / this.step);
        }

        long toValue(int i) {
            long j = this.min + (i * this.step);
            long j2 = this.max;
            return j > j2 ? j2 : j;
        }
    }

    private static ParamRange rangeOf(String str) {
        String substring = str.substring(str.indexOf(46) + 1);
        if ("llcc".equals(substring)) {
            return new ParamRange(300000L, 1800000L, 10000L);
        }
        if ("walt1".equals(substring) || "walt2".equals(substring)) {
            return new ParamRange(0L, 2000L, 20L);
        }
        return new ParamRange(0L, 100L, 1L);
    }

    private void addParam(LinearLayout linearLayout, String str, String str2) {
        View inflate = getLayoutInflater().inflate(R.layout.param_row, (ViewGroup) linearLayout, false);
        ((TextView) inflate.findViewById(R.id.label)).setText(str2);
        final EditText editText = (EditText) inflate.findViewById(R.id.input);
        final SeekBar seekBar = (SeekBar) inflate.findViewById(R.id.seek);
        final ParamRange rangeOf = rangeOf(str);
        seekBar.setMax(rangeOf.maxProgress());
        try {
            seekBar.getProgressDrawable().setColorFilter(-16738616, PorterDuff.Mode.SRC_IN);
            seekBar.getThumb().setColorFilter(-16738616, PorterDuff.Mode.SRC_IN);
        } catch (Exception unused) {
        }
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: Color.fc.ScheduleActivity.1
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar seekBar2) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar seekBar2) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                if (!z || ScheduleActivity.this.syncing) {
                    return;
                }
                ScheduleActivity.this.syncing = true;
                editText.setText(String.valueOf(rangeOf.toValue(i)));
                ScheduleActivity.this.syncing = false;
                if (ScheduleActivity.this.loading) {
                    return;
                }
                ScheduleActivity.this.dirty = true;
            }
        });
        editText.addTextChangedListener(new TextWatcher() { // from class: Color.fc.ScheduleActivity.2
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
                if (!ScheduleActivity.this.loading) {
                    ScheduleActivity.this.dirty = true;
                }
                if (ScheduleActivity.this.syncing) {
                    return;
                }
                try {
                    long parseLong = Long.parseLong(editable.toString().trim());
                    ScheduleActivity.this.syncing = true;
                    seekBar.setProgress(rangeOf.toProgress(parseLong));
                    ScheduleActivity.this.syncing = false;
                } catch (Exception unused2) {
                }
            }
        });
        this.inputs.put(str, editText);
        this.seekBars.put(str, seekBar);
        linearLayout.addView(inflate);
    }

    private void fillInputs() {
        AllConfig currentCfg = currentCfg();
        AllConfig defaults = AllConfig.defaults();
        for (String str : AllConfig.MODE_KEYS) {
            AllConfig.Mode mode = currentCfg.modes.get(str);
            AllConfig.Mode mode2 = defaults.modes.get(str);
            set("opt2", str, mode, mode2);
            set("cpuMax", str, mode, mode2);
            set("cpuMin", str, mode, mode2);
            set("llcc", str, mode, mode2);
            set("uclampDisplay", str, mode, mode2);
            set("uclampSsfg", str, mode, mode2);
            set("uclampTouch", str, mode, mode2);
            set("uclampMm", str, mode, mode2);
            set("uclampRt", str, mode, mode2);
            set("uclampTopApp", str, mode, mode2);
            set("walt1", str, mode, mode2);
            set("walt2", str, mode, mode2);
        }
        this.dirty = false;
    }

    private void set(String str, String str2, AllConfig.Mode mode, AllConfig.Mode mode2) {
        EditText editText = this.inputs.get(str2 + "." + str);
        if (editText == null) {
            return;
        }
        String value = value(mode, str);
        if (value == null || value.isEmpty()) {
            value = value(mode2, str);
        }
        if (value == null) {
            value = "";
        }
        editText.setText(value);
    }

    private String value(AllConfig.Mode mode, String str) {
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case -1701511769:
                if (str.equals("uclampSsfg")) {
                    c = 0;
                    break;
                }
                break;
            case -1396182618:
                if (str.equals("uclampMm")) {
                    c = 1;
                    break;
                }
                break;
            case -1396182456:
                if (str.equals("uclampRt")) {
                    c = 2;
                    break;
                }
                break;
            case -1353684324:
                if (str.equals("cpuMax")) {
                    c = 3;
                    break;
                }
                break;
            case -1353684086:
                if (str.equals("cpuMin")) {
                    c = 4;
                    break;
                }
                break;
            case -1234646916:
                if (str.equals("uclampDisplay")) {
                    c = 5;
                    break;
                }
                break;
            case -1206438535:
                if (str.equals("uclampTouch")) {
                    c = 6;
                    break;
                }
                break;
            case 3324384:
                if (str.equals("llcc")) {
                    c = 7;
                    break;
                }
                break;
            case 3418079:
                if (str.equals("opt2")) {
                    c = '\b';
                    break;
                }
                break;
            case 112896159:
                if (str.equals("walt1")) {
                    c = '\t';
                    break;
                }
                break;
            case 112896160:
                if (str.equals("walt2")) {
                    c = '\n';
                    break;
                }
                break;
            case 1254929810:
                if (str.equals("uclampTopApp")) {
                    c = 11;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                return mode.uclampSsfg;
            case 1:
                return mode.uclampMm;
            case 2:
                return mode.uclampRt;
            case 3:
                return mode.cpuMax;
            case 4:
                return mode.cpuMin;
            case 5:
                return mode.uclampDisplay;
            case 6:
                return mode.uclampTouch;
            case 7:
                return mode.llcc;
            case '\b':
                return mode.opt2;
            case '\t':
                return mode.walt1;
            case '\n':
                return mode.walt2;
            case 11:
                return mode.uclampTopApp;
            default:
                return "";
        }
    }

    private void assign(AllConfig.Mode mode, String str, String str2) {
        str.hashCode();
        char c = 65535;
        switch (str.hashCode()) {
            case -1701511769:
                if (str.equals("uclampSsfg")) {
                    c = 0;
                    break;
                }
                break;
            case -1396182618:
                if (str.equals("uclampMm")) {
                    c = 1;
                    break;
                }
                break;
            case -1396182456:
                if (str.equals("uclampRt")) {
                    c = 2;
                    break;
                }
                break;
            case -1353684324:
                if (str.equals("cpuMax")) {
                    c = 3;
                    break;
                }
                break;
            case -1353684086:
                if (str.equals("cpuMin")) {
                    c = 4;
                    break;
                }
                break;
            case -1234646916:
                if (str.equals("uclampDisplay")) {
                    c = 5;
                    break;
                }
                break;
            case -1206438535:
                if (str.equals("uclampTouch")) {
                    c = 6;
                    break;
                }
                break;
            case 3324384:
                if (str.equals("llcc")) {
                    c = 7;
                    break;
                }
                break;
            case 3418079:
                if (str.equals("opt2")) {
                    c = '\b';
                    break;
                }
                break;
            case 112896159:
                if (str.equals("walt1")) {
                    c = '\t';
                    break;
                }
                break;
            case 112896160:
                if (str.equals("walt2")) {
                    c = '\n';
                    break;
                }
                break;
            case 1254929810:
                if (str.equals("uclampTopApp")) {
                    c = 11;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                mode.uclampSsfg = str2;
                return;
            case 1:
                mode.uclampMm = str2;
                return;
            case 2:
                mode.uclampRt = str2;
                return;
            case 3:
                mode.cpuMax = str2;
                return;
            case 4:
                mode.cpuMin = str2;
                return;
            case 5:
                mode.uclampDisplay = str2;
                return;
            case 6:
                mode.uclampTouch = str2;
                return;
            case 7:
                mode.llcc = str2;
                return;
            case '\b':
                mode.opt2 = str2;
                return;
            case '\t':
                mode.walt1 = str2;
                return;
            case '\n':
                mode.walt2 = str2;
                return;
            case 11:
                mode.uclampTopApp = str2;
                return;
            default:
                return;
        }
    }

    private AllConfig currentCfg() {
        return "a".equals(this.tab) ? this.cfgA : this.cfgB;
    }

    private void switchTab(final String str) {
        if (str.equals(this.tab)) {
            return;
        }
        if (this.dirty) {
            new AlertDialog.Builder(this).setTitle("未保存的修改").setMessage("当前方案已修改但未保存，切换后将丢失，是否继续？").setPositiveButton("继续", new DialogInterface.OnClickListener() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda6
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    ScheduleActivity.this.lambda$switchTab$9(str, dialogInterface, i);
                }
            }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).show();
        } else {
            doSwitch(str);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$switchTab$9(String str, DialogInterface dialogInterface, int i) {
        doSwitch(str);
    }

    private void doSwitch(String str) {
        this.tab = str;
        applyTabStyle();
        fillInputs();
    }

    private void applyTabStyle() {
        boolean equals = "a".equals(this.tab);
        this.tabAV.setBackgroundResource(equals ? R.drawable.bg_tab_sel : R.drawable.bg_tab);
        this.tabAV.setTextColor(equals ? -16746584 : -8615264);
        this.tabBV.setBackgroundResource(equals ? R.drawable.bg_tab : R.drawable.bg_tab_sel);
        this.tabBV.setTextColor(equals ? -8615264 : -16746584);
    }

    private void collectCurrent() {
        AllConfig currentCfg = currentCfg();
        if (currentCfg == null) {
            return;
        }
        AllConfig defaults = AllConfig.defaults();
        for (String str : AllConfig.MODE_KEYS) {
            AllConfig.Mode mode = currentCfg.modes.get(str);
            AllConfig.Mode mode2 = defaults.modes.get(str);
            for (String str2 : FIELDS) {
                EditText editText = this.inputs.get(str + "." + str2);
                if (editText != null) {
                    String trim = editText.getText().toString().trim();
                    if (trim.isEmpty()) {
                        trim = value(mode2, str2);
                    }
                    assign(mode, str2, trim);
                }
            }
        }
    }

    private void saveConfig() {
        if (currentCfg() == null) {
            Toast.makeText(this, "方案仍在加载中", 0).show();
            return;
        }
        collectCurrent();
        final String str = "/data/adb/modules/colorFC/config/" + this.tab + ".all.sh";
        final String generate = AllConfig.generate(currentCfg());
        if ("b".equals(this.tab)) {
            generate = generate.replace("$mokzdz/A/", "$mokzdz/B/");
        }
        new Thread(new Runnable() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                ScheduleActivity.this.lambda$saveConfig$11(generate, str);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$saveConfig$11(String str, String str2) {
        final RootShell.Result writeFile = RootShell.writeFile(getCacheDir(), str, str2);
        runOnUiThread(new Runnable() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                ScheduleActivity.this.lambda$saveConfig$10(writeFile);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$saveConfig$10(RootShell.Result result) {
        if (result.ok()) {
            this.dirty = false;
            Toast.makeText(this, "保存成功", 0).show();
        } else {
            Toast.makeText(this, "写入失败：" + result.err, 1).show();
        }
    }

    private void exportLax() {
        if (this.cfgA == null || this.cfgB == null) {
            Toast.makeText(this, "方案仍在加载中", 0).show();
            return;
        }
        AlertDialog create = new AlertDialog.Builder(this).setTitle("选择要导出的方案").setSingleChoiceItems(new String[]{"方案1", "方案2", "方案1+方案2"}, 2, new DialogInterface.OnClickListener() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda11
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                ScheduleActivity.this.lambda$exportLax$12(dialogInterface, i);
            }
        }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).create();
        if (create.getWindow() != null) {
            create.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
        }
        create.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$exportLax$12(DialogInterface dialogInterface, int i) {
        dialogInterface.dismiss();
        doExport(i);
    }

    private void doExport(int i) {
        final String str;
        collectCurrent();
        final LinkedHashMap<String, String> linkedHashMap = new LinkedHashMap<>();
        if (i != 1) {
            putLaxCfg(linkedHashMap, "a", this.cfgA);
        }
        if (i != 0) {
            putLaxCfg(linkedHashMap, "b", this.cfgB);
        }
        if (i == 0) {
            str = "方案1";
        } else {
            str = i == 1 ? "方案2" : "方案1+2";
        }
        new Thread(new Runnable() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                ScheduleActivity.this.lambda$doExport$14(linkedHashMap, str);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$doExport$14(LinkedHashMap linkedHashMap, final String str) {
        final RootShell.Result write = LaxStore.write(getCacheDir(), linkedHashMap);
        runOnUiThread(new Runnable() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda15
            @Override // java.lang.Runnable
            public final void run() {
                ScheduleActivity.this.lambda$doExport$13(write, str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$doExport$13(RootShell.Result result, String str) {
        String str2;
        if (result.ok()) {
            str2 = "已导出" + str + " 到内部储存根目录 /storage/emulated/0/color.lax";
        } else {
            str2 = "导出失败：" + result.err;
        }
        Toast.makeText(this, str2, 1).show();
    }

    private void putLaxCfg(LinkedHashMap<String, String> linkedHashMap, String str, AllConfig allConfig) {
        for (String str2 : AllConfig.MODE_KEYS) {
            AllConfig.Mode mode = allConfig.modes.get(str2);
            if (mode != null) {
                String str3 = "sch." + str + "." + str2 + ".";
                for (String str4 : FIELDS) {
                    linkedHashMap.put(str3 + str4, value(mode, str4));
                }
            }
        }
    }

    private void importLax() {
        if (this.cfgA == null || this.cfgB == null) {
            Toast.makeText(this, "方案仍在加载中", 0).show();
            return;
        }
        AlertDialog create = new AlertDialog.Builder(this).setTitle("选择要导入的方案").setSingleChoiceItems(new String[]{"方案1", "方案2", "方案1+方案2"}, 2, new DialogInterface.OnClickListener() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda10
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                ScheduleActivity.this.lambda$importLax$15(dialogInterface, i);
            }
        }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).create();
        if (create.getWindow() != null) {
            create.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
        }
        create.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$importLax$15(DialogInterface dialogInterface, int i) {
        dialogInterface.dismiss();
        this.laxScheme = i;
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType("*/*");
        startActivityForResult(intent, REQ_IMPORT);
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i != REQ_IMPORT || i2 != -1 || intent == null || intent.getData() == null) {
            return;
        }
        final Uri data = intent.getData();
        if (this.cfgA == null || this.cfgB == null) {
            Toast.makeText(this, "方案仍在加载中", 0).show();
        } else {
            new Thread(new Runnable() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda13
                @Override // java.lang.Runnable
                public final void run() {
                    ScheduleActivity.this.lambda$onActivityResult$17(data);
                }
            }).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onActivityResult$17(Uri uri) {
        final LinkedHashMap<String, String> readUri = LaxStore.readUri(this, uri);
        runOnUiThread(new Runnable() { // from class: Color.fc.ScheduleActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                ScheduleActivity.this.lambda$onActivityResult$16(readUri);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onActivityResult$16(LinkedHashMap linkedHashMap) {
        if (linkedHashMap.isEmpty()) {
            Toast.makeText(this, "无法读取所选文件", 0).show();
            return;
        }
        int applyLaxScheme = applyLaxScheme(linkedHashMap);
        if (applyLaxScheme == 0) {
            Toast.makeText(this, "文件中没有调度参数", 0).show();
            return;
        }
        fillInputs();
        this.dirty = true;
        int i = this.laxScheme;
        Toast.makeText(this, "已导入 " + applyLaxScheme + " 项（" + (i == 0 ? "方案1" : i == 1 ? "方案2" : "方案1+2") + "），点击保存后生效", 1).show();
    }

    private int applyLaxScheme(Map<String, String> map) {
        int applyLaxCfg = this.laxScheme != 1 ? applyLaxCfg(map, this.cfgA, "a") : 0;
        return this.laxScheme != 0 ? applyLaxCfg + applyLaxCfg(map, this.cfgB, "b") : applyLaxCfg;
    }

    private int applyLaxCfg(Map<String, String> map, AllConfig allConfig, String str) {
        if (allConfig == null) {
            return 0;
        }
        int i = 0;
        for (String str2 : AllConfig.MODE_KEYS) {
            AllConfig.Mode mode = allConfig.modes.get(str2);
            if (mode != null) {
                String str3 = "sch." + str + "." + str2 + ".";
                for (String str4 : FIELDS) {
                    String str5 = map.get(str3 + str4);
                    if (str5 != null && !str5.isEmpty()) {
                        assign(mode, str4, str5);
                        i++;
                    }
                }
            }
        }
        return i;
    }
}
