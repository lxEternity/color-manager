package Color.fc.view;

import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;

/* loaded from: classes.dex */
public class Warp {
    public static void press(View view) {
        view.setOnTouchListener(new View.OnTouchListener() { // from class: Color.fc.view.Warp$$ExternalSyntheticLambda0
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view2, MotionEvent motionEvent) {
                return Warp.lambda$press$0(view2, motionEvent);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ boolean lambda$press$0(View view, MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            view.animate().scaleX(0.95f).scaleY(0.95f).alpha(0.85f).setDuration(90L).start();
            return false;
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return false;
        }
        view.animate().scaleX(1.0f).scaleY(1.0f).alpha(1.0f).setDuration(200L).setInterpolator(new OvershootInterpolator(2.2f)).start();
        return false;
    }
}
