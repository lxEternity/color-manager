package Color.fc;

import Color.fc.RootShell;
import android.content.Context;
import android.os.SystemClock;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public class AppFreqLimiter {
    private static final String CACHE = "/data/local/tmp/afc.cache";
    static final String CONF = "/sdcard/Android/qingtd/单应用负载.conf";
    private static final Map<String, long[]> limits = new HashMap();
    private static String applied = null;
    private static long nextLoad = 0;

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void tick(Context context) {
        try {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            if (elapsedRealtime >= nextLoad) {
                load();
                nextLoad = elapsedRealtime + 5000;
            }
            Map<String, long[]> map = limits;
            if (map.isEmpty()) {
                String str = applied;
                if (str != null) {
                    restore(str);
                    return;
                }
                return;
            }
            String fgPkg = fgPkg();
            if (fgPkg == null) {
                return;
            }
            long[] jArr = map.get(fgPkg);
            if (!fgPkg.equals(applied)) {
                String str2 = applied;
                if (str2 != null) {
                    restore(str2);
                }
                applied = null;
            }
            if (jArr != null) {
                if (jArr[0] > 0 || jArr[1] > 0) {
                    applyFreq(fgPkg, jArr);
                }
                long j = jArr[2];
                if (j > 0) {
                    applyPct(fgPkg, j);
                }
                applied = fgPkg;
            }
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean idle() {
        return limits.isEmpty() && applied == null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean anyLimitConfigured() {
        load();
        for (long[] jArr : limits.values()) {
            if (jArr[0] > 0 || jArr[1] > 0 || jArr[2] > 0) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void restoreAll() {
        String str = applied;
        if (str != null) {
            restore(str);
        } else {
            RootShell.exec(freqRestoreScript(), 10);
        }
    }

    private static void load() {
        int indexOf;
        limits.clear();
        String readFile = RootShell.readFile(CONF);
        if (readFile == null) {
            return;
        }
        for (String str : readFile.split("\n")) {
            String trim = str.trim();
            if (!trim.isEmpty() && !trim.startsWith("#") && (indexOf = trim.indexOf(61)) > 0) {
                try {
                    String[] split = trim.substring(indexOf + 1).trim().split(",");
                    limits.put(trim.substring(0, indexOf).trim(), new long[]{parse(split.length > 0 ? split[0] : null), parse(split.length > 1 ? split[1] : null), parse(split.length > 2 ? split[2] : null)});
                } catch (Exception unused) {
                }
            }
        }
    }

    private static long parse(String str) {
        try {
            return Long.parseLong(str.trim());
        } catch (Exception unused) {
            return 0L;
        }
    }

    private static String fgPkg() {
        RootShell.Result exec = RootShell.exec("f=$(dumpsys window 2>/dev/null | grep -m1 -E 'mCurrentFocus|mFocusedApp');p=$(echo \"$f\" | grep -oE '[A-Za-z0-9_.]+/' | head -1);echo \"${p%/}\"", 6);
        if (!exec.ok() || exec.out == null) {
            return null;
        }
        String trim = exec.out.trim();
        if (trim.isEmpty()) {
            return null;
        }
        return trim;
    }

    private static void applyFreq(String str, long[] jArr) {
        long j = jArr[0];
        long j2 = jArr[1];
        if (j > 0 && j2 > 0 && j > j2) {
            j = j2;
        }
        RootShell.exec("[ -f '/data/local/tmp/afc.cache' ] || for c in /sys/devices/system/cpu/cpu[0-9]*; do d=$c/cpufreq; echo \"$d $(cat $d/scaling_min_freq 2>/dev/null) $(cat $d/scaling_max_freq 2>/dev/null)\" >> '/data/local/tmp/afc.cache'; done; MN=" + (j * 1000) + "; MX=" + (j2 * 1000) + "; for c in /sys/devices/system/cpu/cpu[0-9]*; do d=$c/cpufreq; imn=$(cat $d/cpuinfo_min_freq 2>/dev/null); cmn=$(cat $d/scaling_min_freq 2>/dev/null); cmx=$(cat $d/scaling_max_freq 2>/dev/null); if [ \"$MX\" -gt 0 ] 2>/dev/null; then [ -n \"$cmn\" ] && [ \"$MX\" -lt \"$cmn\" ] 2>/dev/null && echo \"$imn\" > $d/scaling_min_freq 2>/dev/null; echo \"$MX\" > $d/scaling_max_freq 2>/dev/null; cmx=$MX; fi; if [ \"$MN\" -gt 0 ] 2>/dev/null; then [ -n \"$cmx\" ] && [ \"$MN\" -gt \"$cmx\" ] 2>/dev/null && echo \"$MN\" > $d/scaling_max_freq 2>/dev/null; echo \"$MN\" > $d/scaling_min_freq 2>/dev/null; fi; done", 10);
    }

    private static void applyPct(String str, long j) {
        RootShell.exec("n=$(ls -d /sys/devices/system/cpu/cpu[0-9]* 2>/dev/null | wc -l); [ \"$n\" -gt 0 ] || exit 0; q=$(( n * " + j + " * 1000 )); for pid in $(pgrep -f \"^" + str + "($|:| )\" 2>/dev/null); do uid=$(awk '/^Uid/{print $2}' /proc/$pid/status 2>/dev/null); [ -n \"$uid\" ] || continue; cg=/sys/fs/cgroup/uid_$uid/pid_$pid; [ -f \"$cg/cpu.max\" ] && echo \"$q 100000\" > \"$cg/cpu.max\" 2>/dev/null; cg=/dev/cpuctl/uid_$uid/pid_$pid; [ -f \"$cg/cpu.cfs_quota_us\" ] && echo \"$q\" > \"$cg/cpu.cfs_quota_us\" 2>/dev/null; done", 10);
    }

    private static void restore(String str) {
        RootShell.exec(freqRestoreScript(), 10);
        RootShell.exec("for pid in $(pgrep -f \"^" + str + "($|:| )\" 2>/dev/null); do uid=$(awk '/^Uid/{print $2}' /proc/$pid/status 2>/dev/null); [ -n \"$uid\" ] || continue; cg=/sys/fs/cgroup/uid_$uid/pid_$pid; [ -f \"$cg/cpu.max\" ] && echo \"max 100000\" > \"$cg/cpu.max\" 2>/dev/null; cg=/dev/cpuctl/uid_$uid/pid_$pid; [ -f \"$cg/cpu.cfs_quota_us\" ] && echo \"-1\" > \"$cg/cpu.cfs_quota_us\" 2>/dev/null; done", 10);
        applied = null;
    }

    private static String freqRestoreScript() {
        return "[ -f '/data/local/tmp/afc.cache' ] || exit 0; while read d mn mx; do [ -d \"$d\" ] || continue; imn=$(cat $d/cpuinfo_min_freq 2>/dev/null); cmn=$(cat $d/scaling_min_freq 2>/dev/null); [ -n \"$cmn\" ] && [ \"$mx\" -lt \"$cmn\" ] 2>/dev/null && echo \"$imn\" > $d/scaling_min_freq 2>/dev/null; echo \"$mx\" > $d/scaling_max_freq 2>/dev/null; echo \"$mn\" > $d/scaling_min_freq 2>/dev/null; done < '/data/local/tmp/afc.cache'; rm -f '/data/local/tmp/afc.cache'";
    }
}
