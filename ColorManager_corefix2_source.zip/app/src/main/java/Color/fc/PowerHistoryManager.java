package Color.fc;

import Color.fc.PowerMonitor;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/* loaded from: classes.dex */
public class PowerHistoryManager {
    private static final long GAP_MS = 900000;
    private static final int KEEP_SAMPLES = 15000;
    private static final long SAMPLE_MS = 60000;
    private static final List<Sample> data = new ArrayList();
    private static long lastT = 0;
    private static boolean loaded = false;
    private static long lastTrim = 0;

    /* loaded from: classes.dex */
    public static class Sample {
        public int level;
        public char status;
        public long t;
        public double tempC;
        public double watts;
    }

    /* loaded from: classes.dex */
    public static class Session {
        public double avgW;
        public boolean charging;
        public long end;
        public int endLevel;
        public double energyWh;
        public double maxW;
        public int samples;
        public long start;
        public int startLevel;
    }

    private static synchronized File file(Context context) {
        File file;
        synchronized (PowerHistoryManager.class) {
            file = new File(context.getFilesDir(), "power_samples.csv");
        }
        return file;
    }

    private static synchronized void load(Context context) {
        synchronized (PowerHistoryManager.class) {
            if (loaded) {
                return;
            }
            loaded = true;
            try {
                BufferedReader bufferedReader = new BufferedReader(new FileReader(file(context)));
                while (true) {
                    try {
                        String readLine = bufferedReader.readLine();
                        if (readLine == null) {
                            break;
                        }
                        String[] split = readLine.split(",");
                        if (split.length >= 4) {
                            Sample sample = new Sample();
                            sample.t = Long.parseLong(split[0]);
                            sample.level = (int) Double.parseDouble(split[1]);
                            sample.watts = Double.parseDouble(split[2]);
                            sample.status = split[3].charAt(0);
                            if (split.length >= 5) {
                                sample.tempC = Double.parseDouble(split[4]);
                            }
                            data.add(sample);
                        }
                    } catch (Throwable th) {
                        try {
                            bufferedReader.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                        throw th;
                    }
                }
                bufferedReader.close();
            } catch (Exception unused) {
            }
        }
    }

    public static synchronized void record(Context context, PowerMonitor.BatteryStat batteryStat) {
        PrintWriter printWriter;
        synchronized (PowerHistoryManager.class) {
            if (batteryStat != null) {
                if (batteryStat.level >= 0) {
                    load(context);
                    long currentTimeMillis = System.currentTimeMillis();
                    if (currentTimeMillis - lastT < SAMPLE_MS) {
                        return;
                    }
                    lastT = currentTimeMillis;
                    char c = 'C';
                    if (!"Charging".equalsIgnoreCase(batteryStat.status)) {
                        if ("Full".equalsIgnoreCase(batteryStat.status)) {
                            c = 'F';
                        } else if ((batteryStat.status != null && !batteryStat.status.isEmpty()) || batteryStat.amps >= 0.0d) {
                            c = 'D';
                        }
                    }
                    Sample sample = new Sample();
                    sample.t = currentTimeMillis;
                    sample.level = batteryStat.level;
                    sample.watts = Math.abs(batteryStat.watts);
                    sample.status = c;
                    sample.tempC = batteryStat.tempC;
                    data.add(sample);
                    try {
                        printWriter = new PrintWriter(new FileWriter(file(context), true));
                    } catch (Exception unused) {
                    }
                    try {
                        printWriter.println(sample.t + "," + sample.level + "," + String.format(Locale.US, "%.2f", Double.valueOf(sample.watts)) + "," + sample.status + "," + String.format(Locale.US, "%.1f", Double.valueOf(sample.tempC)));
                        printWriter.close();
                        if (currentTimeMillis - lastTrim > 3600000 && data.size() > KEEP_SAMPLES) {
                            lastTrim = currentTimeMillis;
                            trim(context);
                        }
                    } catch (Throwable th) {
                        try {
                            printWriter.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                        throw th;
                    }
                }
            }
        }
    }

    private static synchronized void trim(Context context) {
        List<Sample> list;
        synchronized (PowerHistoryManager.class) {
            while (true) {
                list = data;
                if (list.size() > 7500) {
                    list.remove(0);
                } else {
                    try {
                        break;
                    } catch (Exception unused) {
                    }
                }
            }
            PrintWriter printWriter = new PrintWriter(new FileWriter(file(context)));
            try {
                for (Sample sample : list) {
                    printWriter.println(sample.t + "," + sample.level + "," + String.format(Locale.US, "%.2f", Double.valueOf(sample.watts)) + "," + sample.status + "," + String.format(Locale.US, "%.1f", Double.valueOf(sample.tempC)));
                }
                printWriter.close();
            } catch (Throwable th) {
                try {
                    printWriter.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    public static synchronized void clear(Context context) {
        synchronized (PowerHistoryManager.class) {
            data.clear();
            lastT = 0L;
            try {
                file(context).delete();
            } catch (Exception unused) {
            }
        }
    }

    public static synchronized float[] recentWatts(Context context, int i) {
        float[] fArr;
        synchronized (PowerHistoryManager.class) {
            load(context);
            long currentTimeMillis = System.currentTimeMillis() - (i * SAMPLE_MS);
            ArrayList arrayList = new ArrayList();
            for (int size = data.size() - 1; size >= 0; size--) {
                Sample sample = data.get(size);
                if (sample.t < currentTimeMillis) {
                    break;
                }
                arrayList.add(Float.valueOf((float) sample.watts));
            }
            fArr = new float[arrayList.size()];
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                fArr[i2] = ((Float) arrayList.get((arrayList.size() - 1) - i2)).floatValue();
            }
        }
        return fArr;
    }

    public static synchronized List<Session> sessions(Context context, int i) {
        ArrayList<Session> arrayList;
        synchronized (PowerHistoryManager.class) {
            load(context);
            arrayList = new ArrayList();
            for (int size = data.size() - 1; size >= 0 && arrayList.size() < i; size--) {
                Sample sample = data.get(size);
                boolean z = sample.status == 'C';
                if (!arrayList.isEmpty()) {
                    Session session = (Session) arrayList.get(arrayList.size() - 1);
                    if (session.charging == z && session.start - sample.t <= GAP_MS) {
                        session.start = sample.t;
                        session.startLevel = sample.level;
                        session.avgW += sample.watts;
                        session.maxW = Math.max(session.maxW, sample.watts);
                        session.samples++;
                    }
                }
                Session session2 = new Session();
                session2.charging = z;
                long j = sample.t;
                session2.end = j;
                session2.start = j;
                int i2 = sample.level;
                session2.endLevel = i2;
                session2.startLevel = i2;
                session2.avgW = sample.watts;
                session2.maxW = sample.watts;
                session2.samples = 1;
                arrayList.add(session2);
            }
            for (Session session3 : arrayList) {
                session3.energyWh = (session3.avgW * Math.max(1L, (session3.end - session3.start) / SAMPLE_MS)) / 60.0d;
                session3.avgW = session3.samples > 0 ? session3.avgW / session3.samples : 0.0d;
            }
        }
        return arrayList;
    }

    public static synchronized String todaySummary(Context context) {
        String sb;
        long j;
        synchronized (PowerHistoryManager.class) {
            load(context);
            Calendar calendar = Calendar.getInstance();
            calendar.set(11, 0);
            calendar.set(12, 0);
            calendar.set(13, 0);
            calendar.set(14, 0);
            long timeInMillis = calendar.getTimeInMillis();
            double d = 0.0d;
            int i = 0;
            double d2 = 0.0d;
            while (true) {
                List<Sample> list = data;
                if (i >= list.size()) {
                    break;
                }
                Sample sample = list.get(i);
                if (sample.t < timeInMillis) {
                    j = timeInMillis;
                } else {
                    long max = Math.max(1L, Math.min(GAP_MS, sample.t - (i > 0 ? list.get(i - 1).t : sample.t)) / SAMPLE_MS);
                    if (sample.status == 'C') {
                        j = timeInMillis;
                        d2 += (sample.watts * max) / 60.0d;
                    } else {
                        j = timeInMillis;
                        d += (sample.watts * max) / 60.0d;
                    }
                }
                i++;
                timeInMillis = j;
            }
            long j2 = timeInMillis;
            List<Session> sessions = sessions(context, 5);
            int i2 = 0;
            for (Session session : sessions) {
                if (session.charging && session.end >= j2) {
                    i2++;
                }
            }
            StringBuilder sb2 = new StringBuilder();
            if (data.isEmpty()) {
                sb2.append("暂无记录 · 保持应用运行自动采样");
            } else {
                sb2.append(String.format(Locale.US, "今日充电 %d 次 · %.1fWh ｜ 放电 %.1fWh", Integer.valueOf(i2), Double.valueOf(d2), Double.valueOf(d)));
                Session session2 = sessions.isEmpty() ? null : sessions.get(0);
                if (session2 != null) {
                    sb2.append(String.format(Locale.US, "%n最近: %s %d%%→%d%% · 平均%.1fW", session2.charging ? "充电" : "放电", Integer.valueOf(session2.startLevel), Integer.valueOf(session2.endLevel), Double.valueOf(session2.avgW)));
                }
            }
            sb = sb2.toString();
        }
        return sb;
    }

    public static synchronized String historyText(Context context, int i) {
        synchronized (PowerHistoryManager.class) {
            load(context);
            List<Session> sessions = sessions(context, i);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.US);
            StringBuilder sb = new StringBuilder();
            sb.append(todaySummary(context)).append("\n\n");
            if (sessions.isEmpty()) {
                sb.append("暂无历史会话");
                return sb.toString();
            }
            for (Session session : sessions) {
                long max = Math.max(1L, (session.end - session.start) / 1000);
                sb.append(String.format(Locale.US, "%s ~ %s (%d分%02d秒)%n  %s %d%%→%d%% · 平均 %.1fW · 峰值 %.1fW · %.1fWh%n", simpleDateFormat.format(new Date(session.start)), simpleDateFormat.format(new Date(session.end)), Long.valueOf(max / 60), Long.valueOf(max % 60), session.charging ? "充电" : "放电", Integer.valueOf(session.startLevel), Integer.valueOf(session.endLevel), Double.valueOf(session.avgW), Double.valueOf(session.maxW), Double.valueOf(session.energyWh)));
            }
            return sb.toString();
        }
    }

    public static synchronized List<Sample> recentSamples(Context context, int i) {
        ArrayList arrayList;
        synchronized (PowerHistoryManager.class) {
            load(context);
            long currentTimeMillis = System.currentTimeMillis() - (i * SAMPLE_MS);
            arrayList = new ArrayList();
            for (Sample sample : data) {
                if (sample.t >= currentTimeMillis) {
                    arrayList.add(sample);
                }
            }
        }
        return arrayList;
    }

    private static boolean immersiveOn(Context context) {
        return ThemeStore.transparentBg(context) || (ThemeStore.imageBg(context) && ThemeStore.bgFile(context).exists());
    }

    private static int glassA(Context context) {
        if (immersiveOn(context)) {
            return Math.max(120, Math.round(ThemeStore.glassAlpha(context) * 2.55f));
        }
        return 255;
    }

    public static void openDetail(final Activity activity) {
        new Thread(new Runnable() { // from class: Color.fc.PowerHistoryManager$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                PowerHistoryManager.lambda$openDetail$2(activity);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$openDetail$2(final Activity activity) {
        final PowerMonitor.BatteryStat batteryStat;
        final List<Sample> recentSamples = recentSamples(activity, 180);
        try {
            batteryStat = PowerMonitor.readOnce();
        } catch (Exception unused) {
            batteryStat = null;
        }
        activity.runOnUiThread(new Runnable() { // from class: Color.fc.PowerHistoryManager$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                PowerHistoryManager.lambda$openDetail$1(activity, recentSamples, batteryStat);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$openDetail$1(final Activity activity, List list, PowerMonitor.BatteryStat batteryStat) {
        AlertDialog show = new AlertDialog.Builder(activity).setTitle("功耗记录").setView(buildDetailBody(activity, list, batteryStat)).setPositiveButton("关闭", (DialogInterface.OnClickListener) null).setNeutralButton("清空记录", new DialogInterface.OnClickListener() { // from class: Color.fc.PowerHistoryManager$$ExternalSyntheticLambda0
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                PowerHistoryManager.lambda$openDetail$0(activity, dialogInterface, i);
            }
        }).show();
        if (!immersiveOn(activity) || show.getWindow() == null) {
            return;
        }
        ColorDrawable colorDrawable = new ColorDrawable(activity.getColor(R.color.bgCard));
        colorDrawable.setAlpha(glassA(activity));
        show.getWindow().setBackgroundDrawable(colorDrawable);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$openDetail$0(Activity activity, DialogInterface dialogInterface, int i) {
        clear(activity);
        Toast.makeText(activity, "已清空功耗记录", 0).show();
    }

    /* JADX WARN: Removed duplicated region for block: B:104:0x030e  */
    /* JADX WARN: Removed duplicated region for block: B:107:0x0354  */
    /* JADX WARN: Removed duplicated region for block: B:110:0x0379  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x039f  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x03c1  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x03e6  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x0405  */
    /* JADX WARN: Removed duplicated region for block: B:126:0x0425  */
    /* JADX WARN: Removed duplicated region for block: B:130:0x042a  */
    /* JADX WARN: Removed duplicated region for block: B:131:0x0414  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x03f5  */
    /* JADX WARN: Removed duplicated region for block: B:133:0x03c5  */
    /* JADX WARN: Removed duplicated region for block: B:136:0x03b0  */
    /* JADX WARN: Removed duplicated region for block: B:137:0x038a  */
    /* JADX WARN: Removed duplicated region for block: B:138:0x0365  */
    /* JADX WARN: Removed duplicated region for block: B:149:0x01c8  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x01b2  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x01f3  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static android.view.View buildDetailBody(android.content.Context r44, java.util.List<Color.fc.PowerHistoryManager.Sample> r45, Color.fc.PowerMonitor.BatteryStat r46) {
        /*
            Method dump skipped, instructions count: 1090
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: Color.fc.PowerHistoryManager.buildDetailBody(android.content.Context, java.util.List, Color.fc.PowerMonitor$BatteryStat):android.view.View");
    }

    private static LinearLayout colRow(Context context, int i, boolean z, String[]... strArr) {
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(0);
        for (String[] strArr2 : strArr) {
            LinearLayout linearLayout2 = new LinearLayout(context);
            linearLayout2.setOrientation(1);
            TextView textView = new TextView(context);
            textView.setText(strArr2[0]);
            textView.setTextColor(context.getColor(R.color.textDim));
            textView.setTextSize(9.0f);
            TextView textView2 = new TextView(context);
            textView2.setText(strArr2[1]);
            textView2.setTextSize(z ? 16.0f : 12.0f);
            textView2.setTypeface(Typeface.DEFAULT_BOLD);
            textView2.setTextColor(context.getColor(z ? R.color.accent : R.color.textPrimary));
            if (z) {
                linearLayout2.addView(textView2);
                linearLayout2.addView(textView);
            } else {
                linearLayout2.addView(textView);
                linearLayout2.addView(textView2);
            }
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
            layoutParams.topMargin = i * 10;
            linearLayout.addView(linearLayout2, layoutParams);
        }
        return linearLayout;
    }

    private static String fmtDur(long j) {
        long max = Math.max(0L, j / 1000);
        long j2 = max / 3600;
        long j3 = max % 3600;
        long j4 = j3 / 60;
        long j5 = j3 % 60;
        if (j2 > 0) {
            return j2 + "h" + j4 + "m" + j5 + "s";
        }
        if (j4 > 0) {
            return j4 + "m" + j5 + "s";
        }
        return j5 + "s";
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class SceneChart extends View {
        private final int cAccent;
        private final int cCard;
        private final int cDim;
        private final int cGreen;
        private final int cGrid;
        private final int cOrange;
        private final int cText;
        private final int cardAlpha;
        private final float dp;
        private final Paint pAxis;
        private final Paint pDot;
        private final Paint pFill;
        private final Paint pGrid;
        private final Paint pGridV;
        private final Paint pHeadL;
        private final Paint pHeadV;
        private final Paint pLab;
        private final Paint pLine;
        private final Paint pTemp;
        private final List<Sample> ss;

        private float xOf(long j, long j2, long j3, float f, float f2) {
            return f + ((f2 * ((float) (j - j2))) / ((float) j3));
        }

        SceneChart(Context context, List<Sample> list, int i) {
            super(context);
            Paint paint = new Paint(1);
            this.pGrid = paint;
            Paint paint2 = new Paint(1);
            this.pGridV = paint2;
            Paint paint3 = new Paint(1);
            this.pAxis = paint3;
            Paint paint4 = new Paint(1);
            this.pLab = paint4;
            Paint paint5 = new Paint(1);
            this.pHeadL = paint5;
            Paint paint6 = new Paint(1);
            this.pHeadV = paint6;
            Paint paint7 = new Paint(1);
            this.pLine = paint7;
            Paint paint8 = new Paint(1);
            this.pTemp = paint8;
            this.pFill = new Paint(1);
            Paint paint9 = new Paint(1);
            this.pDot = paint9;
            this.ss = list;
            this.cardAlpha = i;
            float f = context.getResources().getDisplayMetrics().density;
            this.dp = f;
            this.cAccent = context.getColor(R.color.accent);
            this.cGreen = context.getColor(R.color.green);
            int color = context.getColor(R.color.orange);
            this.cOrange = color;
            this.cCard = context.getColor(R.color.bgCard);
            this.cGrid = context.getColor(R.color.divider);
            int color2 = context.getColor(R.color.textSecondary);
            this.cDim = color2;
            int color3 = context.getColor(R.color.textPrimary);
            this.cText = color3;
            paint.setColor(color2);
            paint.setStrokeWidth(1.0f);
            paint.setAlpha(170);
            paint2.setColor(color2);
            paint2.setStrokeWidth(1.0f);
            paint2.setAlpha(70);
            paint3.setColor(color2);
            paint3.setStrokeWidth(1.0f);
            paint3.setAlpha(160);
            paint4.setColor(color2);
            paint4.setTextSize(f * 8.0f);
            paint5.setColor(color2);
            paint5.setTextSize(8.0f * f);
            paint6.setColor(color3);
            paint6.setTextSize(16.0f * f);
            paint6.setTypeface(Typeface.DEFAULT_BOLD);
            paint7.setStyle(Paint.Style.STROKE);
            paint7.setStrokeWidth(f * 1.2f);
            paint8.setColor(color);
            paint8.setStyle(Paint.Style.STROKE);
            paint8.setStrokeWidth(f * 1.2f);
            paint9.setStyle(Paint.Style.FILL);
        }

        /* JADX WARN: Removed duplicated region for block: B:37:0x0134 A[LOOP:2: B:35:0x012d->B:37:0x0134, LOOP_END] */
        /* JADX WARN: Removed duplicated region for block: B:42:0x01c4 A[LOOP:3: B:40:0x01c1->B:42:0x01c4, LOOP_END] */
        /* JADX WARN: Removed duplicated region for block: B:47:0x021e  */
        /* JADX WARN: Removed duplicated region for block: B:76:0x03c7  */
        /* JADX WARN: Removed duplicated region for block: B:90:0x0476  */
        /* JADX WARN: Removed duplicated region for block: B:94:0x0479  */
        /* JADX WARN: Removed duplicated region for block: B:95:0x046d  */
        @Override // android.view.View
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        protected void onDraw(android.graphics.Canvas r39) {
            /*
                Method dump skipped, instructions count: 1252
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: Color.fc.PowerHistoryManager.SceneChart.onDraw(android.graphics.Canvas):void");
        }

        private void stat(Canvas canvas, String str, String str2, float f) {
            canvas.drawText(str, f - (this.pHeadL.measureText(str) / 2.0f), this.dp * 13.0f, this.pHeadL);
            canvas.drawText(str2, f - (this.pHeadV.measureText(str2) / 2.0f), this.dp * 34.0f, this.pHeadV);
        }

        private float yOf(double d, float f, float f2, float f3) {
            double d2 = f3;
            return f - (f2 * ((float) (Math.max(0.0d, Math.min(d2, d)) / d2)));
        }
    }
}
