package Color.fc.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/* loaded from: classes.dex */
public class ChipView extends View {
    private final Paint chipPaint;
    private final Paint innerPaint;
    private String mainText;
    private final Paint pinPaint;
    private final Paint subPaint;
    private String subText;
    private final Paint textPaint;

    public ChipView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mainText = "SOC";
        this.subText = "--";
        this.chipPaint = new Paint(1);
        Paint paint = new Paint(1);
        this.pinPaint = paint;
        Paint paint2 = new Paint(1);
        this.innerPaint = paint2;
        Paint paint3 = new Paint(1);
        this.textPaint = paint3;
        Paint paint4 = new Paint(1);
        this.subPaint = paint4;
        paint.setColor(-8481878);
        paint2.setColor(872415231);
        paint3.setColor(-1);
        paint4.setColor(-855638017);
    }

    public void setChip(String str, String str2) {
        if (str == null) {
            str = "";
        }
        this.mainText = str;
        if (str2 == null) {
            str2 = "";
        }
        this.subText = str2;
        invalidate();
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        int dp = dp(96.0f);
        setMeasuredDimension(dp, dp);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        float dp = dp(7.0f);
        float f = 4.0f;
        float dp2 = dp + dp(4.0f);
        float f2 = width;
        float f3 = height;
        this.chipPaint.setShader(new LinearGradient(0.0f, 0.0f, f2, f3, -14856488, -12877066, Shader.TileMode.CLAMP));
        float f4 = f2 - dp2;
        float f5 = f3 - dp2;
        canvas.drawRoundRect(new RectF(dp2, dp2, f4, f5), dp(12.0f), dp(12.0f), this.chipPaint);
        this.pinPaint.setColor(-7362883);
        int i = 0;
        while (i < 4) {
            float f6 = dp2 + (((f2 - (2.0f * dp2)) * (i + 0.5f)) / f);
            float f7 = f3;
            canvas.drawRect(f6 - dp(1.5f), 0.0f, f6 + dp(1.5f), dp, this.pinPaint);
            f3 = f7;
            canvas.drawRect(f6 - dp(1.5f), f7 - dp, f6 + dp(1.5f), f3, this.pinPaint);
            i++;
            f2 = f2;
            f = 4.0f;
        }
        float f8 = f3;
        float f9 = f2;
        for (int i2 = 0; i2 < 3; i2++) {
            float f10 = dp2 + (((f8 - (dp2 * 2.0f)) * (i2 + 0.5f)) / 3.0f);
            canvas.drawRect(0.0f, f10 - dp(1.5f), dp, f10 + dp(1.5f), this.pinPaint);
            canvas.drawRect(f9 - dp, f10 - dp(1.5f), f9, f10 + dp(1.5f), this.pinPaint);
        }
        this.innerPaint.setStyle(Paint.Style.STROKE);
        this.innerPaint.setStrokeWidth(dp(1.0f));
        canvas.drawRoundRect(new RectF(dp(5.0f) + dp2, dp2 + dp(5.0f), f4 - dp(5.0f), f5 - dp(5.0f)), dp(8.0f), dp(8.0f), this.innerPaint);
        this.textPaint.setTextSize(dp(13.0f));
        this.textPaint.setFakeBoldText(true);
        float f11 = f8 / 2.0f;
        canvas.drawText(this.mainText, (f9 - this.textPaint.measureText(this.mainText)) / 2.0f, f11 - dp(1.0f), this.textPaint);
        this.subPaint.setTextSize(dp(9.0f));
        canvas.drawText(this.subText, (f9 - this.subPaint.measureText(this.subText)) / 2.0f, f11 + dp(13.0f), this.subPaint);
    }

    private int dp(float f) {
        return (int) ((f * getResources().getDisplayMetrics().density) + 0.5f);
    }
}
