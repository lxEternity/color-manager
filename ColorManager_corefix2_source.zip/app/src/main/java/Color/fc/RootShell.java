package Color.fc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.concurrent.TimeUnit;

/* loaded from: classes.dex */
public class RootShell {
    public static final String CONFIG_DIR = "/data/adb/modules/colorFC/config";
    public static final String GOV_DIR = "/data/adb/modules/colorFC/A";

    /* loaded from: classes.dex */
    public static class Result {
        public int code = -1;
        public String out = "";
        public String err = "";

        public boolean ok() {
            return this.code == 0;
        }
    }

    public static Result exec(String str) {
        return exec(str, 6);
    }

    public static Result exec(String str, int i) {
        Process exec;
        Result result = new Result();
        Process process = null;
        try {
            exec = Runtime.getRuntime().exec(new String[]{"su", "-c", str});
        } catch (Exception e) {
            result.err = String.valueOf(e);
            if (0 != 0) {
                process.destroyForcibly();
            }
        }
        if (!exec.waitFor(i, TimeUnit.SECONDS)) {
            exec.destroyForcibly();
            result.err = "timeout";
            return result;
        }
        result.out = readAll(exec.getInputStream());
        result.err = readAll(exec.getErrorStream());
        result.code = exec.exitValue();
        return result;
    }

    private static String readAll(InputStream inputStream) {
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder sb = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    bufferedReader.close();
                    return sb.toString();
                }
                sb.append(readLine).append('\n');
            }
        } catch (Exception unused) {
            return "";
        }
    }

    public static boolean hasRoot() {
        Result exec = exec("id");
        return exec.ok() && exec.out.contains("uid=0");
    }

    public static String readFile(String str) {
        Result exec = exec("cat '" + str + "'");
        if (exec.ok()) {
            return exec.out;
        }
        return null;
    }

    public static Result writeFile(File file, String str, String str2) {
        File file2;
        File file3 = null;
        try {
            try {
                file2 = new File(file, "colorfc_" + System.currentTimeMillis() + ".sh");
            } catch (Exception e) {
                e = e;
            }
        } catch (Throwable th) {
            th = th;
        }
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(file2), "UTF-8");
            outputStreamWriter.write(str);
            outputStreamWriter.flush();
            outputStreamWriter.close();
            Result exec = exec("cp '" + file2.getAbsolutePath() + "' '" + str2 + "' && chmod 755 '" + str2 + "'");
            file2.delete();
            return exec;
        } catch (Exception e2) {
            e = e2;
            file3 = file2;
            Result result = new Result();
            result.err = String.valueOf(e);
            if (file3 != null) {
                file3.delete();
            }
            return result;
        } catch (Throwable th2) {
            th = th2;
            file3 = file2;
            if (file3 != null) {
                file3.delete();
            }
            throw th;
        }
    }

    public static boolean writeFiles(File file, String[] strArr, String[] strArr2) {
        int length = strArr.length;
        File[] fileArr = new File[length];
        int i = 0;
        try {
            StringBuilder sb = new StringBuilder();
            for (int i2 = 0; i2 < strArr.length; i2++) {
                fileArr[i2] = new File(file, "colorfc_" + System.currentTimeMillis() + "_" + i2 + ".sh");
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(fileArr[i2]), "UTF-8");
                outputStreamWriter.write(strArr[i2]);
                outputStreamWriter.flush();
                outputStreamWriter.close();
                sb.append("cp '").append(fileArr[i2].getAbsolutePath()).append("' '").append(strArr2[i2]).append("' && chmod 755 '").append(strArr2[i2]).append("' && ");
            }
            sb.append("true");
            boolean ok = exec(sb.toString()).ok();
            while (i < length) {
                File file2 = fileArr[i];
                if (file2 != null) {
                    file2.delete();
                }
                i++;
            }
            return ok;
        } catch (Exception unused) {
            for (int i3 = 0; i3 < length; i3++) {
                File file3 = fileArr[i3];
                if (file3 != null) {
                    file3.delete();
                }
            }
            return false;
        } catch (Throwable th) {
            while (i < length) {
                File file4 = fileArr[i];
                if (file4 != null) {
                    file4.delete();
                }
                i++;
            }
            throw th;
        }
    }

    public static String getprop(String str) {
        String readLine;
        try {
            String str2 = (String) Class.forName("android.os.SystemProperties").getMethod("get", String.class, String.class).invoke(null, str, "");
            if (str2 != null && !str2.trim().isEmpty()) {
                return str2.trim();
            }
        } catch (Throwable unused) {
        }
        try {
            Process exec = Runtime.getRuntime().exec(new String[]{"getprop", str});
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(exec.getInputStream()));
            String readLine2 = bufferedReader.readLine();
            bufferedReader.close();
            exec.waitFor();
            if (readLine2 != null && !readLine2.trim().isEmpty()) {
                return readLine2.trim();
            }
        } catch (Exception unused2) {
        }
        try {
            File[] fileArr = {new File("/system/build.prop"), new File("/vendor/build.prop")};
            for (int i = 0; i < 2; i++) {
                File file = fileArr[i];
                if (file.canRead()) {
                    BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
                    do {
                        readLine = bufferedReader2.readLine();
                        if (readLine == null) {
                            bufferedReader2.close();
                        }
                    } while (!readLine.startsWith(str + "="));
                    bufferedReader2.close();
                    str = readLine.substring(str.length() + 1).trim();
                    return str;
                }
            }
        } catch (Exception unused3) {
        }
        Result exec2 = exec("getprop " + str);
        return exec2.out == null ? "" : exec2.out.trim();
    }
}
