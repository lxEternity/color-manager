package Color.fc;

import Color.fc.FrameRecordStore;
import Color.fc.MainActivity;
import Color.fc.PowerMonitor;
import Color.fc.view.ChipView;
import Color.fc.view.SparkView;
import Color.fc.view.Warp;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/* loaded from: classes.dex */
public class MainActivity extends ThemedActivity {
    static SocInfo cachedSoc;
    private TextView batteryLevel;
    private TextView batteryTemp;
    private TextView cellBadge;
    private ChipView chipView;
    private TextView cpuCount;
    private TextView currentValue;
    private TextView histHint;
    private SparkView histSpark;
    private TextView histToggle;
    private TextView monitorToggle;
    private TextView peakValue;
    private LinearLayout powerHistBox;
    private TextView powerStatus;
    private TextView powerValue;
    private TextView rootBadge;
    private SocInfo soc;
    private TextView socMarketing;
    private TextView socPlatform;
    private TextView voltageValue;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean rooted = false;
    private double peakWatts = 0.0d;
    private int cellMode = 0;
    private int lastAutoCells = 1;
    private boolean histExpanded = false;
    private long lastHistUpd = 0;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // Color.fc.ThemedActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        this.socMarketing = (TextView) findViewById(R.id.socMarketing);
        this.socPlatform = (TextView) findViewById(R.id.socPlatform);
        this.rootBadge = (TextView) findViewById(R.id.rootBadge);
        this.chipView = (ChipView) findViewById(R.id.chipView);
        this.powerValue = (TextView) findViewById(R.id.powerValue);
        this.powerStatus = (TextView) findViewById(R.id.powerStatus);
        this.currentValue = (TextView) findViewById(R.id.currentValue);
        this.voltageValue = (TextView) findViewById(R.id.voltageValue);
        this.peakValue = (TextView) findViewById(R.id.peakValue);
        this.cellBadge = (TextView) findViewById(R.id.cellBadge);
        this.cpuCount = (TextView) findViewById(R.id.cpuCount);
        this.batteryLevel = (TextView) findViewById(R.id.batteryLevel);
        this.batteryTemp = (TextView) findViewById(R.id.batteryTemp);
        wireBeam(R.id.menuSchedule, ScheduleActivity.class);
        wireBeam(R.id.menuGovernor, GovernorActivity.class);
        wireBeam(R.id.menuMode, ModeActivity.class);
        wireBeam(R.id.menuTheme, ThemeActivity.class);
        Warp.press(findViewById(R.id.socCard));
        Warp.press(findViewById(R.id.menuFrameRecords));
        Warp.press(findViewById(R.id.menuPowerRecords));
        detectSoc();
        detectRoot();
        startPowerLoop();
        AppLimitService.ensure(this);
        TextView textView = (TextView) findViewById(R.id.monitorToggle);
        this.monitorToggle = textView;
        textView.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.lambda$onCreate$0(view);
            }
        });
        TextView textView2 = (TextView) findViewById(R.id.histToggle);
        this.histToggle = textView2;
        textView2.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda17
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.lambda$onCreate$1(view);
            }
        });
        this.powerHistBox = (LinearLayout) findViewById(R.id.powerHistBox);
        this.histSpark = (SparkView) findViewById(R.id.histSpark);
        this.histHint = (TextView) findViewById(R.id.histHint);
        this.powerHistBox.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda18
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.lambda$onCreate$2(view);
            }
        });
        findViewById(R.id.menuFrameRecords).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda19
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.lambda$onCreate$3(view);
            }
        });
        findViewById(R.id.menuPowerRecords).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.lambda$onCreate$4(view);
            }
        });
        this.cellMode = getSharedPreferences("colorfc", 0).getInt("cellMode", 0);
        this.cellBadge.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda21
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.lambda$onCreate$5(view);
            }
        });
        updateCellModeFromPrefs();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(View view) {
        toggleMonitor(!MonitorService.running);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$1(View view) {
        toggleHist();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$2(View view) {
        PowerHistoryManager.openDetail(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$3(View view) {
        showFrameRecords();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$4(View view) {
        PowerHistoryManager.openDetail(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$5(View view) {
        showCellDialog();
    }

    private void wireBeam(int i, final Class<?> cls) {
        View findViewById = findViewById(i);
        Warp.press(findViewById);
        findViewById.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.lambda$wireBeam$6(cls, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$wireBeam$6(Class cls, View view) {
        startActivity(new Intent(this, (Class<?>) cls));
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    private void detectSoc() {
        SocInfo socInfo = cachedSoc;
        if (socInfo != null) {
            applySoc(socInfo);
        } else {
            new Thread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.lambda$detectSoc$8();
                }
            }).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$detectSoc$8() {
        cachedSoc = SocInfo.autoDetect();
        runOnUiThread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$detectSoc$7();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$detectSoc$7() {
        applySoc(cachedSoc);
    }

    private void applySoc(SocInfo socInfo) {
        this.soc = socInfo;
        this.chipView.setChip(socInfo.shortName, socInfo.code);
        this.socMarketing.setText(socInfo.marketing);
        this.socPlatform.setText(String.format(Locale.US, "platform: %s · %s", socInfo.platform, socInfo.vendor));
        int cpuCount = PowerMonitor.cpuCount();
        this.cpuCount.setText(cpuCount > 0 ? String.valueOf(cpuCount) : "--");
    }

    private void detectRoot() {
        new Thread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$detectRoot$10();
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$detectRoot$10() {
        this.rooted = RootShell.hasRoot();
        runOnUiThread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$detectRoot$9();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$detectRoot$9() {
        this.rootBadge.setText(this.rooted ? "ROOT 已授权" : "无 ROOT");
        ((GradientDrawable) this.rootBadge.getBackground().mutate()).setColor(this.rooted ? 638630273 : 653214788);
        this.rootBadge.setTextColor(this.rooted ? -15681151 : -1096636);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: Color.fc.MainActivity$1, reason: invalid class name */
    /* loaded from: classes.dex */
    public class AnonymousClass1 implements Runnable {
        AnonymousClass1() {
        }

        @Override // java.lang.Runnable
        public void run() {
            new Thread(new Runnable() { // from class: Color.fc.MainActivity$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.AnonymousClass1.this.lambda$run$1();
                }
            }).start();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$run$1() {
            final PowerMonitor.BatteryStat readOnce = PowerMonitor.readOnce();
            if (readOnce != null) {
                readOnce.watts = PowerMonitor.applyCellMode(readOnce, MainActivity.this.cellMode);
                PowerHistoryManager.record(MainActivity.this, readOnce);
                if (System.currentTimeMillis() - MainActivity.this.lastHistUpd > 60000) {
                    MainActivity.this.lastHistUpd = System.currentTimeMillis();
                    MainActivity.this.refreshHistCurve();
                }
            }
            MainActivity.this.runOnUiThread(new Runnable() { // from class: Color.fc.MainActivity$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.AnonymousClass1.this.lambda$run$0(readOnce);
                }
            });
            MainActivity.this.handler.postDelayed(this, 1000L);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$run$0(PowerMonitor.BatteryStat batteryStat) {
            if (batteryStat != null) {
                MainActivity.this.updatePower(batteryStat);
            }
        }
    }

    private void startPowerLoop() {
        this.handler.postDelayed(new AnonymousClass1(), 300L);
    }

    private void updateCellModeFromPrefs() {
        this.cellMode = getSharedPreferences("colorfc", 0).getInt("cellMode", 0);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // Color.fc.ThemedActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        updateCellModeFromPrefs();
        syncMonitorUi();
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
    }

    private void syncMonitorUi() {
        int color;
        TextView textView = this.monitorToggle;
        if (textView != null) {
            if (MonitorService.running) {
                color = getResources().getColor(R.color.accent);
            } else {
                color = getResources().getColor(R.color.textSecondary);
            }
            textView.setTextColor(color);
        }
    }

    private void toggleMonitor(boolean z) {
        if (z) {
            if (!Settings.canDrawOverlays(this)) {
                syncMonitorUi();
                Toast.makeText(this, "请先授予悬浮窗权限后重试", 1).show();
                startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())));
                return;
            }
            startForegroundService(new Intent(this, (Class<?>) MonitorService.class));
        } else {
            SharedPreferences sharedPreferences = getSharedPreferences("colorfc", 0);
            if (MonitorService.running && sharedPreferences.getBoolean("mon_pill_hidden", false)) {
                Intent intent = new Intent(this, (Class<?>) MonitorService.class);
                intent.setAction("show_pill");
                startForegroundService(intent);
            } else {
                stopService(new Intent(this, (Class<?>) MonitorService.class));
            }
        }
        syncMonitorUi();
    }

    private void toggleHist() {
        int color;
        boolean z = !this.histExpanded;
        this.histExpanded = z;
        this.powerHistBox.setVisibility(z ? 0 : 8);
        this.histToggle.setText(this.histExpanded ? "功耗统计 ▴" : "功耗统计 ▾");
        TextView textView = this.histToggle;
        if (this.histExpanded) {
            color = getResources().getColor(R.color.accent);
        } else {
            color = getResources().getColor(R.color.textSecondary);
        }
        textView.setTextColor(color);
        if (this.histExpanded) {
            refreshHistCurve();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void refreshHistCurve() {
        new Thread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda22
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$refreshHistCurve$12();
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$refreshHistCurve$12() {
        final float[] recentWatts = PowerHistoryManager.recentWatts(this, 180);
        runOnUiThread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$refreshHistCurve$11(recentWatts);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$refreshHistCurve$11(float[] fArr) {
        SparkView sparkView = this.histSpark;
        if (sparkView == null) {
            return;
        }
        sparkView.setData(fArr);
        if (fArr.length == 0) {
            this.histHint.setText("暂无记录 · 采样中");
            return;
        }
        double d = 0.0d;
        double d2 = 0.0d;
        for (double d3 : fArr) {
            d += d3;
            if (d3 > d2) {
                d2 = d3;
            }
        }
        this.histHint.setText(String.format(Locale.US, "近3小时 · 均值 %.2f W · 峰值 %.2f W", Double.valueOf(d / fArr.length), Double.valueOf(d2)));
    }

    private void showFrameRecords() {
        new Thread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$showFrameRecords$16();
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showFrameRecords$16() {
        final List<FrameRecordStore.Rec> list = FrameRecordStore.list(this);
        final String[] strArr = new String[list.size()];
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd HH:mm", Locale.US);
        for (int i = 0; i < list.size(); i++) {
            FrameRecordStore.Rec rec = list.get(i);
            strArr[i] = String.format(Locale.US, "%s · %d:%02d · 均%.0fHz · CPU峰%.0f%%", simpleDateFormat.format(new Date(rec.t)), Long.valueOf(rec.dur / 60000), Long.valueOf((rec.dur / 1000) % 60), Double.valueOf(rec.avgFps), Double.valueOf(rec.maxCpu));
        }
        runOnUiThread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$showFrameRecords$15(list, strArr);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showFrameRecords$15(final List list, String[] strArr) {
        if (list.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("帧率录制记录").setMessage("暂无录制\n\n开启【监视器功能】→ 点击状态栏\"监视器\"展开列表 → 打开\"帧率记录器\"，点击帧率窗口开始录制，再次点击停止并自动保存曲线图（帧率 / CPU线程负载 / CPU使用率）").setPositiveButton("关闭", (DialogInterface.OnClickListener) null).show();
        } else {
            new AlertDialog.Builder(this).setTitle("帧率录制记录").setItems(strArr, new DialogInterface.OnClickListener() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda11
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.this.lambda$showFrameRecords$13(list, dialogInterface, i);
                }
            }).setNeutralButton("清空", new DialogInterface.OnClickListener() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda15
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.this.lambda$showFrameRecords$14(dialogInterface, i);
                }
            }).setPositiveButton("关闭", (DialogInterface.OnClickListener) null).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showFrameRecords$13(List list, DialogInterface dialogInterface, int i) {
        showRecordImage((FrameRecordStore.Rec) list.get(i));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showFrameRecords$14(DialogInterface dialogInterface, int i) {
        confirmClearRecords();
    }

    private void showRecordImage(final FrameRecordStore.Rec rec) {
        new Thread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$showRecordImage$18(rec);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showRecordImage$18(final FrameRecordStore.Rec rec) {
        final Bitmap bitmap = null;
        try {
            if (rec.ref != null && rec.ref.startsWith("content://")) {
                InputStream openInputStream = getContentResolver().openInputStream(Uri.parse(rec.ref));
                try {
                    bitmap = BitmapFactory.decodeStream(openInputStream);
                    if (openInputStream != null) {
                        openInputStream.close();
                    }
                } finally {
                }
            } else if (rec.ref != null) {
                bitmap = BitmapFactory.decodeFile(rec.ref);
            }
        } catch (Exception unused) {
        }
        runOnUiThread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$showRecordImage$17(bitmap, rec);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showRecordImage$17(Bitmap bitmap, FrameRecordStore.Rec rec) {
        if (bitmap == null) {
            Toast.makeText(this, "曲线图已被删除或无法读取", 0).show();
            return;
        }
        ImageView imageView = new ImageView(this);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setAdjustViewBounds(true);
        imageView.setImageBitmap(bitmap);
        ScrollView scrollView = new ScrollView(this);
        scrollView.addView(imageView);
        new AlertDialog.Builder(this).setTitle(String.format(Locale.US, "录制 %d:%02d · 均%.0fHz", Long.valueOf(rec.dur / 60000), Long.valueOf((rec.dur / 1000) % 60), Double.valueOf(rec.avgFps))).setView(scrollView).setPositiveButton("关闭", (DialogInterface.OnClickListener) null).show();
    }

    private void confirmClearRecords() {
        new AlertDialog.Builder(this).setTitle("清空录制记录").setMessage("将删除全部录制记录及曲线图，确定？").setPositiveButton("清空", new DialogInterface.OnClickListener() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda2
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.lambda$confirmClearRecords$21(dialogInterface, i);
            }
        }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$confirmClearRecords$21(DialogInterface dialogInterface, int i) {
        new Thread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$confirmClearRecords$20();
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$confirmClearRecords$20() {
        FrameRecordStore.clear(this);
        runOnUiThread(new Runnable() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.lambda$confirmClearRecords$19();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$confirmClearRecords$19() {
        Toast.makeText(this, "已清空录制记录", 0).show();
    }

    private void showCellDialog() {
        String[] strArr = new String[3];
        int i = 2;
        strArr[0] = "自动校准（当前识别: " + (this.lastAutoCells >= 2 ? "双电芯" : "单电芯") + "）";
        strArr[1] = "强制双电芯（电流×2）";
        strArr[2] = "强制单电芯";
        int i2 = this.cellMode;
        if (i2 == 2) {
            i = 1;
        } else if (i2 != 1) {
            i = 0;
        }
        new AlertDialog.Builder(this).setTitle("电芯模式").setSingleChoiceItems(strArr, i, new DialogInterface.OnClickListener() { // from class: Color.fc.MainActivity$$ExternalSyntheticLambda14
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i3) {
                MainActivity.this.lambda$showCellDialog$22(dialogInterface, i3);
            }
        }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showCellDialog$22(DialogInterface dialogInterface, int i) {
        this.cellMode = i != 1 ? i == 2 ? 1 : 0 : 2;
        getSharedPreferences("colorfc", 0).edit().putInt("cellMode", this.cellMode).commit();
        dialogInterface.dismiss();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updatePower(PowerMonitor.BatteryStat batteryStat) {
        String str;
        this.lastAutoCells = batteryStat.cells;
        int i = this.cellMode;
        if (i == 0) {
            i = batteryStat.cells;
        }
        boolean z = i >= 2 && batteryStat.cells < 2;
        double d = batteryStat.amps;
        if (z) {
            d *= 2.0d;
        }
        double abs = Math.abs(z ? batteryStat.volts * d : batteryStat.watts);
        this.powerValue.setText(abs > 0.0d ? String.format(Locale.US, "%.2f", Double.valueOf(abs)) : "--");
        if (abs > this.peakWatts) {
            this.peakWatts = abs;
        }
        this.peakValue.setText(this.peakWatts > 0.0d ? String.format(Locale.US, "%.2f W", Double.valueOf(this.peakWatts)) : "--");
        if (batteryStat.status.isEmpty()) {
            str = d > 0.0d ? "放电" : "充电";
        } else if ("Charging".equalsIgnoreCase(batteryStat.status)) {
            str = "充电中";
        } else {
            str = "Full".equalsIgnoreCase(batteryStat.status) ? "已充满" : "放电中";
        }
        this.powerStatus.setText(str);
        this.powerStatus.setTextColor("Charging".equalsIgnoreCase(batteryStat.status) ? -16730717 : -2061824);
        this.currentValue.setText(d != 0.0d ? String.format(Locale.US, "%.0f mA", Double.valueOf(Math.abs(d) * 1000.0d)) : "--");
        this.voltageValue.setText(batteryStat.volts > 0.0d ? String.format(Locale.US, "%.2f V", Double.valueOf(batteryStat.volts)) : "--");
        this.cellBadge.setText((i >= 2 ? "双电芯" : "单电芯").concat(this.cellMode == 0 ? " · 已校准 ▸" : " · 手动 ▸"));
        if (batteryStat.level >= 0) {
            this.batteryLevel.setText(batteryStat.level + "%");
        }
        if (batteryStat.tempC > 0.0d) {
            this.batteryTemp.setText(String.format(Locale.US, "%.1f℃", Double.valueOf(batteryStat.tempC)));
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        this.handler.removeCallbacksAndMessages(null);
    }
}
