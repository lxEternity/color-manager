package Color.fc;

import Color.fc.view.Warp;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;

/* loaded from: classes.dex */
public class ThemeActivity extends ThemedActivity {
    private static final int REQ_PICK = 71;
    private TextView alphaValue;
    private TextView chipDay;
    private TextView chipNight;
    private TextView clearBtn;
    private TextView glassValue;
    private LinearLayout imageGroup;
    private TextView offXValue;
    private TextView offYValue;
    private TextView pickBtn;
    private ImageView preview;
    private TextView scaleValue;
    private Switch swImage;
    private Switch swLiquid;
    private Switch swTransparent;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public interface OnSeek {
        void onSeek(SeekBar seekBar, int i);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // Color.fc.ThemedActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(dp(12), 0, dp(12), dp(24));
        scrollView.addView(linearLayout);
        setContentView(scrollView);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setPadding(0, dp(14), 0, dp(10));
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(R.drawable.ic_back);
        imageView.setPadding(dp(8), dp(8), dp(8), dp(8));
        TypedValue typedValue = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, typedValue, true);
        imageView.setBackgroundResource(typedValue.resourceId);
        imageView.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ThemeActivity.this.lambda$onCreate$0(view);
            }
        });
        linearLayout2.addView(imageView, new LinearLayout.LayoutParams(dp(40), dp(40)));
        TextView textView = new TextView(this);
        textView.setText("主题与背景");
        textView.setTextSize(19.0f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextColor(getResources().getColor(R.color.textPrimary));
        linearLayout2.addView(textView, new LinearLayout.LayoutParams(-2, -2));
        linearLayout.addView(linearLayout2);
        LinearLayout card = card();
        card.addView(label("外观"));
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(0);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = dp(6);
        linearLayout3.setLayoutParams(layoutParams);
        this.chipDay = segChip("日间");
        this.chipNight = segChip("夜间");
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams2.rightMargin = dp(3);
        linearLayout3.addView(this.chipDay, layoutParams2);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams3.leftMargin = dp(3);
        linearLayout3.addView(this.chipNight, layoutParams3);
        card.addView(linearLayout3);
        linearLayout.addView(card);
        this.chipDay.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ThemeActivity.this.lambda$onCreate$1(view);
            }
        });
        this.chipNight.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ThemeActivity.this.lambda$onCreate$2(view);
            }
        });
        LinearLayout card2 = card();
        card2.addView(label("背景沉浸"));
        LinearLayout row = row("全透明背景");
        Switch r5 = new Switch(this);
        this.swTransparent = r5;
        row.addView(r5);
        card2.addView(row);
        this.swTransparent.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda11
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                ThemeActivity.this.lambda$onCreate$3(compoundButton, z);
            }
        });
        LinearLayout row2 = row("控件透明度");
        TextView val = val();
        this.glassValue = val;
        row2.addView(val);
        card2.addView(row2);
        card2.addView(seek(30, 100, ThemeStore.glassAlpha(this), new OnSeek() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda12
            @Override // Color.fc.ThemeActivity.OnSeek
            public final void onSeek(SeekBar seekBar, int i) {
                ThemeActivity.this.lambda$onCreate$4(seekBar, i);
            }
        }));
        LinearLayout row3 = row("液态玻璃");
        Switch r52 = new Switch(this);
        this.swLiquid = r52;
        row3.addView(r52);
        card2.addView(row3);
        this.swLiquid.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda13
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                ThemeActivity.this.lambda$onCreate$5(compoundButton, z);
            }
        });
        card2.addView(divider());
        LinearLayout row4 = row("自定义背景图片");
        Switch r53 = new Switch(this);
        this.swImage = r53;
        row4.addView(r53);
        card2.addView(row4);
        this.swImage.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda14
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                ThemeActivity.this.lambda$onCreate$6(compoundButton, z);
            }
        });
        LinearLayout linearLayout4 = new LinearLayout(this);
        this.imageGroup = linearLayout4;
        linearLayout4.setOrientation(1);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.topMargin = dp(4);
        this.imageGroup.setLayoutParams(layoutParams4);
        ImageView imageView2 = new ImageView(this);
        this.preview = imageView2;
        imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
        this.preview.setOutlineProvider(new ViewOutlineProvider() { // from class: Color.fc.ThemeActivity.1
            @Override // android.view.ViewOutlineProvider
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), ThemeActivity.this.dp(12));
            }
        });
        this.preview.setClipToOutline(true);
        this.imageGroup.addView(this.preview, new LinearLayout.LayoutParams(-1, dp(132)));
        LinearLayout linearLayout5 = new LinearLayout(this);
        linearLayout5.setOrientation(0);
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams5.topMargin = dp(8);
        linearLayout5.setLayoutParams(layoutParams5);
        this.pickBtn = textBtn("选择图片", R.color.accent);
        this.clearBtn = textBtn("清除图片", R.color.red);
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams6.rightMargin = dp(3);
        linearLayout5.addView(this.pickBtn, layoutParams6);
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams7.leftMargin = dp(3);
        linearLayout5.addView(this.clearBtn, layoutParams7);
        this.imageGroup.addView(linearLayout5);
        this.imageGroup.setVisibility(0);
        card2.addView(this.imageGroup);
        this.pickBtn.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ThemeActivity.this.lambda$onCreate$7(view);
            }
        });
        this.clearBtn.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ThemeActivity.this.lambda$onCreate$8(view);
            }
        });
        card2.addView(divider());
        LinearLayout row5 = row("背景透明度");
        TextView val2 = val();
        this.alphaValue = val2;
        row5.addView(val2);
        card2.addView(row5);
        card2.addView(seek(5, 100, ThemeStore.bgAlpha(this), new OnSeek() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda3
            @Override // Color.fc.ThemeActivity.OnSeek
            public final void onSeek(SeekBar seekBar, int i) {
                ThemeActivity.this.lambda$onCreate$9(seekBar, i);
            }
        }));
        LinearLayout row6 = row("背景缩放");
        TextView val3 = val();
        this.scaleValue = val3;
        row6.addView(val3);
        card2.addView(row6);
        card2.addView(seek(100, 300, ThemeStore.bgScale(this), new OnSeek() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda6
            @Override // Color.fc.ThemeActivity.OnSeek
            public final void onSeek(SeekBar seekBar, int i) {
                ThemeActivity.this.lambda$onCreate$10(seekBar, i);
            }
        }));
        LinearLayout row7 = row("取景偏移 左右");
        TextView val4 = val();
        this.offXValue = val4;
        row7.addView(val4);
        card2.addView(row7);
        card2.addView(seek(-50, 50, ThemeStore.bgOffX(this), new OnSeek() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda7
            @Override // Color.fc.ThemeActivity.OnSeek
            public final void onSeek(SeekBar seekBar, int i) {
                ThemeActivity.this.lambda$onCreate$11(seekBar, i);
            }
        }));
        LinearLayout row8 = row("取景偏移 上下");
        TextView val5 = val();
        this.offYValue = val5;
        row8.addView(val5);
        card2.addView(row8);
        card2.addView(seek(-50, 50, ThemeStore.bgOffY(this), new OnSeek() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda8
            @Override // Color.fc.ThemeActivity.OnSeek
            public final void onSeek(SeekBar seekBar, int i) {
                ThemeActivity.this.lambda$onCreate$12(seekBar, i);
            }
        }));
        linearLayout.addView(card2);
        refreshAll();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(View view) {
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$1(View view) {
        if (ThemeStore.dark(this)) {
            ThemeStore.setDark(this, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$2(View view) {
        if (ThemeStore.dark(this)) {
            return;
        }
        ThemeStore.setDark(this, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$3(CompoundButton compoundButton, boolean z) {
        if (z && this.swImage != null) {
            ThemeStore.setImageBg(this, false);
            this.swImage.setChecked(false);
        }
        ThemeStore.setTransparent(this, z);
        ThemeStore.applyBackground(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$4(SeekBar seekBar, int i) {
        ThemeStore.setGlass(this, i);
        this.glassValue.setText(i + "%");
        ThemeStore.applyBackground(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$5(CompoundButton compoundButton, boolean z) {
        ThemeStore.setLiquid(this, z);
        ThemeStore.applyBackground(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$6(CompoundButton compoundButton, boolean z) {
        if (z && this.swTransparent != null) {
            ThemeStore.setTransparent(this, false);
            this.swTransparent.setChecked(false);
        }
        ThemeStore.setImageBg(this, z);
        ThemeStore.applyBackground(this);
        refreshPreview();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$7(View view) {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType("image/*");
        try {
            startActivityForResult(Intent.createChooser(intent, "选择背景图片"), REQ_PICK);
        } catch (Exception unused) {
            Toast.makeText(this, "未找到可用的图片选择器", 0).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$8(View view) {
        File bgFile = ThemeStore.bgFile(this);
        if (bgFile.exists() && bgFile.delete()) {
            ThemeStore.setImageBg(this, false);
            ThemeStore.invalidate();
            ThemeStore.applyBackground(this);
            this.swImage.setChecked(false);
            refreshPreview();
            Toast.makeText(this, "已清除背景图片", 0).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$9(SeekBar seekBar, int i) {
        ThemeStore.setBgAlpha(this, i);
        this.alphaValue.setText(i + "%");
        ThemeStore.applyBackground(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$10(SeekBar seekBar, int i) {
        ThemeStore.setBgScale(this, i);
        this.scaleValue.setText(i + "%");
        ThemeStore.applyBackground(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$11(SeekBar seekBar, int i) {
        ThemeStore.setBgOffX(this, i);
        this.offXValue.setText(i + "%");
        ThemeStore.applyBackground(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$12(SeekBar seekBar, int i) {
        ThemeStore.setBgOffY(this, i);
        this.offYValue.setText(i + "%");
        ThemeStore.applyBackground(this);
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i != REQ_PICK || i2 != -1 || intent == null || intent.getData() == null) {
            return;
        }
        final Uri data = intent.getData();
        new Thread(new Runnable() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                ThemeActivity.this.lambda$onActivityResult$14(data);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onActivityResult$14(Uri uri) {
        final boolean saveBg = saveBg(uri);
        runOnUiThread(new Runnable() { // from class: Color.fc.ThemeActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                ThemeActivity.this.lambda$onActivityResult$13(saveBg);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onActivityResult$13(boolean z) {
        if (!z) {
            Toast.makeText(this, "图片读取失败，请换一张", 0).show();
            return;
        }
        ThemeStore.setImageBg(this, true);
        ThemeStore.invalidate();
        ThemeStore.applyBackground(this);
        this.swImage.setChecked(true);
        refreshPreview();
        Toast.makeText(this, "背景已更新", 0).show();
    }

    private boolean saveBg(Uri uri) {
        try {
            InputStream openInputStream = getContentResolver().openInputStream(uri);
            try {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeStream(openInputStream, null, options);
                int i = 1;
                while (true) {
                    int i2 = i * 2;
                    if (Math.max(options.outWidth, options.outHeight) / i2 < 2560) {
                        break;
                    }
                    i = i2;
                }
                InputStream openInputStream2 = getContentResolver().openInputStream(uri);
                try {
                    BitmapFactory.Options options2 = new BitmapFactory.Options();
                    options2.inSampleSize = i;
                    Bitmap decodeStream = BitmapFactory.decodeStream(openInputStream2, null, options2);
                    if (decodeStream == null) {
                        if (openInputStream2 != null) {
                            openInputStream2.close();
                        }
                        if (openInputStream != null) {
                            openInputStream.close();
                        }
                        return false;
                    }
                    OutputStream newOutputStream = Files.newOutputStream(ThemeStore.bgFile(this).toPath(), new OpenOption[0]);
                    try {
                        decodeStream.compress(Bitmap.CompressFormat.JPEG, 90, newOutputStream);
                        if (newOutputStream != null) {
                            newOutputStream.close();
                        }
                        decodeStream.recycle();
                        if (openInputStream2 != null) {
                            openInputStream2.close();
                        }
                        if (openInputStream != null) {
                            openInputStream.close();
                        }
                        return true;
                    } finally {
                    }
                } finally {
                }
            } finally {
            }
        } catch (Exception unused) {
            return false;
        }
    }

    private void refreshAll() {
        boolean dark = ThemeStore.dark(this);
        styleChip(this.chipDay, !dark);
        styleChip(this.chipNight, dark);
        boolean z = ThemeStore.imageBg(this) && ThemeStore.bgFile(this).exists();
        if (z && ThemeStore.transparentBg(this)) {
            ThemeStore.setTransparent(this, false);
        }
        this.swTransparent.setChecked(ThemeStore.transparentBg(this));
        this.swImage.setChecked(z);
        this.alphaValue.setText(ThemeStore.bgAlpha(this) + "%");
        this.scaleValue.setText(ThemeStore.bgScale(this) + "%");
        this.offXValue.setText(ThemeStore.bgOffX(this) + "%");
        this.offYValue.setText(ThemeStore.bgOffY(this) + "%");
        this.glassValue.setText(ThemeStore.glassAlpha(this) + "%");
        this.swLiquid.setChecked(ThemeStore.liquidGlass(this));
        refreshPreview();
    }

    private void refreshPreview() {
        File bgFile = ThemeStore.bgFile(this);
        boolean exists = bgFile.exists();
        this.imageGroup.setVisibility((exists || this.swImage.isChecked()) ? 0 : 8);
        this.clearBtn.setVisibility(exists ? 0 : 8);
        if (exists) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 4;
            Bitmap decodeFile = BitmapFactory.decodeFile(bgFile.getAbsolutePath(), options);
            this.preview.clearColorFilter();
            this.preview.setBackgroundResource(0);
            this.preview.setImageBitmap(decodeFile);
            return;
        }
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(dp(12));
        gradientDrawable.setColor(getResources().getColor(R.color.bgInput));
        gradientDrawable.setStroke(dp(1), getResources().getColor(R.color.bgInputStroke));
        this.preview.setBackground(gradientDrawable);
        this.preview.setImageResource(android.R.drawable.ic_menu_gallery);
        this.preview.setColorFilter(getResources().getColor(R.color.textDim), PorterDuff.Mode.SRC_ATOP);
    }

    private LinearLayout card() {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundResource(R.drawable.bg_card);
        linearLayout.setPadding(dp(12), dp(10), dp(12), dp(12));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = dp(8);
        linearLayout.setLayoutParams(layoutParams);
        return linearLayout;
    }

    private TextView label(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextSize(14.0f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextColor(getResources().getColor(R.color.textPrimary));
        return textView;
    }

    private LinearLayout row(String str) {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = dp(8);
        linearLayout.setLayoutParams(layoutParams);
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextSize(13.0f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextColor(getResources().getColor(R.color.textPrimary));
        linearLayout.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        return linearLayout;
    }

    private TextView val() {
        TextView textView = new TextView(this);
        textView.setTextSize(12.0f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextColor(getResources().getColor(R.color.accent));
        return textView;
    }

    private View divider() {
        View view = new View(this);
        view.setBackgroundColor(getResources().getColor(R.color.divider));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 1);
        layoutParams.topMargin = dp(10);
        layoutParams.bottomMargin = dp(2);
        view.setLayoutParams(layoutParams);
        return view;
    }

    private SeekBar seek(final int i, int i2, int i3, final OnSeek onSeek) {
        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(i2 - i);
        seekBar.setProgress(i3 - i);
        try {
            seekBar.getProgressDrawable().setColorFilter(getResources().getColor(R.color.accent), PorterDuff.Mode.SRC_IN);
            seekBar.getThumb().setColorFilter(getResources().getColor(R.color.accent), PorterDuff.Mode.SRC_IN);
        } catch (Exception unused) {
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = dp(2);
        seekBar.setLayoutParams(layoutParams);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: Color.fc.ThemeActivity.2
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar seekBar2) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar seekBar2) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar seekBar2, int i4, boolean z) {
                if (z) {
                    onSeek.onSeek(seekBar2, i + i4);
                }
            }
        });
        return seekBar;
    }

    private TextView segChip(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setGravity(17);
        textView.setTextSize(13.0f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setBackgroundResource(R.drawable.bg_tab);
        textView.setPadding(0, dp(9), 0, dp(9));
        return textView;
    }

    private void styleChip(TextView textView, boolean z) {
        textView.setBackgroundResource(z ? R.drawable.bg_tab_sel : R.drawable.bg_tab);
        textView.setTextColor(getResources().getColor(z ? R.color.accent : R.color.textSecondary));
    }

    private TextView textBtn(String str, int i) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setGravity(17);
        textView.setTextSize(13.0f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextColor(getResources().getColor(i));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(dp(11));
        gradientDrawable.setColor(getResources().getColor(R.color.bgInput));
        gradientDrawable.setStroke(dp(1), getResources().getColor(i));
        textView.setBackground(gradientDrawable);
        textView.setPadding(0, dp(9), 0, dp(9));
        Warp.press(textView);
        return textView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }
}
