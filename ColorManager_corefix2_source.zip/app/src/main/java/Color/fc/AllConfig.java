package Color.fc;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* loaded from: classes.dex */
public class AllConfig {
    public final Map<String, Mode> modes = new LinkedHashMap();
    public static final String[] MODE_KEYS = {"powersave", "balance", "performance", "fast"};
    public static final String[] MODE_NAMES = {"省电模式", "均衡模式", "性能模式", "极速模式"};
    public static final String[] MODE_DESC = {"powersave · 最长续航，压制频率与提升值", "balance · 日常使用，兼顾流畅与功耗", "performance · 高负载场景，激进提升", "fast · 极限性能，全力释放"};
    private static final Pattern P_ACTION = Pattern.compile("\\[\\[ \\$action == \"(\\w+)\" ]]");
    private static final Pattern P_OPT2 = Pattern.compile("opt2 (\\S+)");
    private static final Pattern P_JSON = Pattern.compile("json_cpu_max_min \"(\\S+)\" \"(\\S+)\"");
    private static final Pattern P_LLCC = Pattern.compile("llcc\\.sh set_max_freq (\\S+)");
    private static final Pattern P_ECHO = Pattern.compile("echo \"?([\\w.-]+)\"? > (\\S+)");
    private static final Pattern P_WALT = Pattern.compile("walt_up_rate_limit_us \"(\\S+)\" \"(\\S+)\"");

    /* loaded from: classes.dex */
    public static class Mode {
        public String opt2 = "0";
        public String cpuMax = "42";
        public String cpuMin = "5";
        public String llcc = "350000";
        public String uclampDisplay = "6";
        public String uclampSsfg = "5";
        public String uclampTouch = "8";
        public String uclampMm = "6";
        public String uclampRt = "3";
        public String uclampTopApp = "10";
        public String walt1 = "0";
        public String walt2 = "1500";
    }

    public static AllConfig defaults() {
        AllConfig allConfig = new AllConfig();
        Mode mode = new Mode();
        mode.opt2 = "0";
        mode.cpuMax = "42";
        mode.cpuMin = "5";
        mode.llcc = "350000";
        mode.uclampDisplay = "6";
        mode.uclampSsfg = "5";
        mode.uclampTouch = "8";
        mode.uclampMm = "6";
        mode.uclampRt = "3";
        mode.uclampTopApp = "10";
        Mode mode2 = new Mode();
        mode2.opt2 = "26";
        mode2.cpuMax = "64";
        mode2.cpuMin = "20";
        mode2.llcc = "680000";
        mode2.uclampDisplay = "30";
        mode2.uclampSsfg = "28";
        mode2.uclampTouch = "40";
        mode2.uclampMm = "32";
        mode2.uclampRt = "40";
        mode2.uclampTopApp = "26";
        Mode mode3 = new Mode();
        mode3.opt2 = "52";
        mode3.cpuMax = "90";
        mode3.cpuMin = "35";
        mode3.llcc = "1220000";
        mode3.uclampDisplay = "78";
        mode3.uclampSsfg = "76";
        mode3.uclampTouch = "92";
        mode3.uclampMm = "80";
        mode3.uclampRt = "92";
        mode3.uclampTopApp = "74";
        Mode mode4 = new Mode();
        mode4.opt2 = "88";
        mode4.cpuMax = "100";
        mode4.cpuMin = "42";
        mode4.llcc = "1800000";
        mode4.uclampDisplay = "82";
        mode4.uclampSsfg = "80";
        mode4.uclampTouch = "94";
        mode4.uclampMm = "84";
        mode4.uclampRt = "94";
        mode4.uclampTopApp = "78";
        mode4.walt1 = "0";
        mode4.walt2 = "1500";
        allConfig.modes.put("powersave", mode);
        allConfig.modes.put("balance", mode2);
        allConfig.modes.put("performance", mode3);
        allConfig.modes.put("fast", mode4);
        return allConfig;
    }

    public static AllConfig parse(String str) {
        Mode mode;
        if (str != null && !str.trim().isEmpty()) {
            AllConfig defaults = defaults();
            try {
                String str2 = null;
                for (String str3 : str.split("\n")) {
                    String trim = str3.trim();
                    Matcher matcher = P_ACTION.matcher(trim);
                    if (matcher.find()) {
                        str2 = matcher.group(1);
                    } else if (trim.equals("fi")) {
                        str2 = null;
                    } else if (str2 != null && (mode = defaults.modes.get(str2)) != null && !trim.startsWith("#")) {
                        Matcher matcher2 = P_WALT.matcher(trim);
                        if (matcher2.find()) {
                            mode.walt1 = matcher2.group(1);
                            mode.walt2 = matcher2.group(2);
                        } else {
                            Matcher matcher3 = P_OPT2.matcher(trim);
                            if (matcher3.find()) {
                                mode.opt2 = matcher3.group(1);
                            } else {
                                Matcher matcher4 = P_JSON.matcher(trim);
                                if (matcher4.find()) {
                                    mode.cpuMax = matcher4.group(1);
                                    mode.cpuMin = matcher4.group(2);
                                } else {
                                    Matcher matcher5 = P_LLCC.matcher(trim);
                                    if (matcher5.find()) {
                                        mode.llcc = matcher5.group(1);
                                    } else {
                                        Matcher matcher6 = P_ECHO.matcher(trim);
                                        if (matcher6.find()) {
                                            String group = matcher6.group(1);
                                            String group2 = matcher6.group(2);
                                            if (group2.contains("cpuctl")) {
                                                if (group2.contains("display")) {
                                                    mode.uclampDisplay = group;
                                                } else if (group2.contains("ssfg")) {
                                                    mode.uclampSsfg = group;
                                                } else if (group2.contains("touch")) {
                                                    mode.uclampTouch = group;
                                                } else if (group2.contains("multimedia")) {
                                                    mode.uclampMm = group;
                                                } else if (group2.contains("/rt/")) {
                                                    mode.uclampRt = group;
                                                } else if (group2.contains("top-app")) {
                                                    mode.uclampTopApp = group;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return defaults;
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public static String generate(AllConfig allConfig) {
        Mode mode = allConfig.modes.get("powersave");
        Mode mode2 = allConfig.modes.get("balance");
        Mode mode3 = allConfig.modes.get("performance");
        Mode mode4 = allConfig.modes.get("fast");
        StringBuilder sb = new StringBuilder();
        sb.append("SOC_PLAT=$(getprop ro.board.platform)\n\nif [[ $action == \"powersave\" ]]; then\n\t# 省电\n\techo \"powersave\" > $pan1\n    $mokzdz/A/opt2 ");
        sb.append(mode.opt2).append("\n    $mokzdz/A/conservative.sh\n    $mokzdz/A/json_cpu_max_min \"");
        sb.append(mode.cpuMax).append("\" \"").append(mode.cpuMin).append("\"\n    sh $mokzdz/A/freq0.sh 2>/dev/null\n    $mokzdz/A/llcc.sh set_max_freq ");
        sb.append(mode.llcc).append("\n    \n");
        appendUclamp(sb, mode);
        sb.append("fi\n\n");
        sb.append("if [[ $action == \"balance\" ]]; then\n");
        sb.append("\t# 均衡\n");
        appendUnlock(sb);
        sb.append("\techo \"balance\" > $pan1\n");
        sb.append("    $mokzdz/A/opt2 ").append(mode2.opt2).append('\n');
        sb.append("    $mokzdz/A/scx1.sh\n");
        sb.append("    $mokzdz/A/json_cpu_max_min \"").append(mode2.cpuMax).append("\" \"").append(mode2.cpuMin).append("\"\n");
        sb.append("    sh $mokzdz/A/freq1.sh 2>/dev/null\n");
        sb.append("    $mokzdz/A/llcc.sh set_max_freq ").append(mode2.llcc).append('\n');
        sb.append("   \n");
        appendUclamp(sb, mode2);
        sb.append("fi\n\n");
        sb.append("if [[ $action == \"performance\" ]]; then\n");
        sb.append("\t# 性能\n");
        appendUnlock(sb);
        sb.append("\techo \"performance\" > $pan1\n");
        sb.append("    $mokzdz/A/opt2 ").append(mode3.opt2).append('\n');
        sb.append("    $mokzdz/A/scx2.sh\n");
        sb.append("    $mokzdz/A/json_cpu_max_min \"").append(mode3.cpuMax).append("\" \"").append(mode3.cpuMin).append("\"\n");
        sb.append("    sh $mokzdz/A/freq2.sh 2>/dev/null\n");
        sb.append("    $mokzdz/A/llcc.sh set_max_freq ").append(mode3.llcc).append('\n');
        appendUclamp(sb, mode3);
        sb.append("fi\n\n");
        sb.append("if [[ $action == \"fast\" ]]; then\n");
        sb.append("\t# 极速\n");
        appendUnlock(sb);
        sb.append("\techo \"fast\" > $pan1\n");
        sb.append("\t$mokzdz/A/walt_up_rate_limit_us \"").append(mode4.walt1).append("\" \"").append(mode4.walt2).append("\"\n");
        sb.append("    $mokzdz/A/opt2 ").append(mode4.opt2).append('\n');
        sb.append("    $mokzdz/A/scx3.sh\n");
        sb.append("    $mokzdz/A/llcc.sh set_max_freq ").append(mode4.llcc).append('\n');
        sb.append("    $mokzdz/A/json_cpu_max_min \"").append(mode4.cpuMax).append("\" \"").append(mode4.cpuMin).append("\"\n");
        sb.append("    sh $mokzdz/A/freq3.sh 2>/dev/null\n");
        sb.append('\n');
        appendUclamp(sb, mode4);
        sb.append("fi\n");
        return sb.toString();
    }

    public static String patchFreqLines(String str, String str2) {
        if (str == null || str.trim().isEmpty()) {
            return str;
        }
        StringBuilder sb = new StringBuilder();
        int i = -1;
        for (String str3 : str.split("\n", -1)) {
            if (!str3.contains("$mokzdz") || (!str3.contains("/A/freq") && !str3.contains("/B/freq"))) {
                if (str3.contains("$action == \"powersave\"")) {
                    i = 0;
                } else if (str3.contains("$action == \"balance\"")) {
                    i = 1;
                } else if (str3.contains("$action == \"performance\"")) {
                    i = 2;
                } else if (str3.contains("$action == \"fast\"")) {
                    i = 3;
                }
                sb.append(str3).append('\n');
                if (i >= 0 && str3.contains("json_cpu_max_min")) {
                    sb.append("    sh $mokzdz/").append(str2).append("/freq").append(i).append(".sh 2>/dev/null\n");
                }
            }
        }
        return sb.toString();
    }

    private static void appendUnlock(StringBuilder sb) {
        sb.append("    $mokzdz/A/llcc.sh unlock_llcc\n");
        sb.append("    chattr -i /sys/class/devfreq/soc:qcom,memlat-drv/max_freq\n");
        sb.append("    chattr -i /sys/class/devfreq/soc:qcom,memlat-drv/min_freq\n");
        sb.append("    chattr -i /sys/class/devfreq/soc:qcom,memlat-drv/boost_freq\n\n");
    }

    private static void appendUclamp(StringBuilder sb, Mode mode) {
        sb.append("    echo \"").append(mode.uclampDisplay).append("\" > /dev/cpuctl/display/cpu.uclamp.min\n");
        sb.append("    echo \"").append(mode.uclampSsfg).append("\" > /dev/cpuctl/ssfg/cpu.uclamp.min\n");
        sb.append("    echo \"").append(mode.uclampTouch).append("\" > /dev/cpuctl/touch/cpu.uclamp.min\n");
        sb.append("    echo \"").append(mode.uclampMm).append("\" > /dev/cpuctl/multimedia/cpu.uclamp.min\n");
        sb.append("    echo \"").append(mode.uclampRt).append("\" > /dev/cpuctl/rt/cpu.uclamp.min\n");
        sb.append("    echo \"").append(mode.uclampTopApp).append("\" > /dev/cpuctl/top-app/cpu.uclamp.min\n");
    }
}
