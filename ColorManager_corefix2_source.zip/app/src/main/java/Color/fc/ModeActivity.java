package Color.fc;

import Color.fc.AppPickerDialog;
import Color.fc.ModeActivity;
import Color.fc.RootShell;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeSet;

/* loaded from: classes.dex */
public class ModeActivity extends ThemedActivity {
    private static final String CONF_FILE = "/sdcard/Android/qingtd/动态模式切换.conf";
    private static final String LOAD_FILE = "/sdcard/Android/qingtd/单应用负载.conf";
    private static final String[][] MODES = {new String[]{"powersave", "省电"}, new String[]{"balance", "均衡"}, new String[]{"performance", "性能"}, new String[]{"fast", "极速"}};
    private static final String MODULE_CONF_FILE = "/data/adb/modules/colorFC/qingtd/动态模式切换.conf";
    private static final String MOKML = "/sdcard/Android/qingtd";
    private static final String STOP_FILE = "/sdcard/Android/qingtd/stop";
    private TextView btnDelMode;
    private TextView btnDoneMode;
    private LinearLayout ruleBox;
    private TextView ruleHint;
    private String moren = "powersave";
    private final LinkedHashMap<String, String> rules = new LinkedHashMap<>();
    private final LinkedHashMap<String, long[]> loads = new LinkedHashMap<>();
    private String expandedPkg = null;
    private boolean deleteMode = false;
    private long[] cpuFreqs = new long[0];
    private boolean confLoaded = false;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public interface ModeCb {
        void on(String str);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // Color.fc.ThemedActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_mode);
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda21
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ModeActivity.this.lambda$onCreate$0(view);
            }
        });
        this.ruleHint = (TextView) findViewById(R.id.ruleHint);
        this.ruleBox = (LinearLayout) findViewById(R.id.ruleBox);
        this.btnDelMode = (TextView) findViewById(R.id.btnDeleteMode);
        this.btnDoneMode = (TextView) findViewById(R.id.btnDoneMode);
        this.btnDelMode.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda22
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ModeActivity.this.lambda$onCreate$1(view);
            }
        });
        this.btnDoneMode.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda23
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ModeActivity.this.lambda$onCreate$2(view);
            }
        });
        findViewById(R.id.addRuleBtn).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda24
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ModeActivity.this.lambda$onCreate$3(view);
            }
        });
        findViewById(R.id.saveRuleBtn).setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda25
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ModeActivity.this.lambda$onCreate$4(view);
            }
        });
        loadState();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(View view) {
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$1(View view) {
        setDeleteMode(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$2(View view) {
        setDeleteMode(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$3(View view) {
        pickApp();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$4(View view) {
        saveConf();
    }

    private void loadState() {
        new Thread(new Runnable() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda15
            @Override // java.lang.Runnable
            public final void run() {
                ModeActivity.this.lambda$loadState$6();
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$loadState$6() {
        loadFreqScan();
        String readFile = RootShell.readFile(CONF_FILE);
        parseLoads(RootShell.readFile(LOAD_FILE));
        if (readFile != null) {
            parseConf(readFile);
            this.confLoaded = true;
            runOnUiThread(new Runnable() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    ModeActivity.this.renderRules();
                }
            });
            return;
        }
        runOnUiThread(new Runnable() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda11
            @Override // java.lang.Runnable
            public final void run() {
                ModeActivity.this.lambda$loadState$5();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$loadState$5() {
        this.ruleHint.setText("未读取到模块配置文件（动态模式切换.conf）");
    }

    private void parseLoads(String str) {
        int indexOf;
        this.loads.clear();
        if (str == null) {
            return;
        }
        for (String str2 : str.split("\n")) {
            String trim = str2.trim();
            if (!trim.isEmpty() && !trim.startsWith("#") && (indexOf = trim.indexOf(61)) > 0) {
                try {
                    String[] split = trim.substring(indexOf + 1).trim().split(",");
                    this.loads.put(trim.substring(0, indexOf).trim(), new long[]{parseMhz(split.length > 0 ? split[0] : null), parseMhz(split.length > 1 ? split[1] : null), parseMhz(split.length > 2 ? split[2] : null)});
                } catch (Exception unused) {
                }
            }
        }
    }

    private static long parseMhz(String str) {
        try {
            return Long.parseLong(str.trim());
        } catch (Exception unused) {
            return 0L;
        }
    }

    private void writeLoads() {
        final StringBuilder sb = new StringBuilder("#单应用负载：包名=最低MHz,最大MHz,占用%（0=未设）\n");
        for (Map.Entry<String, long[]> entry : this.loads.entrySet()) {
            long[] value = entry.getValue();
            if (value[0] > 0 || value[1] > 0 || value[2] > 0) {
                sb.append(entry.getKey()).append('=').append(value[0]).append(',').append(value[1]).append(',').append(value[2]).append('\n');
            }
        }
        new Thread(new Runnable() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda19
            @Override // java.lang.Runnable
            public final void run() {
                ModeActivity.this.lambda$writeLoads$7(sb);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$writeLoads$7(StringBuilder sb) {
        RootShell.writeFile(getCacheDir(), sb.toString(), LOAD_FILE);
    }

    private void loadFreqScan() {
        int i = 0;
        try {
            String string = getSharedPreferences("colorfc", 0).getString("freqScan", "");
            if (!string.isEmpty()) {
                String[] split = string.split(",");
                long[] jArr = new long[split.length];
                int length = split.length;
                int i2 = 0;
                while (i < length) {
                    int i3 = i2 + 1;
                    try {
                        jArr[i2] = Long.parseLong(split[i]);
                    } catch (Exception unused) {
                    }
                    i++;
                    i2 = i3;
                }
                this.cpuFreqs = Arrays.copyOf(jArr, i2);
                return;
            }
            StringBuilder sb = new StringBuilder();
            for (int i4 = 0; i4 < 8; i4++) {
                sb.append("cat /sys/devices/system/cpu/cpu").append(i4).append("/cpufreq/scaling_available_frequencies 2>/dev/null; ");
            }
            TreeSet treeSet = new TreeSet(Collections.reverseOrder());
            RootShell.Result exec = RootShell.exec(sb.toString());
            if (exec.ok() && exec.out != null) {
                for (String str : exec.out.trim().split("\\s+")) {
                    try {
                        long parseLong = Long.parseLong(str);
                        if (parseLong > 1000) {
                            treeSet.add(Long.valueOf(parseLong / 1000));
                        }
                    } catch (Exception unused2) {
                    }
                }
            }
            if (treeSet.size() < 2) {
                StringBuilder sb2 = new StringBuilder();
                for (int i5 = 0; i5 < 8; i5++) {
                    sb2.append("cat /sys/devices/system/cpu/cpu").append(i5).append("/cpufreq/cpuinfo_min_freq 2>/dev/null; ");
                    sb2.append("cat /sys/devices/system/cpu/cpu").append(i5).append("/cpufreq/cpuinfo_max_freq 2>/dev/null; ");
                }
                RootShell.Result exec2 = RootShell.exec(sb2.toString());
                if (exec2.ok() && exec2.out != null) {
                    for (String str2 : exec2.out.trim().split("\\s+")) {
                        try {
                            long parseLong2 = Long.parseLong(str2);
                            if (parseLong2 > 1000) {
                                treeSet.add(Long.valueOf(parseLong2 / 1000));
                            }
                        } catch (Exception unused3) {
                        }
                    }
                }
            }
            if (treeSet.isEmpty()) {
                return;
            }
            StringBuilder sb3 = new StringBuilder();
            Iterator it = treeSet.iterator();
            while (it.hasNext()) {
                long longValue = ((Long) it.next()).longValue();
                if (sb3.length() > 0) {
                    sb3.append(',');
                }
                sb3.append(longValue);
            }
            getSharedPreferences("colorfc", 0).edit().putString("freqScan", sb3.toString()).commit();
            this.cpuFreqs = new long[treeSet.size()];
            Iterator it2 = treeSet.iterator();
            while (it2.hasNext()) {
                int i6 = i + 1;
                this.cpuFreqs[i] = ((Long) it2.next()).longValue();
                i = i6;
            }
        } catch (Exception unused4) {
        }
    }

    private void parseConf(String str) {
        int indexOf;
        this.rules.clear();
        this.moren = "powersave";
        for (String str2 : str.split("\n")) {
            String trim = str2.trim();
            if (!trim.isEmpty() && !trim.startsWith("#") && (indexOf = trim.indexOf(61)) > 0) {
                String trim2 = trim.substring(0, indexOf).trim();
                String trim3 = trim.substring(indexOf + 1).trim();
                if ("moren".equals(trim2)) {
                    this.moren = trim3;
                } else {
                    this.rules.put(trim2, trim3);
                }
            }
        }
    }

    private String buildConf() {
        StringBuilder sb = new StringBuilder("#moren是全局默认的意思，包名等号加模式（实时的）\n#模式powersave、balance、performance、fast\nmoren=");
        sb.append(this.moren).append("\n");
        for (Map.Entry<String, String> entry : this.rules.entrySet()) {
            sb.append(entry.getKey()).append('=').append(entry.getValue()).append('\n');
        }
        return sb.toString();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void renderRules() {
        this.ruleBox.removeAllViews();
        this.ruleBox.addView(morenRow());
        for (Map.Entry<String, String> entry : this.rules.entrySet()) {
            this.ruleBox.addView(ruleRow(entry.getKey(), appName(entry.getKey())));
        }
    }

    private View morenRow() {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        LayoutParams layoutParams = new LayoutParams(-1, -2);
        layoutParams.bottomMargin = dp(6);
        linearLayout.setLayoutParams(layoutParams);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(getResources().getColor(R.color.accentSoft));
        gradientDrawable.setCornerRadius(dp(10));
        linearLayout.setBackground(gradientDrawable);
        linearLayout.setPadding(dp(12), dp(6), dp(12), dp(6));
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ModeActivity.this.lambda$morenRow$9(view);
            }
        });
        TextView textView = new TextView(this);
        textView.setText("全局默认");
        textView.setTextColor(getResources().getColor(R.color.textPrimary));
        textView.setTextSize(13.0f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setLayoutParams(new LayoutParams(0, -2, 1.0f));
        linearLayout.addView(textView);
        TextView textView2 = new TextView(this);
        textView2.setText(modeName(this.moren));
        textView2.setTextColor(getResources().getColor(R.color.accent));
        textView2.setTextSize(13.0f);
        textView2.setTypeface(Typeface.DEFAULT_BOLD);
        linearLayout.addView(textView2);
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$morenRow$9(View view) {
        pickMode(new ModeCb() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda20
            @Override // Color.fc.ModeActivity.ModeCb
            public final void on(String str) {
                ModeActivity.this.lambda$morenRow$8(str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$morenRow$8(String str) {
        this.moren = str;
        renderRules();
        toast("全局默认已设为 " + modeName(str) + "\n记得保存策略");
    }

    private View ruleRow(final String str, String str2) {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        LayoutParams layoutParams = new LayoutParams(-1, -2);
        layoutParams.topMargin = dp(6);
        linearLayout.setLayoutParams(layoutParams);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(getResources().getColor(R.color.bgInput));
        gradientDrawable.setCornerRadius(dp(10));
        linearLayout.setBackground(gradientDrawable);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setPadding(dp(12), dp(10), dp(12), dp(10));
        linearLayout2.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ModeActivity.this.lambda$ruleRow$10(str, view);
            }
        });
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(1);
        linearLayout3.setLayoutParams(new LayoutParams(0, -2, 1.0f));
        TextView textView = new TextView(this);
        textView.setText(str2);
        textView.setTextColor(getResources().getColor(R.color.textPrimary));
        textView.setTextSize(13.0f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        linearLayout3.addView(textView);
        TextView textView2 = new TextView(this);
        textView2.setText(str);
        textView2.setTextColor(getResources().getColor(R.color.textSecondary));
        textView2.setTextSize(10.5f);
        linearLayout3.addView(textView2);
        linearLayout2.addView(linearLayout3);
        TextView textView3 = new TextView(this);
        textView3.setText(modeName(this.rules.get(str)));
        textView3.setTextColor(getResources().getColor(R.color.accent));
        textView3.setTextSize(13.0f);
        textView3.setTypeface(Typeface.DEFAULT_BOLD);
        linearLayout2.addView(textView3);
        if (this.deleteMode) {
            ImageView imageView = new ImageView(this);
            imageView.setImageResource(android.R.drawable.ic_delete);
            imageView.setColorFilter(-1750963, PorterDuff.Mode.SRC_ATOP);
            LayoutParams layoutParams2 = new LayoutParams(dp(26), dp(26));
            layoutParams2.leftMargin = dp(12);
            imageView.setLayoutParams(layoutParams2);
            imageView.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda6
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    ModeActivity.this.lambda$ruleRow$11(str, view);
                }
            });
            linearLayout2.addView(imageView);
        }
        linearLayout.addView(linearLayout2);
        if (str.equals(this.expandedPkg)) {
            linearLayout.addView(expandPanel(str));
        }
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$ruleRow$10(String str, View view) {
        toggleExpand(str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$ruleRow$11(String str, View view) {
        this.rules.remove(str);
        this.loads.remove(str);
        writeLoads();
        if (str.equals(this.expandedPkg)) {
            this.expandedPkg = null;
        }
        renderRules();
    }

    private void toggleExpand(String str) {
        if (str.equals(this.expandedPkg)) {
            str = null;
        }
        this.expandedPkg = str;
        renderRules();
    }

    private void setDeleteMode(boolean z) {
        this.deleteMode = z;
        this.btnDelMode.setBackgroundResource(z ? R.drawable.bg_tab_sel : R.drawable.bg_tab);
        this.btnDoneMode.setBackgroundResource(z ? R.drawable.bg_tab_sel : R.drawable.bg_tab);
        this.btnDoneMode.setTextColor(getResources().getColor(z ? R.color.accent : R.color.textSecondary));
        renderRules();
    }

    private View expandPanel(final String str) {
        WrapLayout wrapLayout = new WrapLayout(this, dp(8), dp(8));
        boolean z = false;
        wrapLayout.setPadding(dp(12), 0, dp(12), dp(12));
        TextView textView = new TextView(this);
        textView.setText("模式选择");
        textView.setTextColor(getResources().getColor(R.color.accent));
        textView.setTextSize(11.5f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setBackground(makeChip(436238248));
        textView.setPadding(dp(8), dp(3), dp(8), dp(3));
        textView.setOnClickListener(new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ModeActivity.this.lambda$expandPanel$13(str, view);
            }
        });
        wrapLayout.addView(textView);
        long[] jArr = this.loads.get(str);
        wrapLayout.addView(loadChip("最低负载", jArr != null && jArr[0] > 0, new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ModeActivity.this.lambda$expandPanel$14(str, view);
            }
        }));
        wrapLayout.addView(loadChip("最大负载", jArr != null && jArr[1] > 0, new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ModeActivity.this.lambda$expandPanel$15(str, view);
            }
        }));
        if (jArr != null && jArr[2] > 0) {
            z = true;
        }
        wrapLayout.addView(loadChip("占用率", z, new View.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ModeActivity.this.lambda$expandPanel$16(str, view);
            }
        }));
        return wrapLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$expandPanel$13(final String str, View view) {
        pickMode(new ModeCb() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda26
            @Override // Color.fc.ModeActivity.ModeCb
            public final void on(String str2) {
                ModeActivity.this.lambda$expandPanel$12(str, str2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$expandPanel$12(String str, String str2) {
        this.rules.put(str, str2);
        renderRules();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$expandPanel$14(String str, View view) {
        pickFreq(str, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$expandPanel$15(String str, View view) {
        pickFreq(str, false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$expandPanel$16(String str, View view) {
        pickPct(str);
    }

    private void pickApp() {
        if (!this.confLoaded) {
            toast("配置尚未加载完成");
        } else {
            AppPickerDialog.show(this, this.rules, new AppPickerDialog.PickCb() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda4
                @Override // Color.fc.AppPickerDialog.PickCb
                public final void on(String str, String str2) {
                    ModeActivity.this.lambda$pickApp$18(str, str2);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$pickApp$18(final String str, final String str2) {
        pickMode(new ModeCb() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda18
            @Override // Color.fc.ModeActivity.ModeCb
            public final void on(String str3) {
                ModeActivity.this.lambda$pickApp$17(str, str2, str3);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$pickApp$17(String str, String str2, String str3) {
        this.rules.put(str, str3);
        renderRules();
        toast("已添加：" + str2 + " → " + modeName(str3) + "\n记得保存策略");
    }

    private View loadChip(String str, boolean z, View.OnClickListener onClickListener) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(z ? -1531075 : -8615264);
        textView.setTextSize(11.5f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setBackground(makeChip(z ? 451453757 : 343969702));
        textView.setPadding(dp(8), dp(3), dp(8), dp(3));
        textView.setOnClickListener(onClickListener);
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.rightMargin = dp(6);
        textView.setLayoutParams(layoutParams);
        return textView;
    }

    private void pickFreq(final String str, final boolean z) {
        long j;
        int i;
        String str2 = z ? "最低负载" : "最大负载";
        if (this.cpuFreqs.length == 0) {
            pickFreqManual(str, z, str2);
            return;
        }
        long[] jArr = this.loads.get(str);
        int i2 = 0;
        if (jArr == null) {
            j = 0;
        } else {
            j = z ? jArr[0] : jArr[1];
        }
        if (j > 0) {
            int i3 = 0;
            while (true) {
                long[] jArr2 = this.cpuFreqs;
                if (i3 >= jArr2.length) {
                    break;
                }
                if (jArr2[i3] == j) {
                    i = i3 + 1;
                    break;
                }
                i3++;
            }
        }
        i = 0;
        String[] strArr = new String[this.cpuFreqs.length + 1];
        strArr[0] = "关闭";
        while (i2 < this.cpuFreqs.length) {
            int i4 = i2 + 1;
            strArr[i4] = this.cpuFreqs[i2] + " MHz";
            i2 = i4;
        }
        new AlertDialog.Builder(this).setTitle(str2).setSingleChoiceItems(strArr, i, new DialogInterface.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda16
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i5) {
                ModeActivity.this.lambda$pickFreq$19(str, z, dialogInterface, i5);
            }
        }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$pickFreq$19(String str, boolean z, DialogInterface dialogInterface, int i) {
        setLoad(str, z, i == 0 ? 0L : this.cpuFreqs[i - 1]);
        dialogInterface.dismiss();
    }

    private void pickFreqManual(final String str, final boolean z, String str2) {
        long j;
        final EditText editText = new EditText(this);
        editText.setInputType(2);
        long[] jArr = this.loads.get(str);
        if (jArr == null) {
            j = 0;
        } else {
            j = z ? jArr[0] : jArr[1];
        }
        editText.setText(String.valueOf(j));
        new AlertDialog.Builder(this).setTitle(str2).setView(editText).setPositiveButton("确定", new DialogInterface.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda14
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                ModeActivity.this.lambda$pickFreqManual$20(str, z, editText, dialogInterface, i);
            }
        }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$pickFreqManual$20(String str, boolean z, EditText editText, DialogInterface dialogInterface, int i) {
        try {
            setLoad(str, z, Math.max(0L, Long.parseLong(editText.getText().toString().trim())));
        } catch (Exception unused) {
        }
    }

    private void pickPct(final String str) {
        long[] jArr = this.loads.get(str);
        int min = (int) Math.min(100L, Math.max(0L, jArr == null ? 0L : jArr[2]));
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(dp(20), dp(4), dp(20), dp(2));
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        final SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(100);
        seekBar.setProgress(min);
        seekBar.setLayoutParams(new LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(seekBar);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(16);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(343969702);
        gradientDrawable.setCornerRadius(dp(8));
        gradientDrawable.setStroke(dp(1), 771782568);
        linearLayout3.setBackground(gradientDrawable);
        linearLayout3.setPadding(dp(8), 0, dp(7), 0);
        LayoutParams layoutParams = new LayoutParams(dp(74), -2);
        ((LinearLayout.LayoutParams) layoutParams).leftMargin = dp(12);
        linearLayout3.setLayoutParams(layoutParams);
        final EditText editText = new EditText(this);
        editText.setInputType(2);
        editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
        editText.setText(String.valueOf(min));
        editText.setTextSize(13.0f);
        editText.setTextColor(getResources().getColor(R.color.textPrimary));
        editText.setBackgroundColor(0);
        editText.setMinHeight(0);
        editText.setMinimumHeight(0);
        editText.setPadding(0, dp(6), 0, dp(6));
        editText.setGravity(17);
        editText.setLayoutParams(new LayoutParams(0, -2, 1.0f));
        linearLayout3.addView(editText);
        TextView textView = new TextView(this);
        textView.setText("%");
        textView.setTextColor(getResources().getColor(R.color.textSecondary));
        textView.setTextSize(12.0f);
        linearLayout3.addView(textView);
        linearLayout2.addView(linearLayout3);
        linearLayout.addView(linearLayout2);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: Color.fc.ModeActivity.1
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar seekBar2) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar seekBar2) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                if (z) {
                    editText.setText(String.valueOf(i));
                }
            }
        });
        editText.addTextChangedListener(new TextWatcher() { // from class: Color.fc.ModeActivity.2
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                try {
                    int parseInt = Integer.parseInt(charSequence.toString());
                    if (parseInt < 0 || parseInt > 100 || parseInt == seekBar.getProgress()) {
                        return;
                    }
                    seekBar.setProgress(parseInt);
                } catch (Exception unused) {
                }
            }
        });
        new AlertDialog.Builder(this).setTitle("占用率").setView(linearLayout).setPositiveButton("确定", new DialogInterface.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda7
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                ModeActivity.this.lambda$pickPct$21(editText, seekBar, str, dialogInterface, i);
            }
        }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$pickPct$21(EditText editText, SeekBar seekBar, String str, DialogInterface dialogInterface, int i) {
        int progress;
        try {
            progress = Integer.parseInt(editText.getText().toString().trim());
        } catch (Exception unused) {
            progress = seekBar.getProgress();
        }
        setLoad(str, 2, Math.min(100, Math.max(0, progress)));
    }

    private void setLoad(String str, boolean z, long j) {
        setLoad(str, !z ? 1 : 0, j);
    }

    private void setLoad(String str, int i, long j) {
        long[] jArr = this.loads.get(str);
        if (jArr == null) {
            jArr = new long[]{0, 0, 0};
        }
        jArr[i] = j;
        if (jArr[0] > 0 || jArr[1] > 0 || jArr[2] > 0) {
            this.loads.put(str, jArr);
        } else {
            this.loads.remove(str);
        }
        writeLoads();
        renderRules();
        AppLimitService.ensure(this);
    }

    private GradientDrawable makeChip(int i) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(i);
        gradientDrawable.setCornerRadius(dp(7));
        return gradientDrawable;
    }

    private void pickMode(final ModeCb modeCb) {
        String[] strArr = new String[MODES.length];
        int i = 0;
        while (true) {
            String[][] strArr2 = MODES;
            if (i >= strArr2.length) {
                new AlertDialog.Builder(this).setTitle("选择调度模式").setItems(strArr, new DialogInterface.OnClickListener() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda17
                    @Override // android.content.DialogInterface.OnClickListener
                    public final void onClick(DialogInterface dialogInterface, int i2) {
                        ModeActivity.ModeCb.this.on(ModeActivity.MODES[i2][0]);
                    }
                }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).show();
                return;
            } else {
                strArr[i] = strArr2[i][1];
                i++;
            }
        }
    }

    private void saveConf() {
        if (!this.confLoaded) {
            toast("配置尚未加载完成");
        } else {
            final String buildConf = buildConf();
            new Thread(new Runnable() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    ModeActivity.this.lambda$saveConf$25(buildConf);
                }
            }).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$saveConf$25(String str) {
        RootShell.Result writeFile = RootShell.writeFile(getCacheDir(), str, CONF_FILE);
        boolean ok = writeFile.ok();
        RootShell.Result writeFile2 = RootShell.writeFile(getCacheDir(), str, MODULE_CONF_FILE);
        if (ok) {
            RootShell.exec("rm -f '/sdcard/Android/qingtd/stop'; pgrep -f \"[q]ingtdjc\" >/dev/null 2>&1 || nohup sh /data/adb/modules/colorFC/script/qingtd.sh >/dev/null 2>&1 &");
            try {
                Thread.sleep(2000L);
            } catch (InterruptedException unused) {
            }
            String readFile = RootShell.readFile(CONF_FILE);
            final boolean z = readFile != null && readFile.trim().equals(str.trim());
            runOnUiThread(new Runnable() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    ModeActivity.this.lambda$saveConf$23(z);
                }
            });
            return;
        }
        final String str2 = writeFile.err + (writeFile2.ok() ? "" : " | 模板写入失败");
        runOnUiThread(new Runnable() { // from class: Color.fc.ModeActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                ModeActivity.this.lambda$saveConf$24(str2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$saveConf$23(boolean z) {
        if (z) {
            toast("保存成功");
        } else {
            toast("保存后被系统回滚，请把此提示截图反馈");
        }
        loadState();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$saveConf$24(String str) {
        toast("保存失败：" + str);
    }

    private String modeName(String str) {
        for (String[] strArr : MODES) {
            if (strArr[0].equals(str)) {
                return strArr[1];
            }
        }
        return (str == null || str.isEmpty()) ? "未知" : str;
    }

    private String appName(String str) {
        try {
            PackageManager packageManager = getPackageManager();
            return String.valueOf(packageManager.getApplicationLabel(packageManager.getApplicationInfo(str, 0)));
        } catch (Exception unused) {
            return str;
        }
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    private void toast(String str) {
        Toast.makeText(this, str, 0).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class LayoutParams extends LinearLayout.LayoutParams {
        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        public LayoutParams(int i, int i2, float f) {
            super(i, i2, f);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class WrapLayout extends ViewGroup {
        private final int hGap;
        private final int vGap;

        WrapLayout(Context context, int i, int i2) {
            super(context);
            this.hGap = i;
            this.vGap = i2;
        }

        @Override // android.view.View
        protected void onMeasure(int i, int i2) {
            int size = (View.MeasureSpec.getSize(i) - getPaddingLeft()) - getPaddingRight();
            int paddingTop = getPaddingTop();
            int i3 = 0;
            int i4 = 0;
            for (int i5 = 0; i5 < getChildCount(); i5++) {
                View childAt = getChildAt(i5);
                measureChild(childAt, i, i2);
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                if (i4 > 0 && this.hGap + i4 + measuredWidth > size) {
                    paddingTop += i3 + this.vGap;
                    i3 = 0;
                    i4 = 0;
                }
                i4 += (i4 > 0 ? this.hGap : 0) + measuredWidth;
                i3 = Math.max(i3, measuredHeight);
            }
            setMeasuredDimension(resolveSize(size + getPaddingLeft() + getPaddingRight(), i), resolveSize(paddingTop + i3 + getPaddingBottom(), i2));
        }

        @Override // android.view.ViewGroup, android.view.View
        protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
            int paddingLeft = getPaddingLeft();
            int paddingTop = getPaddingTop();
            int width = getWidth() - getPaddingRight();
            int i5 = 0;
            for (int i6 = 0; i6 < getChildCount(); i6++) {
                View childAt = getChildAt(i6);
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                if (paddingLeft > getPaddingLeft() && paddingLeft + measuredWidth > width) {
                    paddingLeft = getPaddingLeft();
                    paddingTop += i5 + this.vGap;
                    i5 = 0;
                }
                childAt.layout(paddingLeft, paddingTop, paddingLeft + measuredWidth, paddingTop + measuredHeight);
                paddingLeft += measuredWidth + this.hGap;
                i5 = Math.max(i5, measuredHeight);
            }
        }
    }
}
