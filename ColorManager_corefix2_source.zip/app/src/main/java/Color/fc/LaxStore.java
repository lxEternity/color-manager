package Color.fc;

import Color.fc.RootShell;
import android.content.Context;
import android.net.Uri;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.function.Predicate;

/* loaded from: classes.dex */
public class LaxStore {
    public static final String PATH = "/storage/emulated/0/color.lax";

    public static LinkedHashMap<String, String> parse(String str) {
        int indexOf;
        LinkedHashMap<String, String> linkedHashMap = new LinkedHashMap<>();
        if (str == null) {
            return linkedHashMap;
        }
        for (String str2 : str.split("\n")) {
            String trim = str2.trim();
            if (!trim.isEmpty() && !trim.startsWith("#") && (indexOf = trim.indexOf(61)) > 0) {
                linkedHashMap.put(trim.substring(0, indexOf).trim(), trim.substring(indexOf + 1).trim());
            }
        }
        return linkedHashMap;
    }

    public static LinkedHashMap<String, String> read() {
        return parse(RootShell.readFile(PATH));
    }

    public static LinkedHashMap<String, String> readUri(Context context, Uri uri) {
        try {
            InputStream openInputStream = context.getContentResolver().openInputStream(uri);
            try {
                if (openInputStream == null) {
                    LinkedHashMap<String, String> linkedHashMap = new LinkedHashMap<>();
                    if (openInputStream != null) {
                        openInputStream.close();
                    }
                    return linkedHashMap;
                }
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                byte[] bArr = new byte[8192];
                while (true) {
                    int read = openInputStream.read(bArr);
                    if (read <= 0) {
                        break;
                    }
                    byteArrayOutputStream.write(bArr, 0, read);
                }
                LinkedHashMap<String, String> parse = parse(byteArrayOutputStream.toString("UTF-8"));
                if (openInputStream != null) {
                    openInputStream.close();
                }
                return parse;
            } finally {
            }
        } catch (Exception unused) {
            return new LinkedHashMap<>();
        }
    }

    public static RootShell.Result write(File file, LinkedHashMap<String, String> linkedHashMap) {
        LinkedHashMap<String, String> read = read();
        final HashSet hashSet = new HashSet();
        for (String str : linkedHashMap.keySet()) {
            int indexOf = str.indexOf(46);
            if (indexOf > 0) {
                str = str.substring(0, indexOf);
            }
            hashSet.add(str);
        }
        read.keySet().removeIf(new Predicate() { // from class: Color.fc.LaxStore$$ExternalSyntheticLambda0
            @Override // java.util.function.Predicate
            public final boolean test(Object obj) {
                return LaxStore.lambda$write$0(hashSet, (String) obj);
            }
        });
        read.putAll(linkedHashMap);
        StringBuilder sb = new StringBuilder("# ColorFC 配置 (color.lax)\n# 仅包含参数数值：gov.*=调速器参数，sch.*=调度参数\n");
        for (String str2 : read.keySet()) {
            if (str2.startsWith("gov.")) {
                sb.append(str2).append('=').append(read.get(str2)).append('\n');
            }
        }
        for (String str3 : read.keySet()) {
            if (!str3.startsWith("gov.")) {
                sb.append(str3).append('=').append(read.get(str3)).append('\n');
            }
        }
        return RootShell.writeFile(file, sb.toString(), PATH);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ boolean lambda$write$0(HashSet hashSet, String str) {
        int indexOf = str.indexOf(46);
        if (indexOf > 0) {
            str = str.substring(0, indexOf);
        }
        return hashSet.contains(str);
    }
}
